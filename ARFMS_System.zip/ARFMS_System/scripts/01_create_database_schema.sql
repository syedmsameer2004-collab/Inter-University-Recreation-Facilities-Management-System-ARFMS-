-- ARFMS Database Schema Creation Script
-- Inter University Recreation Facilities Management System

-- Create Database
CREATE DATABASE ARFMS;
GO

USE ARFMS;
GO

-- Users Table (for all user types)
CREATE TABLE Users (
    UserID INT IDENTITY(1,1) PRIMARY KEY,
    Username NVARCHAR(50) UNIQUE NOT NULL,
    Email NVARCHAR(100) UNIQUE NOT NULL,
    Password NVARCHAR(255) NOT NULL, -- Should be hashed
    UserRole NVARCHAR(20) NOT NULL CHECK (UserRole IN ('Manager', 'Reception', 'Student', 'MaintenanceStaff')),
    FirstName NVARCHAR(50) NOT NULL,
    LastName NVARCHAR(50) NOT NULL,
    PhoneNumber NVARCHAR(15),
    IsActive BIT DEFAULT 1,
    CreatedDate DATETIME DEFAULT GETDATE(),
    LastLoginDate DATETIME
);

-- Universities Table
CREATE TABLE Universities (
    UniversityID INT IDENTITY(1,1) PRIMARY KEY,
    UniversityName NVARCHAR(100) NOT NULL,
    Address NVARCHAR(255),
    ContactPerson NVARCHAR(100),
    ContactEmail NVARCHAR(100),
    ContactPhone NVARCHAR(15),
    IsActive BIT DEFAULT 1,
    CreatedDate DATETIME DEFAULT GETDATE()
);

-- Facility Types Table
CREATE TABLE FacilityTypes (
    FacilityTypeID INT IDENTITY(1,1) PRIMARY KEY,
    TypeName NVARCHAR(50) NOT NULL,
    Description NVARCHAR(255)
);

-- Facilities Table
CREATE TABLE Facilities (
    FacilityID INT IDENTITY(1,1) PRIMARY KEY,
    FacilityCode NVARCHAR(20) UNIQUE NOT NULL,
    FacilityName NVARCHAR(100) NOT NULL,
    FacilityTypeID INT FOREIGN KEY REFERENCES FacilityTypes(FacilityTypeID),
    UniversityID INT FOREIGN KEY REFERENCES Universities(UniversityID),
    Location NVARCHAR(255),
    Capacity INT,
    HourlyRate DECIMAL(10,2) NOT NULL,
    Description NVARCHAR(500),
    IsAvailable BIT DEFAULT 1,
    CreatedDate DATETIME DEFAULT GETDATE()
);

ALTER TABLE Facilities
ADD IsActive BIT NOT NULL DEFAULT 1;


-- Bookings Table
CREATE TABLE Bookings (
    BookingID INT IDENTITY(1,1) PRIMARY KEY,
    StudentID INT FOREIGN KEY REFERENCES Users(UserID),
    FacilityID INT FOREIGN KEY REFERENCES Facilities(FacilityID),
    BookingDate DATE NOT NULL,
    StartTime TIME NOT NULL,
    EndTime TIME NOT NULL,
    Duration AS (DATEDIFF(HOUR, StartTime, EndTime)),
    TotalAmount DECIMAL(10,2) NOT NULL,
    BookingStatus NVARCHAR(20) DEFAULT 'Pending' CHECK (BookingStatus IN ('Pending', 'Confirmed', 'Cancelled', 'Completed')),
    PaymentStatus NVARCHAR(20) DEFAULT 'Unpaid' CHECK (PaymentStatus IN ('Unpaid', 'Paid', 'Refunded')),
    CreatedBy INT FOREIGN KEY REFERENCES Users(UserID), -- Reception staff who created booking
    CreatedDate DATETIME DEFAULT GETDATE(),
    Notes NVARCHAR(500)
);

-- Payments Table
CREATE TABLE Payments (
    PaymentID INT IDENTITY(1,1) PRIMARY KEY,
    BookingID INT FOREIGN KEY REFERENCES Bookings(BookingID),
    Amount DECIMAL(10,2) NOT NULL,
    PaymentMethod NVARCHAR(20) DEFAULT 'Cash' CHECK (PaymentMethod IN ('Cash', 'Card', 'Transfer')),
    PaymentDate DATETIME DEFAULT GETDATE(),
    ProcessedBy INT FOREIGN KEY REFERENCES Users(UserID), -- Reception staff who processed payment
    ReceiptNumber NVARCHAR(50) UNIQUE NOT NULL
);

-- Maintenance Schedules Table
CREATE TABLE MaintenanceSchedules (
    ScheduleID INT IDENTITY(1,1) PRIMARY KEY,
    FacilityID INT FOREIGN KEY REFERENCES Facilities(FacilityID),
    MaintenanceStaffID INT FOREIGN KEY REFERENCES Users(UserID),
    ScheduledDate DATE NOT NULL,
    ScheduledTime TIME NOT NULL,
    MaintenanceType NVARCHAR(50) NOT NULL, -- Routine, Repair, Deep Clean, etc.
    Description NVARCHAR(500),
    Status NVARCHAR(20) DEFAULT 'Scheduled' CHECK (Status IN ('Scheduled', 'InProgress', 'Completed', 'Cancelled')),
    AssignedBy INT FOREIGN KEY REFERENCES Users(UserID), -- Manager who assigned
    CreatedDate DATETIME DEFAULT GETDATE(),
    CompletedDate DATETIME,
    Notes NVARCHAR(500)
);

ALTER TABLE MaintenanceSchedules
ADD IsActive BIT NOT NULL DEFAULT 1;


-- Equipment Requests Table
CREATE TABLE EquipmentRequests (
    RequestID INT IDENTITY(1,1) PRIMARY KEY,
    FacilityID INT FOREIGN KEY REFERENCES Facilities(FacilityID),
    RequestedBy INT FOREIGN KEY REFERENCES Users(UserID), -- Maintenance Staff
    RequestType NVARCHAR(20) NOT NULL CHECK (RequestType IN ('Repair', 'Replacement', 'Supply')),
    ItemName NVARCHAR(100) NOT NULL,
    Description NVARCHAR(500),
    Quantity INT DEFAULT 1,
    EstimatedCost DECIMAL(10,2),
    Priority NVARCHAR(10) DEFAULT 'Medium' CHECK (Priority IN ('Low', 'Medium', 'High', 'Urgent')),
    Status NVARCHAR(20) DEFAULT 'Pending' CHECK (Status IN ('Pending', 'Approved', 'Rejected', 'Completed')),
    RequestDate DATETIME DEFAULT GETDATE(),
    ApprovedBy INT FOREIGN KEY REFERENCES Users(UserID), -- Manager
    ApprovalDate DATETIME,
    CompletedDate DATETIME,
    ApprovalNotes NVARCHAR(500)
);

ALTER TABLE EquipmentRequests
ADD IsActive BIT NOT NULL DEFAULT 1;

-- Reviews Table
CREATE TABLE Reviews (
    ReviewID INT IDENTITY(1,1) PRIMARY KEY,
    BookingID INT FOREIGN KEY REFERENCES Bookings(BookingID),
    StudentID INT FOREIGN KEY REFERENCES Users(UserID),
    FacilityID INT FOREIGN KEY REFERENCES Facilities(FacilityID),
    Rating INT NOT NULL CHECK (Rating >= 1 AND Rating <= 5),
    ReviewText NVARCHAR(1000),
    ReviewDate DATETIME DEFAULT GETDATE()
);

-- Cleaning Supplies Table
CREATE TABLE CleaningSupplies (
    SupplyID INT IDENTITY(1,1) PRIMARY KEY,
    SupplyName NVARCHAR(100) NOT NULL,
    CurrentStock INT DEFAULT 0,
    MinimumStock INT DEFAULT 10,
    Unit NVARCHAR(20) NOT NULL, -- pieces, liters, kg, etc.
    LastRestocked DATETIME,
    IsActive BIT DEFAULT 1
);

-- Supply Requests Table
CREATE TABLE SupplyRequests (
    SupplyRequestID INT IDENTITY(1,1) PRIMARY KEY,
    SupplyID INT FOREIGN KEY REFERENCES CleaningSupplies(SupplyID),
    RequestedBy INT FOREIGN KEY REFERENCES Users(UserID), -- Maintenance Staff
    QuantityRequested INT NOT NULL,
    RequestDate DATETIME DEFAULT GETDATE(),
    Status NVARCHAR(20) DEFAULT 'Pending' CHECK (Status IN ('Pending', 'Approved', 'Fulfilled', 'Rejected')),
    ApprovedBy INT FOREIGN KEY REFERENCES Users(UserID), -- Manager
    ApprovalDate DATETIME,
    Notes NVARCHAR(500)
);
