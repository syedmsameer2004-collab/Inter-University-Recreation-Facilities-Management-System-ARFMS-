-- Sample Data for ARFMS System
USE ARFMS;
GO

-- Insert Facility Types
INSERT INTO FacilityTypes (TypeName, Description) VALUES
('Gymnasium', 'Indoor sports facility for basketball, volleyball, badminton'),
('Swimming Pool', 'Aquatic facility for swimming and water sports'),
('Tennis Court', 'Outdoor/Indoor tennis playing area'),
('Football Field', 'Large outdoor field for football and soccer'),
('Fitness Center', 'Equipment-based fitness and workout facility'),
('Badminton Court', 'Indoor court specifically for badminton'),
('Basketball Court', 'Court designed for basketball games'),
('Squash Court', 'Indoor court for squash games');

-- Insert Universities
INSERT INTO Universities (UniversityName, Address, ContactPerson, ContactEmail, ContactPhone) VALUES
('Asia Pacific University', 'Bukit Jalil, Kuala Lumpur', 'Dr. Ahmad Rahman', 'ahmad.rahman@apu.edu.my', '03-8996-1000'),
('University of Malaya', 'Petaling Jaya, Selangor', 'Prof. Siti Aminah', 'siti.aminah@um.edu.my', '03-7967-3000'),
('Universiti Teknologi Malaysia', 'Skudai, Johor', 'Dr. Lim Wei Ming', 'lim.weiming@utm.my', '07-553-4000'),
('Universiti Putra Malaysia', 'Serdang, Selangor', 'Prof. Raj Kumar', 'raj.kumar@upm.edu.my', '03-9769-1000');

-- Insert Default Manager User
INSERT INTO Users (Username, Email, Password, UserRole, FirstName, LastName, PhoneNumber) VALUES
('admin', 'admin@cozifitness.com', 'admin123', 'Manager', 'System', 'Administrator', '03-1234-5678');

-- Insert Sample Reception Staff
INSERT INTO Users (Username, Email, Password, UserRole, FirstName, LastName, PhoneNumber) VALUES
('reception1', 'reception1@cozifitness.com', 'rec123', 'Reception', 'Sarah', 'Johnson', '03-1234-5679'),
('reception2', 'reception2@cozifitness.com', 'rec123', 'Reception', 'Ahmad', 'Hassan', '03-1234-5680');

-- Insert Sample Maintenance Staff
INSERT INTO Users (Username, Email, Password, UserRole, FirstName, LastName, PhoneNumber) VALUES
('maintenance1', 'maint1@cozifitness.com', 'maint123', 'MaintenanceStaff', 'John', 'Smith', '03-1234-5681'),
('maintenance2', 'maint2@cozifitness.com', 'maint123', 'MaintenanceStaff', 'Ali', 'Abdullah', '03-1234-5682');

-- Insert Sample Students
INSERT INTO Users (Username, Email, Password, UserRole, FirstName, LastName, PhoneNumber) VALUES
('student1', 'student1@student.apu.edu.my', 'stud123', 'Student', 'Emily', 'Chen', '012-345-6789'),
('student2', 'student2@student.um.edu.my', 'stud123', 'Student', 'Michael', 'Tan', '012-345-6790'),
('student3', 'student3@student.utm.my', 'stud123', 'Student', 'Priya', 'Sharma', '012-345-6791');

-- Insert Sample Facilities
INSERT INTO Facilities (FacilityCode, FacilityName, FacilityTypeID, UniversityID, Location, Capacity, HourlyRate, Description) VALUES
('APU-GYM-01', 'APU Main Gymnasium', 1, 1, 'Block A, Level 1', 50, 25.00, 'Main gymnasium with basketball and volleyball courts'),
('APU-POOL-01', 'APU Swimming Pool', 2, 1, 'Block B, Ground Floor', 30, 30.00, 'Olympic-size swimming pool with diving board'),
('UM-TENNIS-01', 'UM Tennis Court 1', 3, 2, 'Sports Complex', 4, 20.00, 'Outdoor tennis court with night lighting'),
('UM-FITNESS-01', 'UM Fitness Center', 5, 2, 'Sports Complex, Level 2', 25, 15.00, 'Modern fitness center with cardio and weight equipment'),
('UTM-FIELD-01', 'UTM Football Field', 4, 3, 'Sports Ground', 22, 40.00, 'Full-size football field with artificial turf'),
('UPM-BADMINTON-01', 'UPM Badminton Hall', 6, 4, 'Sports Hall', 16, 18.00, 'Indoor badminton hall with 4 courts');

-- Insert Cleaning Supplies
INSERT INTO CleaningSupplies (SupplyName, CurrentStock, MinimumStock, Unit) VALUES
('Floor Cleaner', 50, 10, 'Bottles'),
('Disinfectant Spray', 30, 15, 'Bottles'),
('Toilet Paper', 100, 20, 'Rolls'),
('Paper Towels', 75, 25, 'Rolls'),
('Bleach', 20, 5, 'Bottles'),
('Glass Cleaner', 25, 8, 'Bottles'),
('Mop Heads', 15, 5, 'Pieces'),
('Vacuum Bags', 40, 10, 'Pieces');
