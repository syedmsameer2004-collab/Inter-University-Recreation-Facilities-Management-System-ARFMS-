using ARFMS.Forms;
using ARFMS_System;

namespace ARFMS
{
    internal static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // Test database connection
            if (!DatabaseConnection.TestConnection())
            {
                MessageBox.Show("Unable to connect to database. Please check your connection settings.",
                              "Database Connection Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Start with login form
            Application.Run(new LoginForm());
        }
    }
}
