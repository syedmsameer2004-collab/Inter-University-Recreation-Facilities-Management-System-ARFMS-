using ARFMS_System;
using ARFMS_System.Models;

namespace ARFMS.Services
{
    public class AuthenticationService
    {
        private UserRepository userRepository;
        private static User currentUser;

        public AuthenticationService()
        {
            userRepository = new UserRepository();
        }

        // Property to get current logged-in user
        public static User CurrentUser
        {
            get { return currentUser; }
            private set { currentUser = value; }
        }

        // Method to login user
        public bool Login(string username, string password)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
                {
                    return false;
                }

                User user = userRepository.AuthenticateUser(username, password);

                if (user != null)
                {
                    CurrentUser = user;
                    userRepository.UpdateLastLogin(user.UserID);
                    return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                throw new Exception($"Login failed: {ex.Message}");
            }
        }

        // Method to logout user
        public void Logout()
        {
            CurrentUser = null;
        }

        // Method to check if user is logged in
        public static bool IsLoggedIn()
        {
            return CurrentUser != null;
        }

        // Method to check if current user has specific role
        public static bool HasRole(UserRole role)
        {
            return IsLoggedIn() && CurrentUser.UserRole == role;
        }

        // Method to check if current user is Manager
        public static bool IsManager()
        {
            return HasRole(UserRole.Manager);
        }

        // Method to check if current user is Reception
        public static bool IsReception()
        {
            return HasRole(UserRole.Reception);
        }

        // Method to check if current user is Student
        public static bool IsStudent()
        {
            return HasRole(UserRole.Student);
        }

        // Method to check if current user is Maintenance Staff
        public static bool IsMaintenanceStaff()
        {
            return HasRole(UserRole.MaintenanceStaff);
        }

        // Method to get user's full name
        public static string GetCurrentUserFullName()
        {
            return IsLoggedIn() ? CurrentUser.FullName : "Guest";
        }

        // Method to validate password strength
        public static bool IsValidPassword(string password)
        {
            if (string.IsNullOrWhiteSpace(password))
                return false;

            // Basic password validation - at least 6 characters
            return password.Length >= 6;
        }

        // Method to hash password (simple implementation - use proper hashing in production)
        public static string HashPassword(string password)
        {
            // In production, use BCrypt or similar secure hashing
            // This is a simple implementation for demonstration
            return password; // For now, storing plain text (NOT recommended for production)
        }

        // Method to verify password
        public static bool VerifyPassword(string password, string hashedPassword)
        {
            // In production, use proper password verification
            return password == hashedPassword;
        }
    }
}
