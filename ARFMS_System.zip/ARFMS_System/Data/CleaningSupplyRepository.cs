using ARFMS_System.Models;
using Microsoft.Data.SqlClient; // Updated to use Microsoft.Data.SqlClient package

namespace ARFMS_System.Data // Added .Data namespace to match file location
{
    public class CleaningSupplyRepository
    {
        public CleaningSupplyRepository()
        {
        }

        public List<CleaningSupply> GetAllSupplies()
        {
            var supplies = new List<CleaningSupply>();
            string query = "SELECT * FROM CleaningSupplies ORDER BY SupplyName";

            using (var connection = DatabaseConnection.GetConnection())
            {
                using (var command = new SqlCommand(query, connection))
                {
                    connection.Open();
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            supplies.Add(MapReaderToCleaningSupply(reader));
                        }
                    }
                }
            }
            return supplies;
        }

        public List<SupplyRequest> GetSupplyRequestsByStaff(int staffId)
        {
            var requests = new List<SupplyRequest>();
            string query = @"SELECT sr.*, cs.SupplyName, cs.Unit 
                           FROM SupplyRequests sr
                           INNER JOIN CleaningSupplies cs ON sr.SupplyID = cs.SupplyID
                           WHERE sr.RequestedBy = @StaffId
                           ORDER BY sr.RequestDate DESC";

            using (var connection = DatabaseConnection.GetConnection())
            {
                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@StaffId", staffId);
                    connection.Open();
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            requests.Add(MapReaderToSupplyRequest(reader));
                        }
                    }
                }
            }
            return requests;
        }

        public bool AddSupplyRequest(SupplyRequest request)
        {
            string query = @"INSERT INTO SupplyRequests (SupplyID, RequestedBy, QuantityRequested, RequestDate, Status, Notes)
                           VALUES (@SupplyID, @RequestedBy, @QuantityRequested, @RequestDate, @Status, @Notes)";

            using (var connection = DatabaseConnection.GetConnection())
            {
                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@SupplyID", request.SupplyID);
                    command.Parameters.AddWithValue("@RequestedBy", request.RequestedBy);
                    command.Parameters.AddWithValue("@QuantityRequested", request.QuantityRequested);
                    command.Parameters.AddWithValue("@RequestDate", request.RequestDate);
                    command.Parameters.AddWithValue("@Status", request.Status.ToString());
                    command.Parameters.AddWithValue("@Notes", string.IsNullOrEmpty(request.Notes) ? (object)DBNull.Value : request.Notes);

                    connection.Open();
                    return command.ExecuteNonQuery() > 0;
                }
            }
        }

        public bool UpdateSupplyRequest(SupplyRequest request)
        {
            string query = @"UPDATE SupplyRequests 
                           SET SupplyID = @SupplyID, QuantityRequested = @QuantityRequested, Status = @Status, Notes = @Notes
                           WHERE SupplyRequestID = @SupplyRequestID";

            using (var connection = DatabaseConnection.GetConnection())
            {
                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@SupplyRequestID", request.SupplyRequestID);
                    command.Parameters.AddWithValue("@SupplyID", request.SupplyID);
                    command.Parameters.AddWithValue("@QuantityRequested", request.QuantityRequested);
                    command.Parameters.AddWithValue("@Status", request.Status.ToString());
                    command.Parameters.AddWithValue("@Notes", string.IsNullOrEmpty(request.Notes) ? (object)DBNull.Value : request.Notes);

                    connection.Open();
                    return command.ExecuteNonQuery() > 0;
                }
            }
        }

        public bool DeleteSupplyRequest(int requestId)
        {
            string query = "DELETE FROM SupplyRequests WHERE SupplyRequestID = @SupplyRequestID";

            using (var connection = DatabaseConnection.GetConnection())
            {
                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@SupplyRequestID", requestId);
                    connection.Open();
                    return command.ExecuteNonQuery() > 0;
                }
            }
        }

        // Added missing GetAllSupplyRequests method for manager approval
        public List<SupplyRequest> GetAllSupplyRequests()
        {
            var requests = new List<SupplyRequest>();
            string query = @"SELECT sr.*, cs.SupplyName, cs.Unit, u.FirstName, u.LastName
                           FROM SupplyRequests sr
                           INNER JOIN CleaningSupplies cs ON sr.SupplyID = cs.SupplyID
                           INNER JOIN Users u ON sr.RequestedBy = u.UserID
                           ORDER BY sr.RequestDate DESC";

            try
            {
                using (var connection = DatabaseConnection.GetConnection())
                {
                    using (var command = new SqlCommand(query, connection))
                    {
                        connection.Open();
                        using (var reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                var request = MapReaderToSupplyRequest(reader);

                                var firstName = reader["FirstName"]?.ToString() ?? "";
                                var lastName = reader["LastName"]?.ToString() ?? "";

                                request.RequestedByUser = new User
                                {
                                    FirstName = firstName,
                                    LastName = lastName
                                };

                                requests.Add(request);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Error loading supply requests from database: {ex.Message}. Query: {query}", ex);
            }

            return requests;
        }

        // Added missing UpdateSupplyRequestStatus method for manager approval/rejection
        public bool UpdateSupplyRequestStatus(int requestId, RequestStatus status)
        {
            string query = @"UPDATE SupplyRequests 
                           SET Status = @Status
                           WHERE SupplyRequestID = @SupplyRequestID";

            using (var connection = DatabaseConnection.GetConnection())
            {
                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@SupplyRequestID", requestId);
                    command.Parameters.AddWithValue("@Status", status.ToString());

                    connection.Open();
                    return command.ExecuteNonQuery() > 0;
                }
            }
        }

        private CleaningSupply MapReaderToCleaningSupply(SqlDataReader reader)
        {
            return new CleaningSupply
            {
                SupplyID = Convert.ToInt32(reader["SupplyID"]),
                SupplyName = reader["SupplyName"].ToString(),
                Unit = reader["Unit"].ToString(),
                CurrentStock = Convert.ToInt32(reader["CurrentStock"]),
                MinimumStock = Convert.ToInt32(reader["MinimumStock"])
            };
        }

        private SupplyRequest MapReaderToSupplyRequest(SqlDataReader reader)
        {
            try
            {
                var request = new SupplyRequest
                {
                    SupplyRequestID = Convert.ToInt32(reader["SupplyRequestID"]),
                    SupplyID = Convert.ToInt32(reader["SupplyID"]),
                    RequestedBy = Convert.ToInt32(reader["RequestedBy"]),
                    QuantityRequested = Convert.ToInt32(reader["QuantityRequested"]),
                    RequestDate = Convert.ToDateTime(reader["RequestDate"]),
                    Status = Enum.TryParse<RequestStatus>(reader["Status"]?.ToString(), out var status) ? status : RequestStatus.Pending,
                    Notes = reader["Notes"]?.ToString()
                };

                request.Supply = new CleaningSupply
                {
                    SupplyName = reader["SupplyName"]?.ToString() ?? "Unknown Supply",
                    Unit = reader["Unit"]?.ToString() ?? "Unit"
                };

                return request;
            }
            catch (Exception ex)
            {
                throw new Exception($"Error mapping supply request data: {ex.Message}. Check database schema and data types.", ex);
            }
        }
    }
}
