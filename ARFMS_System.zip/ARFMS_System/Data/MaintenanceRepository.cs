using ARFMS_System.Models;
using Microsoft.Data.SqlClient; // Updated to use Microsoft.Data.SqlClient package

namespace ARFMS_System
{
    public class MaintenanceRepository
    {
        // Method to get all maintenance schedules
        public List<MaintenanceSchedule> GetAllMaintenanceSchedules()
        {
            List<MaintenanceSchedule> schedules = new List<MaintenanceSchedule>();
            string query = @"SELECT ms.ScheduleID, ms.FacilityID, ms.MaintenanceStaffID, ms.ScheduledDate, 
                           ms.ScheduledTime, ms.MaintenanceType, ms.Description, ms.Status, ms.AssignedBy, 
                           ms.CreatedDate, ms.CompletedDate, ms.Notes,
                           f.FacilityName, u1.FirstName + ' ' + u1.LastName AS StaffName,
                           u2.FirstName + ' ' + u2.LastName AS AssignedByName
                           FROM MaintenanceSchedules ms
                           INNER JOIN Facilities f ON ms.FacilityID = f.FacilityID
                           INNER JOIN Users u1 ON ms.MaintenanceStaffID = u1.UserID
                           INNER JOIN Users u2 ON ms.AssignedBy = u2.UserID
                           WHERE ms.IsActive = 1";

            try
            {
                using (SqlConnection connection = DatabaseConnection.GetConnection())
                {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                schedules.Add(MapReaderToMaintenanceSchedule(reader));
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Error getting maintenance schedules: {ex.Message}");
            }

            return schedules;
        }

        // Method to add maintenance schedule
        public int AddMaintenanceSchedule(MaintenanceSchedule schedule)
        {
            string query = @"INSERT INTO MaintenanceSchedules (FacilityID, MaintenanceStaffID, ScheduledDate, 
                           ScheduledTime, MaintenanceType, Description, Status, AssignedBy) 
                           VALUES (@FacilityID, @MaintenanceStaffID, @ScheduledDate, @ScheduledTime, 
                           @MaintenanceType, @Description, @Status, @AssignedBy);
                           SELECT SCOPE_IDENTITY();";

            SqlParameter[] parameters = {
                new SqlParameter("@FacilityID", schedule.FacilityID),
                new SqlParameter("@MaintenanceStaffID", schedule.MaintenanceStaffID),
                new SqlParameter("@ScheduledDate", schedule.ScheduledDate),
                new SqlParameter("@ScheduledTime", schedule.ScheduledTime),
                new SqlParameter("@MaintenanceType", schedule.MaintenanceType),
                new SqlParameter("@Description", string.IsNullOrEmpty(schedule.Description) ? (object)DBNull.Value : schedule.Description),
                new SqlParameter("@Status", schedule.Status.ToString()),
                new SqlParameter("@AssignedBy", schedule.AssignedBy)
            };

            object result = DatabaseConnection.ExecuteScalar(query, parameters);
            return Convert.ToInt32(result);
        }

        // Method to get all equipment requests
        public List<EquipmentRequest> GetAllEquipmentRequests()
        {
            List<EquipmentRequest> requests = new List<EquipmentRequest>();
            string query = @"SELECT er.RequestID, er.FacilityID, er.RequestedBy, er.RequestType, er.ItemName, 
                           er.Description, er.Quantity, er.EstimatedCost, er.Priority, er.Status, 
                           er.RequestDate, er.ApprovedBy, er.ApprovalDate, er.CompletedDate, er.ApprovalNotes,
                           f.FacilityName, u1.FirstName + ' ' + u1.LastName AS RequestedByName,
                           u2.FirstName + ' ' + u2.LastName AS ApprovedByName
                           FROM EquipmentRequests er
                           INNER JOIN Facilities f ON er.FacilityID = f.FacilityID
                           INNER JOIN Users u1 ON er.RequestedBy = u1.UserID
                           LEFT JOIN Users u2 ON er.ApprovedBy = u2.UserID
                           WHERE er.IsActive = 1";

            try
            {
                using (SqlConnection connection = DatabaseConnection.GetConnection())
                {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                requests.Add(MapReaderToEquipmentRequest(reader));
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Error getting equipment requests: {ex.Message}");
            }

            return requests;
        }

        // Method to approve equipment request
        public void ApproveEquipmentRequest(int requestId, int managerId, string notes)
        {
            string query = @"UPDATE EquipmentRequests SET Status = @Status, ApprovedBy = @ApprovedBy, 
                           ApprovalDate = @ApprovalDate, ApprovalNotes = @ApprovalNotes 
                           WHERE RequestID = @RequestID";

            SqlParameter[] parameters = {
                new SqlParameter("@Status", RequestStatus.Approved.ToString()),
                new SqlParameter("@ApprovedBy", managerId),
                new SqlParameter("@ApprovalDate", DateTime.Now),
                new SqlParameter("@ApprovalNotes", string.IsNullOrEmpty(notes) ? (object)DBNull.Value : notes),
                new SqlParameter("@RequestID", requestId)
            };

            DatabaseConnection.ExecuteNonQuery(query, parameters);
        }

        // Method to reject equipment request
        public void RejectEquipmentRequest(int requestId, int managerId, string notes)
        {
            string query = @"UPDATE EquipmentRequests SET Status = @Status, ApprovedBy = @ApprovedBy, 
                           ApprovalDate = @ApprovalDate, ApprovalNotes = @ApprovalNotes 
                           WHERE RequestID = @RequestID";

            SqlParameter[] parameters = {
                new SqlParameter("@Status", RequestStatus.Rejected.ToString()),
                new SqlParameter("@ApprovedBy", managerId),
                new SqlParameter("@ApprovalDate", DateTime.Now),
                new SqlParameter("@ApprovalNotes", notes),
                new SqlParameter("@RequestID", requestId)
            };

            DatabaseConnection.ExecuteNonQuery(query, parameters);
        }

        // Method to add equipment request
        public int AddEquipmentRequest(EquipmentRequest request)
        {
            string query = @"INSERT INTO EquipmentRequests (FacilityID, RequestedBy, RequestType, ItemName, 
                           Description, Quantity, EstimatedCost, Priority, Status, RequestDate) 
                           VALUES (@FacilityID, @RequestedBy, @RequestType, @ItemName, @Description, 
                           @Quantity, @EstimatedCost, @Priority, @Status, @RequestDate);
                           SELECT SCOPE_IDENTITY();";

            SqlParameter[] parameters = {
                new SqlParameter("@FacilityID", request.FacilityID),
                new SqlParameter("@RequestedBy", request.RequestedBy),
                new SqlParameter("@RequestType", request.RequestType.ToString()),
                new SqlParameter("@ItemName", request.ItemName),
                new SqlParameter("@Description", string.IsNullOrEmpty(request.Description) ? (object)DBNull.Value : request.Description),
                new SqlParameter("@Quantity", request.Quantity),
                new SqlParameter("@EstimatedCost", request.EstimatedCost.HasValue ? (object)request.EstimatedCost.Value : DBNull.Value),
                new SqlParameter("@Priority", request.Priority.ToString()),
                new SqlParameter("@Status", request.Status.ToString()),
                new SqlParameter("@RequestDate", request.RequestDate)
            };

            object result = DatabaseConnection.ExecuteScalar(query, parameters);
            return Convert.ToInt32(result);
        }

        public List<MaintenanceSchedule> GetSchedulesByStaff(int staffId)
        {
            List<MaintenanceSchedule> schedules = new List<MaintenanceSchedule>();
            string query = @"SELECT ms.ScheduleID, ms.FacilityID, ms.MaintenanceStaffID, ms.ScheduledDate, 
                           ms.ScheduledTime, ms.MaintenanceType, ms.Description, ms.Status, ms.AssignedBy, 
                           ms.CreatedDate, ms.CompletedDate, ms.Notes,
                           f.FacilityName, u1.FirstName + ' ' + u1.LastName AS StaffName,
                           u2.FirstName + ' ' + u2.LastName AS AssignedByName
                           FROM MaintenanceSchedules ms
                           INNER JOIN Facilities f ON ms.FacilityID = f.FacilityID
                           INNER JOIN Users u1 ON ms.MaintenanceStaffID = u1.UserID
                           INNER JOIN Users u2 ON ms.AssignedBy = u2.UserID
                           WHERE ms.IsActive = 1 AND ms.MaintenanceStaffID = @StaffID
                           ORDER BY ms.ScheduledDate, ms.ScheduledTime";

            try
            {
                using (SqlConnection connection = DatabaseConnection.GetConnection())
                {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@StaffID", staffId);

                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                schedules.Add(MapReaderToMaintenanceSchedule(reader));
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Error getting schedules by staff: {ex.Message}");
            }

            return schedules;
        }

        // Helper methods
        private MaintenanceSchedule MapReaderToMaintenanceSchedule(SqlDataReader reader)
        {
            return new MaintenanceSchedule
            {
                ScheduleID = Convert.ToInt32(reader["ScheduleID"]),
                FacilityID = Convert.ToInt32(reader["FacilityID"]),
                MaintenanceStaffID = Convert.ToInt32(reader["MaintenanceStaffID"]),
                ScheduledDate = Convert.ToDateTime(reader["ScheduledDate"]),
                ScheduledTime = (TimeSpan)reader["ScheduledTime"],
                MaintenanceType = reader["MaintenanceType"].ToString(),
                Description = reader["Description"]?.ToString(),
                Status = (MaintenanceStatus)Enum.Parse(typeof(MaintenanceStatus), reader["Status"].ToString()),
                AssignedBy = Convert.ToInt32(reader["AssignedBy"]),
                CreatedDate = Convert.ToDateTime(reader["CreatedDate"]),
                CompletedDate = reader["CompletedDate"] == DBNull.Value ? null : (DateTime?)reader["CompletedDate"],
                Notes = reader["Notes"]?.ToString(),
                Facility = new Facility { FacilityName = reader["FacilityName"].ToString() },
                MaintenanceStaff = new User { FullName = reader["StaffName"].ToString() },
                AssignedByUser = new User { FullName = reader["AssignedByName"].ToString() }
            };
        }

        private EquipmentRequest MapReaderToEquipmentRequest(SqlDataReader reader)
        {
            return new EquipmentRequest
            {
                RequestID = Convert.ToInt32(reader["RequestID"]),
                FacilityID = Convert.ToInt32(reader["FacilityID"]),
                RequestedBy = Convert.ToInt32(reader["RequestedBy"]),
                RequestType = (RequestType)Enum.Parse(typeof(RequestType), reader["RequestType"].ToString()),
                ItemName = reader["ItemName"].ToString(),
                Description = reader["Description"]?.ToString(),
                Quantity = Convert.ToInt32(reader["Quantity"]),
                EstimatedCost = reader["EstimatedCost"] == DBNull.Value ? null : (decimal?)reader["EstimatedCost"],
                Priority = (Priority)Enum.Parse(typeof(Priority), reader["Priority"].ToString()),
                Status = (RequestStatus)Enum.Parse(typeof(RequestStatus), reader["Status"].ToString()),
                RequestDate = Convert.ToDateTime(reader["RequestDate"]),
                ApprovedBy = reader["ApprovedBy"] == DBNull.Value ? null : (int?)reader["ApprovedBy"],
                ApprovalDate = reader["ApprovalDate"] == DBNull.Value ? null : (DateTime?)reader["ApprovalDate"],
                CompletedDate = reader["CompletedDate"] == DBNull.Value ? null : (DateTime?)reader["CompletedDate"],
                ApprovalNotes = reader["ApprovalNotes"]?.ToString(),
                Facility = new Facility { FacilityName = reader["FacilityName"].ToString() },
                RequestedByUser = new User { FullName = reader["RequestedByName"].ToString() },
                ApprovedByUser = reader["ApprovedByName"] == DBNull.Value ? null : new User { FullName = reader["ApprovedByName"].ToString() }
            };
        }
    }
}
