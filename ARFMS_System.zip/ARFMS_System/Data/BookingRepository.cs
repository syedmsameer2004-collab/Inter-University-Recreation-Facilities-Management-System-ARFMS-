using ARFMS_System.Models;
using Microsoft.Data.SqlClient; // Updated to use Microsoft.Data.SqlClient package

namespace ARFMS_System
{
    public class BookingRepository
    {
        // Method to get all bookings
        public List<Booking> GetAllBookings()
        {
            List<Booking> bookings = new List<Booking>();
            string query = @"SELECT b.BookingID, b.StudentID, b.FacilityID, b.BookingDate, b.StartTime, 
                           b.EndTime, b.TotalAmount, b.BookingStatus, b.PaymentStatus, b.CreatedBy, 
                           b.CreatedDate, b.Notes,
                           s.FirstName + ' ' + s.LastName AS StudentName, s.Email AS StudentEmail,
                           f.FacilityName, f.FacilityCode, f.HourlyRate,
                           r.FirstName + ' ' + r.LastName AS CreatedByName
                           FROM Bookings b
                           INNER JOIN Users s ON b.StudentID = s.UserID
                           INNER JOIN Facilities f ON b.FacilityID = f.FacilityID
                           LEFT JOIN Users r ON b.CreatedBy = r.UserID
                           ORDER BY b.CreatedDate DESC";

            try
            {
                using (SqlConnection connection = DatabaseConnection.GetConnection())
                {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                bookings.Add(MapReaderToBooking(reader));
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Error getting bookings: {ex.Message}");
            }

            return bookings;
        }

        // Method to search bookings by student name or facility code
        public List<Booking> SearchBookings(string searchTerm)
        {
            List<Booking> bookings = new List<Booking>();
            string query = @"SELECT b.BookingID, b.StudentID, b.FacilityID, b.BookingDate, b.StartTime, 
                           b.EndTime, b.TotalAmount, b.BookingStatus, b.PaymentStatus, b.CreatedBy, 
                           b.CreatedDate, b.Notes,
                           s.FirstName + ' ' + s.LastName AS StudentName, s.Email AS StudentEmail,
                           f.FacilityName, f.FacilityCode, f.HourlyRate,
                           r.FirstName + ' ' + r.LastName AS CreatedByName
                           FROM Bookings b
                           INNER JOIN Users s ON b.StudentID = s.UserID
                           INNER JOIN Facilities f ON b.FacilityID = f.FacilityID
                           LEFT JOIN Users r ON b.CreatedBy = r.UserID
                           WHERE (s.FirstName + ' ' + s.LastName LIKE @SearchTerm 
                           OR f.FacilityCode LIKE @SearchTerm 
                           OR f.FacilityName LIKE @SearchTerm)
                           ORDER BY b.CreatedDate DESC";

            try
            {
                using (SqlConnection connection = DatabaseConnection.GetConnection())
                {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@SearchTerm", $"%{searchTerm}%");

                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                bookings.Add(MapReaderToBooking(reader));
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Error searching bookings: {ex.Message}");
            }

            return bookings;
        }

        // Method to add booking
        public int AddBooking(Booking booking)
        {
            string query = @"INSERT INTO Bookings (StudentID, FacilityID, BookingDate, StartTime, EndTime, 
                           TotalAmount, BookingStatus, PaymentStatus, CreatedBy, Notes) 
                           VALUES (@StudentID, @FacilityID, @BookingDate, @StartTime, @EndTime, 
                           @TotalAmount, @BookingStatus, @PaymentStatus, @CreatedBy, @Notes);
                           SELECT SCOPE_IDENTITY();";

            SqlParameter[] parameters = {
                new SqlParameter("@StudentID", booking.StudentID),
                new SqlParameter("@FacilityID", booking.FacilityID),
                new SqlParameter("@BookingDate", booking.BookingDate),
                new SqlParameter("@StartTime", booking.StartTime),
                new SqlParameter("@EndTime", booking.EndTime),
                new SqlParameter("@TotalAmount", booking.TotalAmount),
                new SqlParameter("@BookingStatus", booking.BookingStatus.ToString()),
                new SqlParameter("@PaymentStatus", booking.PaymentStatus.ToString()),
                new SqlParameter("@CreatedBy", booking.CreatedBy.HasValue ? (object)booking.CreatedBy.Value : DBNull.Value),
                new SqlParameter("@Notes", string.IsNullOrEmpty(booking.Notes) ? (object)DBNull.Value : booking.Notes)
            };

            object result = DatabaseConnection.ExecuteScalar(query, parameters);
            return Convert.ToInt32(result);
        }

        // Method to update booking
        public void UpdateBooking(Booking booking)
        {
            string query = @"UPDATE Bookings SET StudentID = @StudentID, FacilityID = @FacilityID, 
                           BookingDate = @BookingDate, StartTime = @StartTime, EndTime = @EndTime, 
                           TotalAmount = @TotalAmount, BookingStatus = @BookingStatus, 
                           PaymentStatus = @PaymentStatus, Notes = @Notes 
                           WHERE BookingID = @BookingID";

            SqlParameter[] parameters = {
                new SqlParameter("@StudentID", booking.StudentID),
                new SqlParameter("@FacilityID", booking.FacilityID),
                new SqlParameter("@BookingDate", booking.BookingDate),
                new SqlParameter("@StartTime", booking.StartTime),
                new SqlParameter("@EndTime", booking.EndTime),
                new SqlParameter("@TotalAmount", booking.TotalAmount),
                new SqlParameter("@BookingStatus", booking.BookingStatus.ToString()),
                new SqlParameter("@PaymentStatus", booking.PaymentStatus.ToString()),
                new SqlParameter("@Notes", string.IsNullOrEmpty(booking.Notes) ? (object)DBNull.Value : booking.Notes),
                new SqlParameter("@BookingID", booking.BookingID)
            };

            DatabaseConnection.ExecuteNonQuery(query, parameters);
        }

        // Method to check facility availability
        public bool IsFacilityAvailable(int facilityId, DateTime bookingDate, TimeSpan startTime, TimeSpan endTime, int? excludeBookingId = null)
        {
            string query = @"SELECT COUNT(*) FROM Bookings 
                           WHERE FacilityID = @FacilityID 
                           AND BookingDate = @BookingDate 
                           AND BookingStatus IN ('Pending', 'Confirmed')
                           AND ((@StartTime >= StartTime AND @StartTime < EndTime) 
                           OR (@EndTime > StartTime AND @EndTime <= EndTime)
                           OR (@StartTime <= StartTime AND @EndTime >= EndTime))";

            if (excludeBookingId.HasValue)
            {
                query += " AND BookingID != @ExcludeBookingID";
            }

            try
            {
                using (SqlConnection connection = DatabaseConnection.GetConnection())
                {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@FacilityID", facilityId);
                        command.Parameters.AddWithValue("@BookingDate", bookingDate);
                        command.Parameters.AddWithValue("@StartTime", startTime);
                        command.Parameters.AddWithValue("@EndTime", endTime);

                        if (excludeBookingId.HasValue)
                        {
                            command.Parameters.AddWithValue("@ExcludeBookingID", excludeBookingId.Value);
                        }

                        int count = Convert.ToInt32(command.ExecuteScalar());
                        return count == 0;
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Error checking facility availability: {ex.Message}");
            }
        }

        public List<Booking> GetBookingsByStudent(int studentId)
        {
            List<Booking> bookings = new List<Booking>();
            string query = @"SELECT b.BookingID, b.StudentID, b.FacilityID, b.BookingDate, b.StartTime, 
                           b.EndTime, b.TotalAmount, b.BookingStatus, b.PaymentStatus, b.CreatedBy, 
                           b.CreatedDate, b.Notes,
                           s.FirstName + ' ' + s.LastName AS StudentName, s.Email AS StudentEmail,
                           f.FacilityName, f.FacilityCode, f.HourlyRate,
                           r.FirstName + ' ' + r.LastName AS CreatedByName
                           FROM Bookings b
                           INNER JOIN Users s ON b.StudentID = s.UserID
                           INNER JOIN Facilities f ON b.FacilityID = f.FacilityID
                           LEFT JOIN Users r ON b.CreatedBy = r.UserID
                           WHERE b.StudentID = @StudentID
                           ORDER BY b.CreatedDate DESC";

            try
            {
                using (SqlConnection connection = DatabaseConnection.GetConnection())
                {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@StudentID", studentId);

                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                bookings.Add(MapReaderToBooking(reader));
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Error getting student bookings: {ex.Message}");
            }

            return bookings;
        }

        public void UpdateBookingStatus(int bookingId, BookingStatus status)
        {
            string query = "UPDATE Bookings SET BookingStatus = @BookingStatus WHERE BookingID = @BookingID";

            SqlParameter[] parameters = {
                new SqlParameter("@BookingStatus", status.ToString()),
                new SqlParameter("@BookingID", bookingId)
            };

            DatabaseConnection.ExecuteNonQuery(query, parameters);
        }

        public List<Booking> GetBookingsByStatus(BookingStatus status)
        {
            List<Booking> bookings = new List<Booking>();
            string query = @"SELECT b.BookingID, b.StudentID, b.FacilityID, b.BookingDate, b.StartTime, 
                           b.EndTime, b.TotalAmount, b.BookingStatus, b.PaymentStatus, b.CreatedBy, 
                           b.CreatedDate, b.Notes,
                           s.FirstName + ' ' + s.LastName AS StudentName, s.Email AS StudentEmail,
                           f.FacilityName, f.FacilityCode, f.HourlyRate,
                           r.FirstName + ' ' + r.LastName AS CreatedByName
                           FROM Bookings b
                           INNER JOIN Users s ON b.StudentID = s.UserID
                           INNER JOIN Facilities f ON b.FacilityID = f.FacilityID
                           LEFT JOIN Users r ON b.CreatedBy = r.UserID
                           WHERE b.BookingStatus = @BookingStatus
                           ORDER BY b.CreatedDate DESC";

            try
            {
                using (SqlConnection connection = DatabaseConnection.GetConnection())
                {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@BookingStatus", status.ToString());

                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                bookings.Add(MapReaderToBooking(reader));
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Error getting bookings by status: {ex.Message}");
            }

            return bookings;
        }

        // Helper method to map SqlDataReader to Booking object
        private Booking MapReaderToBooking(SqlDataReader reader)
        {
            return new Booking
            {
                BookingID = Convert.ToInt32(reader["BookingID"]),
                StudentID = Convert.ToInt32(reader["StudentID"]),
                FacilityID = Convert.ToInt32(reader["FacilityID"]),
                BookingDate = Convert.ToDateTime(reader["BookingDate"]),
                StartTime = (TimeSpan)reader["StartTime"],
                EndTime = (TimeSpan)reader["EndTime"],
                TotalAmount = Convert.ToDecimal(reader["TotalAmount"]),
                BookingStatus = (BookingStatus)Enum.Parse(typeof(BookingStatus), reader["BookingStatus"].ToString()),
                PaymentStatus = (PaymentStatus)Enum.Parse(typeof(PaymentStatus), reader["PaymentStatus"].ToString()),
                CreatedBy = reader["CreatedBy"] == DBNull.Value ? null : (int?)reader["CreatedBy"],
                CreatedDate = Convert.ToDateTime(reader["CreatedDate"]),
                Notes = reader["Notes"]?.ToString(),
                Student = new User { FullName = reader["StudentName"].ToString(), Email = reader["StudentEmail"].ToString() },
                Facility = new Facility
                {
                    FacilityName = reader["FacilityName"].ToString(),
                    FacilityCode = reader["FacilityCode"].ToString(),
                    HourlyRate = Convert.ToDecimal(reader["HourlyRate"])
                },
                CreatedByUser = reader["CreatedByName"] == DBNull.Value ? null : new User { FullName = reader["CreatedByName"].ToString() }
            };
        }
    }
}
