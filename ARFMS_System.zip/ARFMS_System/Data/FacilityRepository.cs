using ARFMS_System.Models;
using Microsoft.Data.SqlClient; // Updated to use Microsoft.Data.SqlClient package

namespace ARFMS_System
{
    public class FacilityRepository
    {
        // Method to get all facilities
        public List<Facility> GetAllFacilities()
        {
            List<Facility> facilities = new List<Facility>();
            string query = @"SELECT f.FacilityID, f.FacilityCode, f.FacilityName, f.FacilityTypeID, 
                           f.UniversityID, f.Location, f.Capacity, f.HourlyRate, f.Description, 
                           f.IsAvailable, f.CreatedDate, ft.TypeName, u.UniversityName
                           FROM Facilities f
                           INNER JOIN FacilityTypes ft ON f.FacilityTypeID = ft.FacilityTypeID
                           INNER JOIN Universities u ON f.UniversityID = u.UniversityID
                           WHERE f.IsActive = 1";

            try
            {
                using (SqlConnection connection = DatabaseConnection.GetConnection())
                {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                facilities.Add(MapReaderToFacility(reader));
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Error getting facilities: {ex.Message}");
            }

            return facilities;
        }

        // Method to add facility
        public int AddFacility(Facility facility)
        {
            string query = @"INSERT INTO Facilities (FacilityCode, FacilityName, FacilityTypeID, UniversityID, 
                           Location, Capacity, HourlyRate, Description, IsAvailable) 
                           VALUES (@FacilityCode, @FacilityName, @FacilityTypeID, @UniversityID, 
                           @Location, @Capacity, @HourlyRate, @Description, @IsAvailable);
                           SELECT SCOPE_IDENTITY();";

            SqlParameter[] parameters = {
                new SqlParameter("@FacilityCode", facility.FacilityCode),
                new SqlParameter("@FacilityName", facility.FacilityName),
                new SqlParameter("@FacilityTypeID", facility.FacilityTypeID),
                new SqlParameter("@UniversityID", facility.UniversityID),
                new SqlParameter("@Location", string.IsNullOrEmpty(facility.Location) ? (object)DBNull.Value : facility.Location),
                new SqlParameter("@Capacity", facility.Capacity),
                new SqlParameter("@HourlyRate", facility.HourlyRate),
                new SqlParameter("@Description", string.IsNullOrEmpty(facility.Description) ? (object)DBNull.Value : facility.Description),
                new SqlParameter("@IsAvailable", facility.IsAvailable)
            };

            object result = DatabaseConnection.ExecuteScalar(query, parameters);
            return Convert.ToInt32(result);
        }

        // Method to update facility
        public void UpdateFacility(Facility facility)
        {
            string query = @"UPDATE Facilities SET FacilityCode = @FacilityCode, FacilityName = @FacilityName, 
                           FacilityTypeID = @FacilityTypeID, UniversityID = @UniversityID, Location = @Location, 
                           Capacity = @Capacity, HourlyRate = @HourlyRate, Description = @Description, 
                           IsAvailable = @IsAvailable WHERE FacilityID = @FacilityID";

            SqlParameter[] parameters = {
                new SqlParameter("@FacilityCode", facility.FacilityCode),
                new SqlParameter("@FacilityName", facility.FacilityName),
                new SqlParameter("@FacilityTypeID", facility.FacilityTypeID),
                new SqlParameter("@UniversityID", facility.UniversityID),
                new SqlParameter("@Location", string.IsNullOrEmpty(facility.Location) ? (object)DBNull.Value : facility.Location),
                new SqlParameter("@Capacity", facility.Capacity),
                new SqlParameter("@HourlyRate", facility.HourlyRate),
                new SqlParameter("@Description", string.IsNullOrEmpty(facility.Description) ? (object)DBNull.Value : facility.Description),
                new SqlParameter("@IsAvailable", facility.IsAvailable),
                new SqlParameter("@FacilityID", facility.FacilityID)
            };

            DatabaseConnection.ExecuteNonQuery(query, parameters);
        }

        // Method to delete facility (soft delete)
        public void DeleteFacility(int facilityId)
        {
            string query = "UPDATE Facilities SET IsActive = 0 WHERE FacilityID = @FacilityID";

            SqlParameter[] parameters = {
                new SqlParameter("@FacilityID", facilityId)
            };

            DatabaseConnection.ExecuteNonQuery(query, parameters);
        }

        // Method to get all facility types
        public List<FacilityType> GetAllFacilityTypes()
        {
            List<FacilityType> facilityTypes = new List<FacilityType>();
            string query = "SELECT FacilityTypeID, TypeName, Description FROM FacilityTypes";

            try
            {
                using (SqlConnection connection = DatabaseConnection.GetConnection())
                {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                facilityTypes.Add(new FacilityType
                                {
                                    FacilityTypeID = Convert.ToInt32(reader["FacilityTypeID"]),
                                    TypeName = reader["TypeName"].ToString(),
                                    Description = reader["Description"]?.ToString()
                                });
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Error getting facility types: {ex.Message}");
            }

            return facilityTypes;
        }

        // Method to get all universities
        public List<University> GetAllUniversities()
        {
            List<University> universities = new List<University>();
            string query = @"SELECT UniversityID, UniversityName, Address, ContactPerson, 
                           ContactEmail, ContactPhone, IsActive, CreatedDate 
                           FROM Universities WHERE IsActive = 1";

            try
            {
                using (SqlConnection connection = DatabaseConnection.GetConnection())
                {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                universities.Add(new University
                                {
                                    UniversityID = Convert.ToInt32(reader["UniversityID"]),
                                    UniversityName = reader["UniversityName"].ToString(),
                                    Address = reader["Address"]?.ToString(),
                                    ContactPerson = reader["ContactPerson"]?.ToString(),
                                    ContactEmail = reader["ContactEmail"]?.ToString(),
                                    ContactPhone = reader["ContactPhone"]?.ToString(),
                                    IsActive = Convert.ToBoolean(reader["IsActive"]),
                                    CreatedDate = Convert.ToDateTime(reader["CreatedDate"])
                                });
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Error getting universities: {ex.Message}");
            }

            return universities;
        }

        // Helper method to map SqlDataReader to Facility object
        private Facility MapReaderToFacility(SqlDataReader reader)
        {
            return new Facility
            {
                FacilityID = Convert.ToInt32(reader["FacilityID"]),
                FacilityCode = reader["FacilityCode"].ToString(),
                FacilityName = reader["FacilityName"].ToString(),
                FacilityTypeID = Convert.ToInt32(reader["FacilityTypeID"]),
                UniversityID = Convert.ToInt32(reader["UniversityID"]),
                Location = reader["Location"]?.ToString(),
                Capacity = Convert.ToInt32(reader["Capacity"]),
                HourlyRate = Convert.ToDecimal(reader["HourlyRate"]),
                Description = reader["Description"]?.ToString(),
                IsAvailable = Convert.ToBoolean(reader["IsAvailable"]),
                CreatedDate = Convert.ToDateTime(reader["CreatedDate"]),
                FacilityType = new FacilityType { TypeName = reader["TypeName"].ToString() },
                University = new University { UniversityName = reader["UniversityName"].ToString() }
            };
        }
    }
}
