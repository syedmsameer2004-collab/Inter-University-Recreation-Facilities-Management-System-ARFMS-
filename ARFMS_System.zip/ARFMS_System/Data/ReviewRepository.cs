using ARFMS_System.Models;
using Microsoft.Data.SqlClient; // Updated to use Microsoft.Data.SqlClient package

namespace ARFMS_System
{
    public class ReviewRepository
    {
        // Method to get all reviews
        public List<Review> GetAllReviews()
        {
            List<Review> reviews = new List<Review>();
            string query = @"SELECT r.ReviewID, r.BookingID, r.StudentID, r.FacilityID, r.Rating, 
                           r.ReviewText, r.ReviewDate,
                           s.FirstName + ' ' + s.LastName AS StudentName,
                           f.FacilityName, f.FacilityCode
                           FROM Reviews r
                           INNER JOIN Users s ON r.StudentID = s.UserID
                           INNER JOIN Facilities f ON r.FacilityID = f.FacilityID
                           ORDER BY r.ReviewDate DESC";

            try
            {
                using (SqlConnection connection = DatabaseConnection.GetConnection())
                {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                reviews.Add(new Review
                                {
                                    // <CHANGE> Added DBNull checking for all fields to prevent casting exceptions
                                    ReviewID = reader["ReviewID"] == DBNull.Value ? 0 : Convert.ToInt32(reader["ReviewID"]),
                                    BookingID = reader["BookingID"] == DBNull.Value ? (int?)null : Convert.ToInt32(reader["BookingID"]),
                                    StudentID = reader["StudentID"] == DBNull.Value ? 0 : Convert.ToInt32(reader["StudentID"]),
                                    FacilityID = reader["FacilityID"] == DBNull.Value ? 0 : Convert.ToInt32(reader["FacilityID"]),
                                    Rating = reader["Rating"] == DBNull.Value ? 0 : Convert.ToInt32(reader["Rating"]),
                                    ReviewText = reader["ReviewText"] == DBNull.Value ? null : reader["ReviewText"].ToString(),
                                    ReviewDate = reader["ReviewDate"] == DBNull.Value ? DateTime.MinValue : Convert.ToDateTime(reader["ReviewDate"]),
                                    Student = new User { FullName = reader["StudentName"] == DBNull.Value ? "Unknown" : reader["StudentName"].ToString() },
                                    Facility = new Facility
                                    {
                                        FacilityName = reader["FacilityName"] == DBNull.Value ? "Unknown" : reader["FacilityName"].ToString(),
                                        FacilityCode = reader["FacilityCode"] == DBNull.Value ? "Unknown" : reader["FacilityCode"].ToString()
                                    }
                                });
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Error getting reviews: {ex.Message}");
            }

            return reviews;
        }

        // Method to get reviews by facility
        public List<Review> GetReviewsByFacility(int facilityId)
        {
            List<Review> reviews = new List<Review>();
            string query = @"SELECT r.ReviewID, r.BookingID, r.StudentID, r.FacilityID, r.Rating, 
                           r.ReviewText, r.ReviewDate,
                           s.FirstName + ' ' + s.LastName AS StudentName,
                           f.FacilityName, f.FacilityCode
                           FROM Reviews r
                           INNER JOIN Users s ON r.StudentID = s.UserID
                           INNER JOIN Facilities f ON r.FacilityID = f.FacilityID
                           WHERE r.FacilityID = @FacilityID
                           ORDER BY r.ReviewDate DESC";

            try
            {
                using (SqlConnection connection = DatabaseConnection.GetConnection())
                {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@FacilityID", facilityId);

                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                reviews.Add(new Review
                                {
                                    // <CHANGE> Added DBNull checking for all fields to prevent casting exceptions
                                    ReviewID = reader["ReviewID"] == DBNull.Value ? 0 : Convert.ToInt32(reader["ReviewID"]),
                                    BookingID = reader["BookingID"] == DBNull.Value ? (int?)null : Convert.ToInt32(reader["BookingID"]),
                                    StudentID = reader["StudentID"] == DBNull.Value ? 0 : Convert.ToInt32(reader["StudentID"]),
                                    FacilityID = reader["FacilityID"] == DBNull.Value ? 0 : Convert.ToInt32(reader["FacilityID"]),
                                    Rating = reader["Rating"] == DBNull.Value ? 0 : Convert.ToInt32(reader["Rating"]),
                                    ReviewText = reader["ReviewText"] == DBNull.Value ? null : reader["ReviewText"].ToString(),
                                    ReviewDate = reader["ReviewDate"] == DBNull.Value ? DateTime.MinValue : Convert.ToDateTime(reader["ReviewDate"]),
                                    Student = new User { FullName = reader["StudentName"] == DBNull.Value ? "Unknown" : reader["StudentName"].ToString() },
                                    Facility = new Facility
                                    {
                                        FacilityName = reader["FacilityName"] == DBNull.Value ? "Unknown" : reader["FacilityName"].ToString(),
                                        FacilityCode = reader["FacilityCode"] == DBNull.Value ? "Unknown" : reader["FacilityCode"].ToString()
                                    }
                                });
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Error getting facility reviews: {ex.Message}");
            }

            return reviews;
        }

        public int AddReview(Review review)
        {
            string validationQuery = @"SELECT COUNT(*) FROM Users WHERE UserID = @StudentID AND UserRole = 'Student';
                                     SELECT COUNT(*) FROM Facilities WHERE FacilityID = @FacilityID AND IsActive = 1;";

            try
            {
                using (SqlConnection connection = DatabaseConnection.GetConnection())
                {
                    connection.Open();

                    // Validate StudentID exists and is a student
                    using (SqlCommand validationCommand = new SqlCommand("SELECT COUNT(*) FROM Users WHERE UserID = @StudentID AND UserRole = 'Student'", connection))
                    {
                        validationCommand.Parameters.AddWithValue("@StudentID", review.StudentID);
                        int studentCount = (int)validationCommand.ExecuteScalar();
                        if (studentCount == 0)
                        {
                            throw new Exception("Invalid student ID or user is not a student.");
                        }
                    }

                    // Validate FacilityID exists and is active
                    using (SqlCommand facilityValidationCommand = new SqlCommand("SELECT COUNT(*) FROM Facilities WHERE FacilityID = @FacilityID AND IsActive = 1", connection))
                    {
                        facilityValidationCommand.Parameters.AddWithValue("@FacilityID", review.FacilityID);
                        int facilityCount = (int)facilityValidationCommand.ExecuteScalar();
                        if (facilityCount == 0)
                        {
                            throw new Exception("Invalid facility ID or facility is not active.");
                        }
                    }
                }

                // If validation passes, insert the review
                string query = @"INSERT INTO Reviews (BookingID, StudentID, FacilityID, Rating, ReviewText, ReviewDate) 
                               VALUES (@BookingID, @StudentID, @FacilityID, @Rating, @ReviewText, @ReviewDate);
                               SELECT SCOPE_IDENTITY();";

                SqlParameter[] parameters = {
                    new SqlParameter("@BookingID", review.BookingID.HasValue ? (object)review.BookingID.Value : DBNull.Value),
                    new SqlParameter("@StudentID", review.StudentID),
                    new SqlParameter("@FacilityID", review.FacilityID),
                    new SqlParameter("@Rating", review.Rating),
                    new SqlParameter("@ReviewText", string.IsNullOrEmpty(review.ReviewText) ? (object)DBNull.Value : review.ReviewText),
                    new SqlParameter("@ReviewDate", review.ReviewDate)
                };

                object result = DatabaseConnection.ExecuteScalar(query, parameters);
                return Convert.ToInt32(result);
            }
            catch (SqlException sqlEx)
            {
                if (sqlEx.Number == 547) // Foreign key constraint violation
                {
                    throw new Exception("Foreign key constraint violation. Please ensure all referenced records exist.");
                }
                throw new Exception($"Database error: {sqlEx.Message}");
            }
            catch (Exception ex)
            {
                throw new Exception($"Error adding review: {ex.Message}");
            }
        }
    }
}
