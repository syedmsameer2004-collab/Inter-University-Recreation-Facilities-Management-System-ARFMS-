using ARFMS_System.Models;
using Microsoft.Data.SqlClient; // Updated to use Microsoft.Data.SqlClient package

namespace ARFMS_System
{
    public class UserRepository
    {
        // Method to authenticate user
        public User AuthenticateUser(string username, string password)
        {
            string query = @"SELECT UserID, Username, Email, Password, UserRole, FirstName, LastName, 
                           PhoneNumber, IsActive, CreatedDate, LastLoginDate 
                           FROM Users 
                           WHERE (Username = @Username OR Email = @Username) AND IsActive = 1";

            try
            {
                using (SqlConnection connection = DatabaseConnection.GetConnection())
                {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Username", username);

                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                User user = MapReaderToUser(reader);

                                // Verify password (in production, use hashed passwords)
                                if (user.Password == password)
                                {
                                    return user;
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Error authenticating user: {ex.Message}");
            }

            return null; // Authentication failed
        }

        // Method to get user by ID
        public User GetUserById(int userId)
        {
            string query = @"SELECT UserID, Username, Email, Password, UserRole, FirstName, LastName, 
                           PhoneNumber, IsActive, CreatedDate, LastLoginDate 
                           FROM Users WHERE UserID = @UserID";

            try
            {
                using (SqlConnection connection = DatabaseConnection.GetConnection())
                {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@UserID", userId);

                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                return MapReaderToUser(reader);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Error getting user: {ex.Message}");
            }

            return null;
        }

        // Method to update last login date
        public void UpdateLastLogin(int userId)
        {
            string query = "UPDATE Users SET LastLoginDate = @LastLoginDate WHERE UserID = @UserID";

            SqlParameter[] parameters = {
                new SqlParameter("@LastLoginDate", DateTime.Now),
                new SqlParameter("@UserID", userId)
            };

            DatabaseConnection.ExecuteNonQuery(query, parameters);
        }

        // Method to add new user
        public int AddUser(User user)
        {
            string query = @"INSERT INTO Users (Username, Email, Password, UserRole, FirstName, LastName, PhoneNumber, IsActive) 
                           VALUES (@Username, @Email, @Password, @UserRole, @FirstName, @LastName, @PhoneNumber, @IsActive);
                           SELECT SCOPE_IDENTITY();";

            SqlParameter[] parameters = {
                new SqlParameter("@Username", user.Username),
                new SqlParameter("@Email", user.Email),
                new SqlParameter("@Password", user.Password),
                new SqlParameter("@UserRole", user.UserRole.ToString()),
                new SqlParameter("@FirstName", user.FirstName),
                new SqlParameter("@LastName", user.LastName),
                new SqlParameter("@PhoneNumber", string.IsNullOrEmpty(user.PhoneNumber) ? (object)DBNull.Value : user.PhoneNumber),
                new SqlParameter("@IsActive", user.IsActive)
            };

            object result = DatabaseConnection.ExecuteScalar(query, parameters);
            return Convert.ToInt32(result);
        }

        // Method to update user
        public void UpdateUser(User user)
        {
            string query = @"UPDATE Users SET Username = @Username, Email = @Email, FirstName = @FirstName, 
                           LastName = @LastName, PhoneNumber = @PhoneNumber, IsActive = @IsActive 
                           WHERE UserID = @UserID";

            SqlParameter[] parameters = {
                new SqlParameter("@Username", user.Username),
                new SqlParameter("@Email", user.Email),
                new SqlParameter("@FirstName", user.FirstName),
                new SqlParameter("@LastName", user.LastName),
                new SqlParameter("@PhoneNumber", string.IsNullOrEmpty(user.PhoneNumber) ? (object)DBNull.Value : user.PhoneNumber),
                new SqlParameter("@IsActive", user.IsActive),
                new SqlParameter("@UserID", user.UserID)
            };

            DatabaseConnection.ExecuteNonQuery(query, parameters);
        }

        // Method to delete user (soft delete)
        public void DeleteUser(int userId)
        {
            string query = "UPDATE Users SET IsActive = 0 WHERE UserID = @UserID";

            SqlParameter[] parameters = {
                new SqlParameter("@UserID", userId)
            };

            DatabaseConnection.ExecuteNonQuery(query, parameters);
        }

        // Method to get users by role
        public List<User> GetUsersByRole(UserRole role)
        {
            List<User> users = new List<User>();
            string query = @"SELECT UserID, Username, Email, Password, UserRole, FirstName, LastName, 
                           PhoneNumber, IsActive, CreatedDate, LastLoginDate 
                           FROM Users WHERE UserRole = @UserRole AND IsActive = 1";

            try
            {
                using (SqlConnection connection = DatabaseConnection.GetConnection())
                {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@UserRole", role.ToString());

                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                users.Add(MapReaderToUser(reader));
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Error getting users by role: {ex.Message}");
            }

            return users;
        }

        // Helper method to map SqlDataReader to User object
        private User MapReaderToUser(SqlDataReader reader)
        {
            return new User
            {
                UserID = Convert.ToInt32(reader["UserID"]),
                Username = reader["Username"].ToString(),
                Email = reader["Email"].ToString(),
                Password = reader["Password"].ToString(),
                UserRole = (UserRole)Enum.Parse(typeof(UserRole), reader["UserRole"].ToString()),
                FirstName = reader["FirstName"].ToString(),
                LastName = reader["LastName"].ToString(),
                PhoneNumber = reader["PhoneNumber"]?.ToString(),
                IsActive = Convert.ToBoolean(reader["IsActive"]),
                CreatedDate = Convert.ToDateTime(reader["CreatedDate"]),
                LastLoginDate = reader["LastLoginDate"] == DBNull.Value ? null : (DateTime?)reader["LastLoginDate"]
            };
        }
    }
}
