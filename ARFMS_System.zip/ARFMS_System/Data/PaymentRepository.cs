using ARFMS_System.Models;
using Microsoft.Data.SqlClient; // Updated to use Microsoft.Data.SqlClient package

namespace ARFMS_System
{
    public class PaymentRepository
    {
        // Method to add payment
        public int AddPayment(Payment payment)
        {
            string query = @"INSERT INTO Payments (BookingID, Amount, PaymentMethod, PaymentDate, ProcessedBy, ReceiptNumber) 
                           VALUES (@BookingID, @Amount, @PaymentMethod, @PaymentDate, @ProcessedBy, @ReceiptNumber);
                           SELECT SCOPE_IDENTITY();";

            SqlParameter[] parameters = {
                new SqlParameter("@BookingID", payment.BookingID),
                new SqlParameter("@Amount", payment.Amount),
                new SqlParameter("@PaymentMethod", payment.PaymentMethod.ToString()),
                new SqlParameter("@PaymentDate", payment.PaymentDate),
                new SqlParameter("@ProcessedBy", payment.ProcessedBy),
                new SqlParameter("@ReceiptNumber", payment.ReceiptNumber)
            };

            object result = DatabaseConnection.ExecuteScalar(query, parameters);
            return Convert.ToInt32(result);
        }

        // Method to get payments by booking ID
        public List<Payment> GetPaymentsByBookingId(int bookingId)
        {
            List<Payment> payments = new List<Payment>();
            string query = @"SELECT p.PaymentID, p.BookingID, p.Amount, p.PaymentMethod, p.PaymentDate, 
                           p.ProcessedBy, p.ReceiptNumber,
                           u.FirstName + ' ' + u.LastName AS ProcessedByName
                           FROM Payments p
                           INNER JOIN Users u ON p.ProcessedBy = u.UserID
                           WHERE p.BookingID = @BookingID
                           ORDER BY p.PaymentDate DESC";

            try
            {
                using (SqlConnection connection = DatabaseConnection.GetConnection())
                {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@BookingID", bookingId);

                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                payments.Add(new Payment
                                {
                                    PaymentID = Convert.ToInt32(reader["PaymentID"]),
                                    BookingID = Convert.ToInt32(reader["BookingID"]),
                                    Amount = Convert.ToDecimal(reader["Amount"]),
                                    PaymentMethod = (PaymentMethod)Enum.Parse(typeof(PaymentMethod), reader["PaymentMethod"].ToString()),
                                    PaymentDate = Convert.ToDateTime(reader["PaymentDate"]),
                                    ProcessedBy = Convert.ToInt32(reader["ProcessedBy"]),
                                    ReceiptNumber = reader["ReceiptNumber"].ToString(),
                                    ProcessedByUser = new User { FullName = reader["ProcessedByName"].ToString() }
                                });
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Error getting payments: {ex.Message}");
            }

            return payments;
        }

        // Method to update booking payment status
        public void UpdateBookingPaymentStatus(int bookingId, PaymentStatus status)
        {
            string query = "UPDATE Bookings SET PaymentStatus = @PaymentStatus WHERE BookingID = @BookingID";

            SqlParameter[] parameters = {
                new SqlParameter("@PaymentStatus", status.ToString()),
                new SqlParameter("@BookingID", bookingId)
            };

            DatabaseConnection.ExecuteNonQuery(query, parameters);
        }
    }
}
