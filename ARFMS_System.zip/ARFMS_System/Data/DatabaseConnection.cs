using Microsoft.Data.SqlClient; // Updated to use Microsoft.Data.SqlClient package

namespace ARFMS_System
{
    public class DatabaseConnection
    {
        private static string connectionString =
            @"Server=AHMAD_USMAN\SQLEXPRESS;Initial Catalog=ARFMS;Integrated Security=True;Encrypt=True;TrustServerCertificate=True;Connect Timeout=15;";

        // Property to get connection string
        public static string ConnectionString
        {
            get { return connectionString; }
            set { connectionString = value; }
        }

        // Method to get a new SQL connection
        public static SqlConnection GetConnection()
        {
            try
            {
                SqlConnection connection = new SqlConnection(connectionString);
                return connection;
            }
            catch (Exception ex)
            {
                throw new Exception($"Error creating database connection: {ex.Message}");
            }
        }

        // Method to test database connection
        public static bool TestConnection()
        {
            try
            {
                using (SqlConnection connection = GetConnection())
                {
                    connection.Open();
                    return connection.State == System.Data.ConnectionState.Open;
                }
            }
            catch
            {
                return false;
            }
        }

        // Method to execute non-query commands (INSERT, UPDATE, DELETE)
        public static int ExecuteNonQuery(string query, SqlParameter[] parameters = null)
        {
            try
            {
                using (SqlConnection connection = GetConnection())
                {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        if (parameters != null)
                        {
                            command.Parameters.AddRange(parameters);
                        }
                        return command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Error executing query: {ex.Message}");
            }
        }

        // Method to execute scalar commands (COUNT, MAX, etc.)
        public static object ExecuteScalar(string query, SqlParameter[] parameters = null)
        {
            try
            {
                using (SqlConnection connection = GetConnection())
                {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        if (parameters != null)
                        {
                            command.Parameters.AddRange(parameters);
                        }
                        return command.ExecuteScalar();
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Error executing scalar query: {ex.Message}");
            }
        }
    }
}
