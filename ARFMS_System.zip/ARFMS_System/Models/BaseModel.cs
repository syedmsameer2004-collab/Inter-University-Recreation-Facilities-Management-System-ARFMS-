namespace ARFMS_System.Models
{
    // Base class for all models with common properties
    public abstract class BaseModel
    {
        public DateTime CreatedDate { get; set; } = DateTime.Now;
        public bool IsActive { get; set; } = true;
    }
}
