using System.ComponentModel.DataAnnotations;

namespace ARFMS_System.Models
{
    public class Payment
    {
        public int PaymentID { get; set; }

        [Required(ErrorMessage = "Booking is required")]
        public int BookingID { get; set; }

        public int BookingId => BookingID;

        [Required(ErrorMessage = "Amount is required")]
        [Range(0.01, double.MaxValue, ErrorMessage = "Amount must be greater than 0")]
        public decimal Amount { get; set; }

        public PaymentMethod PaymentMethod { get; set; } = PaymentMethod.Cash;

        public DateTime PaymentDate { get; set; } = DateTime.Now;

        [Required(ErrorMessage = "Processed by is required")]
        public int ProcessedBy { get; set; } // Reception staff who processed payment

        [Required(ErrorMessage = "Receipt number is required")]
        [StringLength(50, ErrorMessage = "Receipt number cannot exceed 50 characters")]
        public string ReceiptNumber { get; set; }

        public PaymentStatus Status { get; set; } = PaymentStatus.Paid;

        // Navigation properties
        public Booking Booking { get; set; }
        public User ProcessedByUser { get; set; }

        // Method to generate receipt number
        public static string GenerateReceiptNumber()
        {
            return $"RCP{DateTime.Now:yyyyMMddHHmmss}";
        }
    }
}
