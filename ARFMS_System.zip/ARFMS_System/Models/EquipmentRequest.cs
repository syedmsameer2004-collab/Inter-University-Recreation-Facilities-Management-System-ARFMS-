using System.ComponentModel.DataAnnotations;

namespace ARFMS_System.Models
{
    public class EquipmentRequest : BaseModel
    {
        public int RequestID { get; set; }

        [Required(ErrorMessage = "Facility is required")]
        public int FacilityID { get; set; }

        [Required(ErrorMessage = "Requested by is required")]
        public int RequestedBy { get; set; } // Maintenance Staff

        [Required(ErrorMessage = "Request type is required")]
        public RequestType RequestType { get; set; }

        [Required(ErrorMessage = "Item name is required")]
        [StringLength(100, ErrorMessage = "Item name cannot exceed 100 characters")]
        public string ItemName { get; set; }

        [StringLength(500, ErrorMessage = "Description cannot exceed 500 characters")]
        public string Description { get; set; }

        [Range(1, int.MaxValue, ErrorMessage = "Quantity must be greater than 0")]
        public int Quantity { get; set; } = 1;

        [Range(0, double.MaxValue, ErrorMessage = "Estimated cost cannot be negative")]
        public decimal? EstimatedCost { get; set; }

        public Priority Priority { get; set; } = Priority.Medium;
        public RequestStatus Status { get; set; } = RequestStatus.Pending;

        public DateTime RequestDate { get; set; } = DateTime.Now;

        public int? ApprovedBy { get; set; } // Manager
        public DateTime? ApprovalDate { get; set; }
        public DateTime? CompletedDate { get; set; }

        [StringLength(500, ErrorMessage = "Approval notes cannot exceed 500 characters")]
        public string ApprovalNotes { get; set; }

        // Navigation properties
        public Facility Facility { get; set; }
        public User RequestedByUser { get; set; }
        public User ApprovedByUser { get; set; }

        // Method to approve request
        public void ApproveRequest(int managerId, string notes = null)
        {
            Status = RequestStatus.Approved;
            ApprovedBy = managerId;
            ApprovalDate = DateTime.Now;
            if (!string.IsNullOrEmpty(notes))
                ApprovalNotes = notes;
        }

        // Method to reject request
        public void RejectRequest(int managerId, string notes)
        {
            Status = RequestStatus.Rejected;
            ApprovedBy = managerId;
            ApprovalDate = DateTime.Now;
            ApprovalNotes = notes;
        }
    }
}
