using System.ComponentModel.DataAnnotations;

namespace ARFMS_System.Models
{
    public class Facility : BaseModel
    {
        public int FacilityID { get; set; }

        [Required(ErrorMessage = "Facility code is required")]
        [StringLength(20, ErrorMessage = "Facility code cannot exceed 20 characters")]
        public string FacilityCode { get; set; }

        [Required(ErrorMessage = "Facility name is required")]
        [StringLength(100, ErrorMessage = "Facility name cannot exceed 100 characters")]
        public string FacilityName { get; set; }

        [Required(ErrorMessage = "Facility type is required")]
        public int FacilityTypeID { get; set; }

        [Required(ErrorMessage = "University is required")]
        public int UniversityID { get; set; }

        [StringLength(255, ErrorMessage = "Location cannot exceed 255 characters")]
        public string Location { get; set; }

        [Range(1, int.MaxValue, ErrorMessage = "Capacity must be greater than 0")]
        public int Capacity { get; set; }

        [Required(ErrorMessage = "Hourly rate is required")]
        [Range(0.01, double.MaxValue, ErrorMessage = "Hourly rate must be greater than 0")]
        public decimal HourlyRate { get; set; }

        [StringLength(500, ErrorMessage = "Description cannot exceed 500 characters")]
        public string Description { get; set; }

        public bool IsAvailable { get; set; } = true;

        // Navigation properties
        public FacilityType FacilityType { get; set; }
        public University University { get; set; }

        // Method to calculate booking cost
        public decimal CalculateBookingCost(int hours)
        {
            return HourlyRate * hours;
        }
    }
}
