using System.ComponentModel.DataAnnotations;

namespace ARFMS_System.Models
{
    public class FacilityType
    {
        public int FacilityTypeID { get; set; }

        [Required(ErrorMessage = "Type name is required")]
        [StringLength(50, ErrorMessage = "Type name cannot exceed 50 characters")]
        public string TypeName { get; set; }

        [StringLength(255, ErrorMessage = "Description cannot exceed 255 characters")]
        public string Description { get; set; }
    }
}
