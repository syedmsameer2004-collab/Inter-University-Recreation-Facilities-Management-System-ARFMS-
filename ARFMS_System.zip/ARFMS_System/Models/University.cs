using System.ComponentModel.DataAnnotations;

namespace ARFMS_System.Models
{
    public class University : BaseModel
    {
        public int UniversityID { get; set; }

        [Required(ErrorMessage = "University name is required")]
        [StringLength(100, ErrorMessage = "University name cannot exceed 100 characters")]
        public string UniversityName { get; set; }

        [StringLength(255, ErrorMessage = "Address cannot exceed 255 characters")]
        public string Address { get; set; }

        [StringLength(100, ErrorMessage = "Contact person name cannot exceed 100 characters")]
        public string ContactPerson { get; set; }

        [EmailAddress(ErrorMessage = "Invalid email format")]
        [StringLength(100, ErrorMessage = "Contact email cannot exceed 100 characters")]
        public string ContactEmail { get; set; }

        [Phone(ErrorMessage = "Invalid phone number format")]
        [StringLength(15, ErrorMessage = "Contact phone cannot exceed 15 characters")]
        public string ContactPhone { get; set; }
    }
}
