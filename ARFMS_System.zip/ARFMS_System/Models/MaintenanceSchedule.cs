using System.ComponentModel.DataAnnotations;

namespace ARFMS_System.Models
{
    public class MaintenanceSchedule : BaseModel
    {
        public int ScheduleID { get; set; }

        public int ScheduleId => ScheduleID;

        [Required(ErrorMessage = "Facility is required")]
        public int FacilityID { get; set; }

        [Required(ErrorMessage = "Maintenance staff is required")]
        public int MaintenanceStaffID { get; set; }

        [Required(ErrorMessage = "Scheduled date is required")]
        [DataType(DataType.Date)]
        public DateTime ScheduledDate { get; set; }

        [Required(ErrorMessage = "Scheduled time is required")]
        [DataType(DataType.Time)]
        public TimeSpan ScheduledTime { get; set; }

        [Required(ErrorMessage = "Maintenance type is required")]
        [StringLength(50, ErrorMessage = "Maintenance type cannot exceed 50 characters")]
        public string MaintenanceType { get; set; }

        [StringLength(500, ErrorMessage = "Description cannot exceed 500 characters")]
        public string Description { get; set; }

        public MaintenanceStatus Status { get; set; } = MaintenanceStatus.Scheduled;

        [Required(ErrorMessage = "Assigned by is required")]
        public int AssignedBy { get; set; } // Manager who assigned

        public DateTime? CompletedDate { get; set; }

        [StringLength(500, ErrorMessage = "Notes cannot exceed 500 characters")]
        public string Notes { get; set; }

        // Navigation properties
        public Facility Facility { get; set; }
        public User MaintenanceStaff { get; set; }
        public User AssignedByUser { get; set; }

        public string FacilityName => Facility?.FacilityName;
        public int EstimatedHours { get; set; } = 1; // Default estimated hours

        // Method to mark as completed
        public void MarkAsCompleted(string notes = null)
        {
            Status = MaintenanceStatus.Completed;
            CompletedDate = DateTime.Now;
            if (!string.IsNullOrEmpty(notes))
                Notes = notes;
        }

        // Method to check if overdue
        public bool IsOverdue()
        {
            var scheduledDateTime = ScheduledDate.Add(ScheduledTime);
            return DateTime.Now > scheduledDateTime && Status == MaintenanceStatus.Scheduled;
        }
    }
}
