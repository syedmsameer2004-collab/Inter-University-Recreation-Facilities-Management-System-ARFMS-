using System.ComponentModel.DataAnnotations;

namespace ARFMS_System.Models
{
    public class User : BaseModel
    {
        public int UserID { get; set; }

        public int UserId => UserID;

        [Required(ErrorMessage = "Username is required")]
        [StringLength(50, ErrorMessage = "Username cannot exceed 50 characters")]
        public string Username { get; set; }

        [Required(ErrorMessage = "Email is required")]
        [EmailAddress(ErrorMessage = "Invalid email format")]
        [StringLength(100, ErrorMessage = "Email cannot exceed 100 characters")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Password is required")]
        [StringLength(255, MinimumLength = 6, ErrorMessage = "Password must be between 6 and 255 characters")]
        public string Password { get; set; }

        [Required(ErrorMessage = "User role is required")]
        public UserRole UserRole { get; set; }

        [Required(ErrorMessage = "First name is required")]
        [StringLength(50, ErrorMessage = "First name cannot exceed 50 characters")]
        public string FirstName { get; set; }

        [Required(ErrorMessage = "Last name is required")]
        [StringLength(50, ErrorMessage = "Last name cannot exceed 50 characters")]
        public string LastName { get; set; }

        [Phone(ErrorMessage = "Invalid phone number format")]
        [StringLength(15, ErrorMessage = "Phone number cannot exceed 15 characters")]
        public string PhoneNumber { get; set; }

        public DateTime? LastLoginDate { get; set; }

        public string FullName
        {
            get => $"{FirstName} {LastName}";
            set
            {
                // Optional: Parse full name into first and last name if needed
                if (!string.IsNullOrWhiteSpace(value))
                {
                    var parts = value.Split(' ', 2);
                    FirstName = parts[0];
                    LastName = parts.Length > 1 ? parts[1] : "";
                }
            }
        }

        // Method to validate user credentials
        public bool ValidateCredentials(string username, string password)
        {
            return Username.Equals(username, StringComparison.OrdinalIgnoreCase) &&
                   Password == password && IsActive;
        }

        // Method to update last login
        public void UpdateLastLogin()
        {
            LastLoginDate = DateTime.Now;
        }
    }
}
