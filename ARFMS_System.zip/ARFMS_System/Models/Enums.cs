namespace ARFMS_System.Models
{
    // User role enumeration
    public enum UserRole
    {
        Manager,
        Reception,
        Student,
        MaintenanceStaff
    }

    // Booking status enumeration
    public enum BookingStatus
    {
        Pending,
        Confirmed,
        Cancelled,
        Completed,
        //Paid
    }

    // Payment status enumeration
    public enum PaymentStatus
    {
        Unpaid,
        Paid,
        Refunded
    }

    // Payment method enumeration
    public enum PaymentMethod
    {
        Cash,
        Card,
        Transfer
    }

    // Maintenance status enumeration
    public enum MaintenanceStatus
    {
        Scheduled,
        InProgress,
        Completed,
        Cancelled
    }

    // Equipment request type enumeration
    public enum RequestType
    {
        Repair,
        Replacement,
        Supply
    }

    // Request status enumeration
    public enum RequestStatus
    {
        Pending,
        Approved,
        Rejected,
        Completed,
        Fulfilled
    }

    // Priority levels enumeration
    public enum Priority
    {
        Low,
        Medium,
        High,
        Urgent
    }
}
