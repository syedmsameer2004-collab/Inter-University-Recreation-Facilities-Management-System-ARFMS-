using System.ComponentModel.DataAnnotations;

namespace ARFMS_System.Models
{
    public class SupplyRequest : BaseModel
    {
        public int SupplyRequestID { get; set; }

        public int RequestId => SupplyRequestID;

        [Required(ErrorMessage = "Supply is required")]
        public int SupplyID { get; set; }

        [Required(ErrorMessage = "Requested by is required")]
        public int RequestedBy { get; set; } // Maintenance Staff

        [Required(ErrorMessage = "Quantity requested is required")]
        [Range(1, int.MaxValue, ErrorMessage = "Quantity requested must be greater than 0")]
        public int QuantityRequested { get; set; }

        public int Quantity => QuantityRequested;

        public DateTime RequestDate { get; set; } = DateTime.Now;
        public RequestStatus Status { get; set; } = RequestStatus.Pending;

        public int? ApprovedBy { get; set; } // Manager
        public DateTime? ApprovalDate { get; set; }

        [StringLength(500, ErrorMessage = "Notes cannot exceed 500 characters")]
        public string Notes { get; set; }

        // Navigation properties
        public CleaningSupply Supply { get; set; }
        public User RequestedByUser { get; set; }
        public User ApprovedByUser { get; set; }

        public string SupplyName => Supply?.SupplyName;
        public string Unit => Supply?.Unit;

        // Method to approve request
        public void ApproveRequest(int managerId)
        {
            Status = RequestStatus.Approved;
            ApprovedBy = managerId;
            ApprovalDate = DateTime.Now;
        }

        // Method to fulfill request
        public void FulfillRequest()
        {
            Status = RequestStatus.Fulfilled;
        }
    }
}
