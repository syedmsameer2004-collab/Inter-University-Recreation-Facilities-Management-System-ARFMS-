using System.ComponentModel.DataAnnotations;

namespace ARFMS_System.Models
{
    public class Review
    {
        public int ReviewID { get; set; }

        public int? BookingID { get; set; }

        [Required(ErrorMessage = "Student is required")]
        public int StudentID { get; set; }

        public int StudentId => StudentID;

        [Required(ErrorMessage = "Facility is required")]
        public int FacilityID { get; set; }

        public int FacilityId => FacilityID;

        [Required(ErrorMessage = "Rating is required")]
        [Range(1, 5, ErrorMessage = "Rating must be between 1 and 5")]
        public int Rating { get; set; }

        [StringLength(1000, ErrorMessage = "Review text cannot exceed 1000 characters")]
        public string ReviewText { get; set; }

        public string Comment => ReviewText;

        public DateTime ReviewDate { get; set; } = DateTime.Now;

        // Navigation properties
        public Booking Booking { get; set; }
        public User Student { get; set; }
        public Facility Facility { get; set; }

        // Method to get rating description
        public string GetRatingDescription()
        {
            return Rating switch
            {
                1 => "Poor",
                2 => "Fair",
                3 => "Good",
                4 => "Very Good",
                5 => "Excellent",
                _ => "Unknown"
            };
        }
    }
}
