using System.ComponentModel.DataAnnotations;

namespace ARFMS_System.Models
{
    public class CleaningSupply : BaseModel
    {
        public int SupplyID { get; set; }

        [Required(ErrorMessage = "Supply name is required")]
        [StringLength(100, ErrorMessage = "Supply name cannot exceed 100 characters")]
        public string SupplyName { get; set; }

        [Range(0, int.MaxValue, ErrorMessage = "Current stock cannot be negative")]
        public int CurrentStock { get; set; } = 0;

        [Range(0, int.MaxValue, ErrorMessage = "Minimum stock cannot be negative")]
        public int MinimumStock { get; set; } = 10;

        [Required(ErrorMessage = "Unit is required")]
        [StringLength(20, ErrorMessage = "Unit cannot exceed 20 characters")]
        public string Unit { get; set; }

        public DateTime? LastRestocked { get; set; }

        // Method to check if stock is low
        public bool IsLowStock()
        {
            return CurrentStock <= MinimumStock;
        }

        // Method to update stock
        public void UpdateStock(int quantity)
        {
            CurrentStock += quantity;
            if (quantity > 0)
                LastRestocked = DateTime.Now;
        }
    }
}
