using System.ComponentModel.DataAnnotations;

namespace ARFMS_System.Models
{
    public class Booking : BaseModel
    {
        public int BookingID { get; set; }
        public int BookingId => BookingID;

        [Required(ErrorMessage = "Student is required")]
        public int StudentID { get; set; }

        [Required(ErrorMessage = "Facility is required")]
        public int FacilityID { get; set; }

        [Required(ErrorMessage = "Booking date is required")]
        [DataType(DataType.Date)]
        public DateTime BookingDate { get; set; }

        [Required(ErrorMessage = "Start time is required")]
        [DataType(DataType.Time)]
        public TimeSpan StartTime { get; set; }

        [Required(ErrorMessage = "End time is required")]
        [DataType(DataType.Time)]
        public TimeSpan EndTime { get; set; }

        [Required(ErrorMessage = "Total amount is required")]
        [Range(0.01, double.MaxValue, ErrorMessage = "Total amount must be greater than 0")]
        public decimal TotalAmount { get; set; }

        public BookingStatus BookingStatus { get; set; } = BookingStatus.Pending;
        public PaymentStatus PaymentStatus { get; set; } = PaymentStatus.Unpaid;

        public int? CreatedBy { get; set; } // Reception staff who created booking

        [StringLength(500, ErrorMessage = "Notes cannot exceed 500 characters")]
        public string? Notes { get; set; }

        // Navigation properties (hydrated by repository)
        public User? Student { get; set; }
        public Facility? Facility { get; set; }
        public User? CreatedByUser { get; set; }

        // Existing convenience
        public string? StudentName => Student?.FullName;
        public string? FacilityCode => Facility?.FacilityCode;

        // NEW: flattened properties for easy binding (names instead of IDs)
        public string? FacilityName => Facility?.FacilityName;
        public string? CreatedByName => CreatedByUser?.FullName;

        // Enums as text for the grid
        public string BookingStatusText => BookingStatus.ToString();
        public string PaymentStatusText => PaymentStatus.ToString();

        // Computed property for duration
        public int Duration => (int)(EndTime - StartTime).TotalHours;

        // Method to validate booking time
        public bool IsValidBookingTime()
        {
            return EndTime > StartTime && BookingDate > DateTime.Today;
        }

        // Method to check if booking can be cancelled
        public bool CanBeCancelled()
        {
            return BookingStatus == BookingStatus.Pending || BookingStatus == BookingStatus.Confirmed;
        }
    }
}
