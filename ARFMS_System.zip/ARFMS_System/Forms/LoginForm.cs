using System;
using System.Drawing;
using System.Windows.Forms;
using ARFMS.Services;
using ARFMS_System.Models;

namespace ARFMS.Forms
{
    public partial class LoginForm : Form
    {
        private AuthenticationService authService;

        public LoginForm()
        {
            InitializeComponent();
            authService = new AuthenticationService();
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();

            // Form properties
            this.Text = "ARFMS - Login";
            this.Size = new Size(400, 350);
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.BackColor = Color.White;

            // Title Label
            Label titleLabel = new Label();
            titleLabel.Text = "ARFMS Login";
            titleLabel.Font = new Font("Segoe UI", 16, FontStyle.Bold);
            titleLabel.ForeColor = Color.FromArgb(41, 128, 185);
            titleLabel.Location = new Point(120, 30);
            titleLabel.Size = new Size(150, 30);
            titleLabel.TextAlign = ContentAlignment.MiddleCenter;
            this.Controls.Add(titleLabel);

            // Username Label
            Label usernameLabel = new Label();
            usernameLabel.Text = "Username/Email:";
            usernameLabel.Font = new Font("Segoe UI", 10);
            usernameLabel.Location = new Point(50, 80);
            usernameLabel.Size = new Size(120, 20);
            this.Controls.Add(usernameLabel);

            // Username TextBox
            TextBox usernameTextBox = new TextBox();
            usernameTextBox.Name = "txtUsername";
            usernameTextBox.Font = new Font("Segoe UI", 10);
            usernameTextBox.Location = new Point(50, 105);
            usernameTextBox.Size = new Size(300, 25);
            usernameTextBox.TabIndex = 1;
            this.Controls.Add(usernameTextBox);

            // Password Label
            Label passwordLabel = new Label();
            passwordLabel.Text = "Password:";
            passwordLabel.Font = new Font("Segoe UI", 10);
            passwordLabel.Location = new Point(50, 140);
            passwordLabel.Size = new Size(80, 20);
            this.Controls.Add(passwordLabel);

            // Password TextBox
            TextBox passwordTextBox = new TextBox();
            passwordTextBox.Name = "txtPassword";
            passwordTextBox.Font = new Font("Segoe UI", 10);
            passwordTextBox.Location = new Point(50, 165);
            passwordTextBox.Size = new Size(300, 25);
            passwordTextBox.UseSystemPasswordChar = true;
            passwordTextBox.TabIndex = 2;
            passwordTextBox.KeyPress += PasswordTextBox_KeyPress;
            this.Controls.Add(passwordTextBox);

            // Login Button
            Button loginButton = new Button();
            loginButton.Name = "btnLogin";
            loginButton.Text = "Login";
            loginButton.Font = new Font("Segoe UI", 10, FontStyle.Bold);
            loginButton.BackColor = Color.FromArgb(41, 128, 185);
            loginButton.ForeColor = Color.White;
            loginButton.FlatStyle = FlatStyle.Flat;
            loginButton.Location = new Point(150, 210);
            loginButton.Size = new Size(100, 35);
            loginButton.TabIndex = 3;
            loginButton.Click += LoginButton_Click;
            this.Controls.Add(loginButton);

            // Status Label
            Label statusLabel = new Label();
            statusLabel.Name = "lblStatus";
            statusLabel.Font = new Font("Segoe UI", 9);
            statusLabel.ForeColor = Color.Red;
            statusLabel.Location = new Point(50, 250);
            statusLabel.Size = new Size(300, 20);
            statusLabel.TextAlign = ContentAlignment.MiddleCenter;
            statusLabel.Visible = false;
            this.Controls.Add(statusLabel);

            this.ResumeLayout(false);
        }

        private void LoginButton_Click(object sender, EventArgs e)
        {
            PerformLogin();
        }

        private void PasswordTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                PerformLogin();
            }
        }

        private void PerformLogin()
        {
            TextBox txtUsername = this.Controls["txtUsername"] as TextBox;
            TextBox txtPassword = this.Controls["txtPassword"] as TextBox;
            Label lblStatus = this.Controls["lblStatus"] as Label;

            string username = txtUsername.Text.Trim();
            string password = txtPassword.Text;

            // Clear previous status
            lblStatus.Visible = false;

            // Validate input
            if (string.IsNullOrWhiteSpace(username))
            {
                ShowStatus("Please enter username or email.", Color.Red);
                txtUsername.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(password))
            {
                ShowStatus("Please enter password.", Color.Red);
                txtPassword.Focus();
                return;
            }

            try
            {
                // Attempt login
                if (authService.Login(username, password))
                {
                    ShowStatus("Login successful! Redirecting...", Color.Green);

                    System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer();
                    timer.Interval = 1000;
                    timer.Tick += (s, args) =>
                    {
                        timer.Stop();
                        RedirectToHomePage();
                    };
                    timer.Start();
                }
                else
                {
                    ShowStatus("Invalid username/email or password.", Color.Red);
                    txtPassword.Clear();
                    txtUsername.Focus();
                }
            }
            catch (Exception ex)
            {
                ShowStatus($"Login error: {ex.Message}", Color.Red);
            }
        }

        private void ShowStatus(string message, Color color)
        {
            Label lblStatus = this.Controls["lblStatus"] as Label;
            lblStatus.Text = message;
            lblStatus.ForeColor = color;
            lblStatus.Visible = true;
        }

        private void RedirectToHomePage()
        {
            try
            {
                Form homeForm = null;

                // Redirect based on user role
                switch (AuthenticationService.CurrentUser.UserRole)
                {
                    case UserRole.Manager:
                        homeForm = new ManagerHomeForm();
                        break;
                    case UserRole.Reception:
                        homeForm = new ReceptionHomeForm();
                        break;
                    case UserRole.Student:
                        homeForm = new StudentHomeForm();
                        break;
                    case UserRole.MaintenanceStaff:
                        homeForm = new MaintenanceStaffHomeForm(AuthenticationService.CurrentUser);
                        break;
                    default:
                        MessageBox.Show("Unknown user role. Please contact administrator.", "Error",
                                      MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                }

                // Hide login form and show home form
                this.Hide();
                homeForm.FormClosed += (s, args) => this.Close();
                homeForm.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error opening home page: {ex.Message}", "Error",
                              MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
