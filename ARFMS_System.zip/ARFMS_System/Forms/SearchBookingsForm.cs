using ARFMS_System;

namespace ARFMS.Forms
{
    public partial class SearchBookingsForm : Form
    {
        private BookingRepository bookingRepository;
        private TextBox searchTextBox;
        private ComboBox searchTypeComboBox;
        private Button searchButton;
        private DataGridView resultsGrid;

        public SearchBookingsForm()
        {
            bookingRepository = new BookingRepository();
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Search Bookings";
            this.Size = new Size(800, 500);
            this.StartPosition = FormStartPosition.CenterScreen;

            // Search type
            Label typeLabel = new Label();
            typeLabel.Text = "Search by:";
            typeLabel.Location = new Point(20, 20);
            typeLabel.Size = new Size(80, 20);
            this.Controls.Add(typeLabel);

            searchTypeComboBox = new ComboBox();
            searchTypeComboBox.Location = new Point(110, 20);
            searchTypeComboBox.Size = new Size(150, 25);
            searchTypeComboBox.Items.AddRange(new string[] { "Student Name", "Facility Code", "Booking ID" });
            searchTypeComboBox.SelectedIndex = 0;
            this.Controls.Add(searchTypeComboBox);

            // Search text
            Label searchLabel = new Label();
            searchLabel.Text = "Search:";
            searchLabel.Location = new Point(280, 20);
            searchLabel.Size = new Size(50, 20);
            this.Controls.Add(searchLabel);

            searchTextBox = new TextBox();
            searchTextBox.Location = new Point(340, 20);
            searchTextBox.Size = new Size(200, 25);
            this.Controls.Add(searchTextBox);

            searchButton = new Button();
            searchButton.Text = "Search";
            searchButton.Location = new Point(560, 20);
            searchButton.Size = new Size(80, 25);
            searchButton.Click += SearchButton_Click;
            this.Controls.Add(searchButton);

            // Results grid
            resultsGrid = new DataGridView();
            resultsGrid.Location = new Point(20, 60);
            resultsGrid.Size = new Size(740, 380);
            resultsGrid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            this.Controls.Add(resultsGrid);
        }

        private void SearchButton_Click(object sender, EventArgs e)
        {
            string searchText = searchTextBox.Text.Trim();
            if (string.IsNullOrEmpty(searchText))
            {
                MessageBox.Show("Please enter search text.");
                return;
            }

            var allBookings = bookingRepository.GetAllBookings();
            var filteredBookings = allBookings.Where(b =>
                searchTypeComboBox.SelectedItem.ToString() == "Student Name" && b.StudentName.Contains(searchText) ||
                searchTypeComboBox.SelectedItem.ToString() == "Facility Code" && b.FacilityCode.Contains(searchText) ||
                searchTypeComboBox.SelectedItem.ToString() == "Booking ID" && b.BookingID.ToString().Contains(searchText)
            ).ToList();

            resultsGrid.DataSource = filteredBookings;
        }
    }
}
