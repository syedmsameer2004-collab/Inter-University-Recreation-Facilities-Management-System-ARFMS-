using ARFMS_System;
using ARFMS_System.Models;

namespace ARFMS.Forms
{
    public partial class AddEditFacilityForm : Form
    {
        private FacilityRepository facilityRepository;
        private Facility currentFacility;
        private bool isEditMode;

        public AddEditFacilityForm(Facility facility = null)
        {
            facilityRepository = new FacilityRepository();
            currentFacility = facility;
            isEditMode = facility != null;
            InitializeComponent();
            LoadComboBoxData();

            if (isEditMode)
            {
                LoadFacilityData();
            }
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();

            // Form properties
            this.Text = isEditMode ? "Edit Facility" : "Add Facility";
            this.Size = new Size(500, 500);
            this.StartPosition = FormStartPosition.CenterParent;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.BackColor = Color.White;

            // Facility Code
            Label codeLabel = new Label();
            codeLabel.Text = "Facility Code:";
            codeLabel.Font = new Font("Segoe UI", 10);
            codeLabel.Location = new Point(30, 30);
            codeLabel.Size = new Size(100, 20);
            this.Controls.Add(codeLabel);

            TextBox codeTextBox = new TextBox();
            codeTextBox.Name = "txtCode";
            codeTextBox.Font = new Font("Segoe UI", 10);
            codeTextBox.Location = new Point(140, 28);
            codeTextBox.Size = new Size(300, 25);
            this.Controls.Add(codeTextBox);

            // Facility Name
            Label nameLabel = new Label();
            nameLabel.Text = "Facility Name:";
            nameLabel.Font = new Font("Segoe UI", 10);
            nameLabel.Location = new Point(30, 70);
            nameLabel.Size = new Size(100, 20);
            this.Controls.Add(nameLabel);

            TextBox nameTextBox = new TextBox();
            nameTextBox.Name = "txtName";
            nameTextBox.Font = new Font("Segoe UI", 10);
            nameTextBox.Location = new Point(140, 68);
            nameTextBox.Size = new Size(300, 25);
            this.Controls.Add(nameTextBox);

            // Facility Type
            Label typeLabel = new Label();
            typeLabel.Text = "Facility Type:";
            typeLabel.Font = new Font("Segoe UI", 10);
            typeLabel.Location = new Point(30, 110);
            typeLabel.Size = new Size(100, 20);
            this.Controls.Add(typeLabel);

            ComboBox typeComboBox = new ComboBox();
            typeComboBox.Name = "cmbType";
            typeComboBox.Font = new Font("Segoe UI", 10);
            typeComboBox.Location = new Point(140, 108);
            typeComboBox.Size = new Size(300, 25);
            typeComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
            this.Controls.Add(typeComboBox);

            // University
            Label universityLabel = new Label();
            universityLabel.Text = "University:";
            universityLabel.Font = new Font("Segoe UI", 10);
            universityLabel.Location = new Point(30, 150);
            universityLabel.Size = new Size(100, 20);
            this.Controls.Add(universityLabel);

            ComboBox universityComboBox = new ComboBox();
            universityComboBox.Name = "cmbUniversity";
            universityComboBox.Font = new Font("Segoe UI", 10);
            universityComboBox.Location = new Point(140, 148);
            universityComboBox.Size = new Size(300, 25);
            universityComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
            this.Controls.Add(universityComboBox);

            // Location
            Label locationLabel = new Label();
            locationLabel.Text = "Location:";
            locationLabel.Font = new Font("Segoe UI", 10);
            locationLabel.Location = new Point(30, 190);
            locationLabel.Size = new Size(100, 20);
            this.Controls.Add(locationLabel);

            TextBox locationTextBox = new TextBox();
            locationTextBox.Name = "txtLocation";
            locationTextBox.Font = new Font("Segoe UI", 10);
            locationTextBox.Location = new Point(140, 188);
            locationTextBox.Size = new Size(300, 25);
            this.Controls.Add(locationTextBox);

            // Capacity
            Label capacityLabel = new Label();
            capacityLabel.Text = "Capacity:";
            capacityLabel.Font = new Font("Segoe UI", 10);
            capacityLabel.Location = new Point(30, 230);
            capacityLabel.Size = new Size(100, 20);
            this.Controls.Add(capacityLabel);

            NumericUpDown capacityNumeric = new NumericUpDown();
            capacityNumeric.Name = "numCapacity";
            capacityNumeric.Font = new Font("Segoe UI", 10);
            capacityNumeric.Location = new Point(140, 228);
            capacityNumeric.Size = new Size(150, 25);
            capacityNumeric.Minimum = 1;
            capacityNumeric.Maximum = 1000;
            capacityNumeric.Value = 10;
            this.Controls.Add(capacityNumeric);

            // Hourly Rate
            Label rateLabel = new Label();
            rateLabel.Text = "Hourly Rate:";
            rateLabel.Font = new Font("Segoe UI", 10);
            rateLabel.Location = new Point(30, 270);
            rateLabel.Size = new Size(100, 20);
            this.Controls.Add(rateLabel);

            NumericUpDown rateNumeric = new NumericUpDown();
            rateNumeric.Name = "numRate";
            rateNumeric.Font = new Font("Segoe UI", 10);
            rateNumeric.Location = new Point(140, 268);
            rateNumeric.Size = new Size(150, 25);
            rateNumeric.DecimalPlaces = 2;
            rateNumeric.Minimum = 0.01m;
            rateNumeric.Maximum = 1000m;
            rateNumeric.Value = 10m;
            this.Controls.Add(rateNumeric);

            // Description
            Label descLabel = new Label();
            descLabel.Text = "Description:";
            descLabel.Font = new Font("Segoe UI", 10);
            descLabel.Location = new Point(30, 310);
            descLabel.Size = new Size(100, 20);
            this.Controls.Add(descLabel);

            TextBox descTextBox = new TextBox();
            descTextBox.Name = "txtDescription";
            descTextBox.Font = new Font("Segoe UI", 10);
            descTextBox.Location = new Point(140, 308);
            descTextBox.Size = new Size(300, 60);
            descTextBox.Multiline = true;
            descTextBox.ScrollBars = ScrollBars.Vertical;
            this.Controls.Add(descTextBox);

            // Available CheckBox
            CheckBox availableCheckBox = new CheckBox();
            availableCheckBox.Name = "chkAvailable";
            availableCheckBox.Text = "Available for booking";
            availableCheckBox.Font = new Font("Segoe UI", 10);
            availableCheckBox.Location = new Point(140, 380);
            availableCheckBox.Size = new Size(200, 25);
            availableCheckBox.Checked = true;
            this.Controls.Add(availableCheckBox);

            // Save Button
            Button saveButton = new Button();
            saveButton.Text = "Save";
            saveButton.Font = new Font("Segoe UI", 10, FontStyle.Bold);
            saveButton.BackColor = Color.FromArgb(46, 204, 113);
            saveButton.ForeColor = Color.White;
            saveButton.FlatStyle = FlatStyle.Flat;
            saveButton.Location = new Point(250, 420);
            saveButton.Size = new Size(80, 30);
            saveButton.Click += SaveButton_Click;
            this.Controls.Add(saveButton);

            // Cancel Button
            Button cancelButton = new Button();
            cancelButton.Text = "Cancel";
            cancelButton.Font = new Font("Segoe UI", 10);
            cancelButton.BackColor = Color.FromArgb(149, 165, 166);
            cancelButton.ForeColor = Color.White;
            cancelButton.FlatStyle = FlatStyle.Flat;
            cancelButton.Location = new Point(350, 420);
            cancelButton.Size = new Size(80, 30);
            cancelButton.Click += CancelButton_Click;
            this.Controls.Add(cancelButton);

            this.ResumeLayout(false);
        }

        private void LoadComboBoxData()
        {
            try
            {
                // Load facility types
                List<FacilityType> facilityTypes = facilityRepository.GetAllFacilityTypes();
                ComboBox typeComboBox = this.Controls["cmbType"] as ComboBox;
                typeComboBox.DataSource = facilityTypes;
                typeComboBox.DisplayMember = "TypeName";
                typeComboBox.ValueMember = "FacilityTypeID";

                // Load universities
                List<University> universities = facilityRepository.GetAllUniversities();
                ComboBox universityComboBox = this.Controls["cmbUniversity"] as ComboBox;
                universityComboBox.DataSource = universities;
                universityComboBox.DisplayMember = "UniversityName";
                universityComboBox.ValueMember = "UniversityID";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading data: {ex.Message}", "Error",
                              MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadFacilityData()
        {
            if (currentFacility != null)
            {
                (this.Controls["txtCode"] as TextBox).Text = currentFacility.FacilityCode;
                (this.Controls["txtName"] as TextBox).Text = currentFacility.FacilityName;
                (this.Controls["cmbType"] as ComboBox).SelectedValue = currentFacility.FacilityTypeID;
                (this.Controls["cmbUniversity"] as ComboBox).SelectedValue = currentFacility.UniversityID;
                (this.Controls["txtLocation"] as TextBox).Text = currentFacility.Location;
                (this.Controls["numCapacity"] as NumericUpDown).Value = currentFacility.Capacity;
                (this.Controls["numRate"] as NumericUpDown).Value = currentFacility.HourlyRate;
                (this.Controls["txtDescription"] as TextBox).Text = currentFacility.Description;
                (this.Controls["chkAvailable"] as CheckBox).Checked = currentFacility.IsAvailable;
            }
        }

        private void SaveButton_Click(object sender, EventArgs e)
        {
            try
            {
                if (!ValidateInput())
                    return;

                Facility facility = isEditMode ? currentFacility : new Facility();

                facility.FacilityCode = (this.Controls["txtCode"] as TextBox).Text.Trim();
                facility.FacilityName = (this.Controls["txtName"] as TextBox).Text.Trim();
                facility.FacilityTypeID = Convert.ToInt32((this.Controls["cmbType"] as ComboBox).SelectedValue);
                facility.UniversityID = Convert.ToInt32((this.Controls["cmbUniversity"] as ComboBox).SelectedValue);
                facility.Location = (this.Controls["txtLocation"] as TextBox).Text.Trim();
                facility.Capacity = Convert.ToInt32((this.Controls["numCapacity"] as NumericUpDown).Value);
                facility.HourlyRate = (this.Controls["numRate"] as NumericUpDown).Value;
                facility.Description = (this.Controls["txtDescription"] as TextBox).Text.Trim();
                facility.IsAvailable = (this.Controls["chkAvailable"] as CheckBox).Checked;

                if (isEditMode)
                {
                    facilityRepository.UpdateFacility(facility);
                    MessageBox.Show("Facility updated successfully.", "Success",
                                  MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    facilityRepository.AddFacility(facility);
                    MessageBox.Show("Facility added successfully.", "Success",
                                  MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error saving facility: {ex.Message}", "Error",
                              MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void CancelButton_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private bool ValidateInput()
        {
            string code = (this.Controls["txtCode"] as TextBox).Text.Trim();
            string name = (this.Controls["txtName"] as TextBox).Text.Trim();

            if (string.IsNullOrWhiteSpace(code))
            {
                MessageBox.Show("Facility code is required.", "Validation Error",
                              MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            if (string.IsNullOrWhiteSpace(name))
            {
                MessageBox.Show("Facility name is required.", "Validation Error",
                              MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            return true;
        }
    }
}
