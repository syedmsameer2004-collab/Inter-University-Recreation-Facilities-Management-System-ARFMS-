using System;
using System.Drawing;
using System.Windows.Forms;
using ARFMS_System.Models;
using ARFMS_System;

namespace ARFMS.Forms
{
    public partial class UpdateMaintenanceStatusForm : Form
    {
        private User _currentUser;

        public UpdateMaintenanceStatusForm(User user)
        {
            _currentUser = user;
            InitializeComponent();
            LoadMaintenanceSchedules();
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();
            
            // Form properties
            this.Text = "Update Maintenance Status";
            this.Size = new Size(800, 600);
            this.StartPosition = FormStartPosition.CenterParent;

            // Create controls
            CreateControls();
            
            this.ResumeLayout(false);
        }

        private void CreateControls()
        {
            // DataGridView for schedules
            DataGridView dgvSchedules = new DataGridView
            {
                Name = "dgvSchedules",
                Location = new Point(20, 20),
                Size = new Size(740, 400),
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                ReadOnly = true,
                AllowUserToAddRows = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect
            };

            // Status ComboBox
            Label lblStatus = new Label { Text = "New Status:", Location = new Point(20, 440), Size = new Size(80, 23) };
            ComboBox cmbStatus = new ComboBox 
            { 
                Name = "cmbStatus", 
                Location = new Point(110, 440), 
                Size = new Size(150, 23),
                DropDownStyle = ComboBoxStyle.DropDownList
            };
            cmbStatus.Items.AddRange(Enum.GetNames(typeof(MaintenanceStatus)));

            // Buttons
            Button btnUpdate = new Button { Text = "Update Status", Location = new Point(280, 440), Size = new Size(100, 30) };
            Button btnClose = new Button { Text = "Close", Location = new Point(390, 440), Size = new Size(80, 30) };

            btnUpdate.Click += BtnUpdate_Click;
            btnClose.Click += (s, e) => this.Close();

            this.Controls.AddRange(new Control[] { dgvSchedules, lblStatus, cmbStatus, btnUpdate, btnClose });
        }

        private void LoadMaintenanceSchedules()
        {
            try
            {
                var repository = new MaintenanceRepository();
                var schedules = repository.GetSchedulesByStaff(_currentUser.UserID);
                
                var dgv = this.Controls["dgvSchedules"] as DataGridView;
                dgv.DataSource = schedules;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading schedules: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnUpdate_Click(object sender, EventArgs e)
        {
            var dgv = this.Controls["dgvSchedules"] as DataGridView;
            var cmbStatus = this.Controls["cmbStatus"] as ComboBox;

            if (dgv.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a schedule to update.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (cmbStatus.SelectedItem == null)
            {
                MessageBox.Show("Please select a status.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                // Update logic would go here
                MessageBox.Show("Status updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadMaintenanceSchedules();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error updating status: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
