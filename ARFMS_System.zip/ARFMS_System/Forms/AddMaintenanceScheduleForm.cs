using ARFMS.Services;
using ARFMS_System;
using ARFMS_System.Models;

namespace ARFMS.Forms
{
    public partial class AddMaintenanceScheduleForm : Form
    {
        private MaintenanceRepository maintenanceRepository;
        private FacilityRepository facilityRepository;
        private UserRepository userRepository;

        public AddMaintenanceScheduleForm()
        {
            maintenanceRepository = new MaintenanceRepository();
            facilityRepository = new FacilityRepository();
            userRepository = new UserRepository();
            InitializeComponent();
            LoadComboBoxData();
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();

            // Form properties
            this.Text = "Add Maintenance Schedule";
            this.Size = new Size(500, 450);
            this.StartPosition = FormStartPosition.CenterParent;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.BackColor = Color.White;

            // Facility
            Label facilityLabel = new Label();
            facilityLabel.Text = "Facility:";
            facilityLabel.Font = new Font("Segoe UI", 10);
            facilityLabel.Location = new Point(30, 30);
            facilityLabel.Size = new Size(100, 20);
            this.Controls.Add(facilityLabel);

            ComboBox facilityComboBox = new ComboBox();
            facilityComboBox.Name = "cmbFacility";
            facilityComboBox.Font = new Font("Segoe UI", 10);
            facilityComboBox.Location = new Point(140, 28);
            facilityComboBox.Size = new Size(300, 25);
            facilityComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
            this.Controls.Add(facilityComboBox);

            // Maintenance Staff
            Label staffLabel = new Label();
            staffLabel.Text = "Staff:";
            staffLabel.Font = new Font("Segoe UI", 10);
            staffLabel.Location = new Point(30, 70);
            staffLabel.Size = new Size(100, 20);
            this.Controls.Add(staffLabel);

            ComboBox staffComboBox = new ComboBox();
            staffComboBox.Name = "cmbStaff";
            staffComboBox.Font = new Font("Segoe UI", 10);
            staffComboBox.Location = new Point(140, 68);
            staffComboBox.Size = new Size(300, 25);
            staffComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
            this.Controls.Add(staffComboBox);

            // Scheduled Date
            Label dateLabel = new Label();
            dateLabel.Text = "Date:";
            dateLabel.Font = new Font("Segoe UI", 10);
            dateLabel.Location = new Point(30, 110);
            dateLabel.Size = new Size(100, 20);
            this.Controls.Add(dateLabel);

            DateTimePicker datePicker = new DateTimePicker();
            datePicker.Name = "dtpDate";
            datePicker.Font = new Font("Segoe UI", 10);
            datePicker.Location = new Point(140, 108);
            datePicker.Size = new Size(200, 25);
            datePicker.Format = DateTimePickerFormat.Short;
            datePicker.MinDate = DateTime.Today;
            this.Controls.Add(datePicker);

            // Scheduled Time
            Label timeLabel = new Label();
            timeLabel.Text = "Time:";
            timeLabel.Font = new Font("Segoe UI", 10);
            timeLabel.Location = new Point(30, 150);
            timeLabel.Size = new Size(100, 20);
            this.Controls.Add(timeLabel);

            DateTimePicker timePicker = new DateTimePicker();
            timePicker.Name = "dtpTime";
            timePicker.Font = new Font("Segoe UI", 10);
            timePicker.Location = new Point(140, 148);
            timePicker.Size = new Size(150, 25);
            timePicker.Format = DateTimePickerFormat.Time;
            timePicker.ShowUpDown = true;
            this.Controls.Add(timePicker);

            // Maintenance Type
            Label typeLabel = new Label();
            typeLabel.Text = "Type:";
            typeLabel.Font = new Font("Segoe UI", 10);
            typeLabel.Location = new Point(30, 190);
            typeLabel.Size = new Size(100, 20);
            this.Controls.Add(typeLabel);

            ComboBox typeComboBox = new ComboBox();
            typeComboBox.Name = "cmbType";
            typeComboBox.Font = new Font("Segoe UI", 10);
            typeComboBox.Location = new Point(140, 188);
            typeComboBox.Size = new Size(200, 25);
            typeComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
            typeComboBox.Items.AddRange(new string[] { "Routine Cleaning", "Deep Cleaning", "Equipment Check", "Repair", "Inspection" });
            typeComboBox.SelectedIndex = 0;
            this.Controls.Add(typeComboBox);

            // Description
            Label descLabel = new Label();
            descLabel.Text = "Description:";
            descLabel.Font = new Font("Segoe UI", 10);
            descLabel.Location = new Point(30, 230);
            descLabel.Size = new Size(100, 20);
            this.Controls.Add(descLabel);

            TextBox descTextBox = new TextBox();
            descTextBox.Name = "txtDescription";
            descTextBox.Font = new Font("Segoe UI", 10);
            descTextBox.Location = new Point(140, 228);
            descTextBox.Size = new Size(300, 80);
            descTextBox.Multiline = true;
            descTextBox.ScrollBars = ScrollBars.Vertical;
            this.Controls.Add(descTextBox);

            // Save Button
            Button saveButton = new Button();
            saveButton.Text = "Save";
            saveButton.Font = new Font("Segoe UI", 10, FontStyle.Bold);
            saveButton.BackColor = Color.FromArgb(46, 204, 113);
            saveButton.ForeColor = Color.White;
            saveButton.FlatStyle = FlatStyle.Flat;
            saveButton.Location = new Point(250, 350);
            saveButton.Size = new Size(80, 30);
            saveButton.Click += SaveButton_Click;
            this.Controls.Add(saveButton);

            // Cancel Button
            Button cancelButton = new Button();
            cancelButton.Text = "Cancel";
            cancelButton.Font = new Font("Segoe UI", 10);
            cancelButton.BackColor = Color.FromArgb(149, 165, 166);
            cancelButton.ForeColor = Color.White;
            cancelButton.FlatStyle = FlatStyle.Flat;
            cancelButton.Location = new Point(350, 350);
            cancelButton.Size = new Size(80, 30);
            cancelButton.Click += CancelButton_Click;
            this.Controls.Add(cancelButton);

            this.ResumeLayout(false);
        }

        private void LoadComboBoxData()
        {
            try
            {
                // Load facilities
                List<Facility> facilities = facilityRepository.GetAllFacilities();
                ComboBox facilityComboBox = this.Controls["cmbFacility"] as ComboBox;
                facilityComboBox.DataSource = facilities;
                facilityComboBox.DisplayMember = "FacilityName";
                facilityComboBox.ValueMember = "FacilityID";

                // Load maintenance staff
                List<User> maintenanceStaff = userRepository.GetUsersByRole(UserRole.MaintenanceStaff);
                ComboBox staffComboBox = this.Controls["cmbStaff"] as ComboBox;
                staffComboBox.DataSource = maintenanceStaff;
                staffComboBox.DisplayMember = "FullName";
                staffComboBox.ValueMember = "UserID";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading data: {ex.Message}", "Error",
                              MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void SaveButton_Click(object sender, EventArgs e)
        {
            try
            {
                if (!ValidateInput())
                    return;

                MaintenanceSchedule schedule = new MaintenanceSchedule();
                schedule.FacilityID = Convert.ToInt32((this.Controls["cmbFacility"] as ComboBox).SelectedValue);
                schedule.MaintenanceStaffID = Convert.ToInt32((this.Controls["cmbStaff"] as ComboBox).SelectedValue);
                schedule.ScheduledDate = (this.Controls["dtpDate"] as DateTimePicker).Value.Date;
                schedule.ScheduledTime = (this.Controls["dtpTime"] as DateTimePicker).Value.TimeOfDay;
                schedule.MaintenanceType = (this.Controls["cmbType"] as ComboBox).SelectedItem.ToString();
                schedule.Description = (this.Controls["txtDescription"] as TextBox).Text.Trim();
                schedule.Status = MaintenanceStatus.Scheduled;
                schedule.AssignedBy = AuthenticationService.CurrentUser.UserID;

                maintenanceRepository.AddMaintenanceSchedule(schedule);
                MessageBox.Show("Maintenance schedule added successfully.", "Success",
                              MessageBoxButtons.OK, MessageBoxIcon.Information);

                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error saving schedule: {ex.Message}", "Error",
                              MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void CancelButton_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private bool ValidateInput()
        {
            ComboBox facilityComboBox = this.Controls["cmbFacility"] as ComboBox;
            ComboBox staffComboBox = this.Controls["cmbStaff"] as ComboBox;

            if (facilityComboBox.SelectedValue == null)
            {
                MessageBox.Show("Please select a facility.", "Validation Error",
                              MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            if (staffComboBox.SelectedValue == null)
            {
                MessageBox.Show("Please select maintenance staff.", "Validation Error",
                              MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            return true;
        }
    }
}
