﻿using ARFMS.Services;
using ARFMS_System.Models;
using System;
using System.Drawing;
using System.Windows.Forms;

namespace ARFMS.Forms
{
    public partial class StudentHomeForm : Form
    {
        public StudentHomeForm()
        {
            InitializeComponent();      // Calls base form init
            SetupResponsiveUI();        // Our new layout method
        }

        /* ----------------------------------------------------- */
        /* 1. Basic form properties + scaling                    */
        /* ----------------------------------------------------- */
        private void SetupResponsiveUI()
        {
            this.Text = "ARFMS - Student Dashboard";
            this.StartPosition = FormStartPosition.CenterScreen;

            // 1.1 Scaling & minimum size
            this.AutoScaleMode = AutoScaleMode.Dpi;     // or Font
            this.AutoSize = true;
            this.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            this.MinimumSize = new Size(800, 600);

            // 1.2 Create the container panels
            var headerPanel = CreateHeaderPanel();
            var mainPanel = CreateMainPanel();

            this.Controls.Add(mainPanel);
            this.Controls.Add(headerPanel);
        }

        /* ----------------------------------------------------- */
        /* 2. Header – Top panel with title & logout button     */
        /* ----------------------------------------------------- */
        private Panel CreateHeaderPanel()
        {
            var panel = new Panel
            {
                BackColor = Color.FromArgb(155, 89, 182),
                Dock = DockStyle.Top,
                Height = 80
            };

            // Title
            var title = new Label
            {
                Text = "Student Dashboard",
                Font = new Font("Segoe UI", 18, FontStyle.Bold),
                ForeColor = Color.White,
                Location = new Point(20, 20),
                AutoSize = true
            };

            // Welcome
            var welcome = new Label
            {
                Text = $"Welcome, {AuthenticationService.GetCurrentUserFullName()}",
                Font = new Font("Segoe UI", 12),
                ForeColor = Color.White,
                Location = new Point(20, 50),
                AutoSize = true
            };

            // Logout
            var logout = new Button
            {
                Text = "Logout",
                Font = new Font("Segoe UI", 10),
                BackColor = Color.FromArgb(231, 76, 60),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Size = new Size(100, 30),
                Anchor = AnchorStyles.Top | AnchorStyles.Right,
                Location = new Point(this.Width - 120, 25)  // will adjust in Resize
            };
            logout.Click += LogoutButton_Click;

            // Adjust position when form resizes
            this.Resize += (s, e) => {
                logout.Location = new Point(this.ClientSize.Width - 120, 25);
            };

            panel.Controls.AddRange(new Control[] { title, welcome, logout });
            return panel;
        }

        /* ----------------------------------------------------- */
        /* 3. Main Panel – TableLayoutPanel (3 columns)          */
        /* ----------------------------------------------------- */
        private TableLayoutPanel CreateMainPanel()
        {
            var tlp = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                Padding = new Padding(20),
                ColumnCount = 3,
                RowCount = 2,
                AutoSize = true,
                AutoSizeMode = AutoSizeMode.GrowAndShrink
            };

            // Each column is 33% of the width
            tlp.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33F));
            tlp.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33F));
            tlp.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 34F));

            // Rows: 120px height (fixed), second row 120px
            tlp.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tlp.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tlp.AutoSize = false;
            tlp.AutoSizeMode = AutoSizeMode.GrowAndShrink;

            // Create all 6 buttons using a helper
            var buttons = new[]
            {
                CreateMenuButton("Search Facilities", "Find Available Sports & Recreation Facilities"),
                CreateMenuButton("My Bookings",        "View & Manage Your Bookings"),
                CreateMenuButton("Submit Review",      "Rate & Review Facilities"),
                CreateMenuButton("My Profile",         "Update Your Profile Information"),
                CreateMenuButton("Booking History",    "View Your Past Bookings"),
                CreateMenuButton("Help & Support",     "Get Help & Contact Support")
            };

            // Add buttons to the grid
            tlp.Controls.Add(buttons[0], 0, 0);
            tlp.Controls.Add(buttons[1], 1, 0);
            tlp.Controls.Add(buttons[2], 2, 0);
            tlp.Controls.Add(buttons[3], 0, 1);
            tlp.Controls.Add(buttons[4], 1, 1);
            tlp.Controls.Add(buttons[5], 2, 1);

            // Hook up events
            buttons[0].Click += SearchFacilitiesButton_Click;
            buttons[1].Click += MyBookingsButton_Click;
            buttons[2].Click += SubmitReviewButton_Click;
            buttons[3].Click += MyProfileButton_Click;
            buttons[4].Click += HistoryButton_Click;
            buttons[5].Click += HelpButton_Click;

            return tlp;
        }

        /* ----------------------------------------------------- */
        /* 4. Button Helper – creates a nicely styled button     */
        /* ----------------------------------------------------- */
        private Button CreateMenuButton(string title, string description)
        {
            var btn = new Button
            {
                Text = $"{title}\n{description}",
                Font = new Font("Segoe UI", 11, FontStyle.Bold),
                BackColor = Color.FromArgb(52, 152, 219),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                FlatAppearance = { BorderSize = 0 },
                Dock = DockStyle.Fill,               // Fills the cell
                TextAlign = ContentAlignment.MiddleCenter,
                Cursor = Cursors.Hand
            };

            // Hover
            btn.MouseEnter += (s, e) => btn.BackColor = Color.FromArgb(41, 128, 185);
            btn.MouseLeave += (s, e) => btn.BackColor = Color.FromArgb(52, 152, 219);

            return btn;
        }

        /* ----------------------------------------------------- */
        /* 5. Event Handlers – unchanged from your original code  */
        /* ----------------------------------------------------- */
        private void SearchFacilitiesButton_Click(object sender, EventArgs e)
        {
            var form = new SearchFacilitiesForm();
            form.ShowDialog();
        }

        private void MyBookingsButton_Click(object sender, EventArgs e)
        {
            var form = new MyBookingsForm();
            form.ShowDialog();
        }

        private void SubmitReviewButton_Click(object sender, EventArgs e)
        {
            var form = new SubmitReviewForm();
            form.ShowDialog();
        }

        private void MyProfileButton_Click(object sender, EventArgs e)
        {
            var form = new StudentProfileForm();
            form.ShowDialog();
        }

        private void HistoryButton_Click(object sender, EventArgs e)
        {
            var form = new BookingHistoryForm();
            form.ShowDialog();
        }

        private void HelpButton_Click(object sender, EventArgs e)
        {
            MessageBox.Show("For assistance, please contact the reception desk or email support@arfms.com",
                            "Help & Support", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        /* ----------------------------------------------------- */
        /* 6. Logout – same as original                          */
        /* ----------------------------------------------------- */
        private void LogoutButton_Click(object sender, EventArgs e)
        {
            var result = MessageBox.Show("Are you sure you want to log out?", "Confirm Logout",
                                         MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                // TODO: clean up sessions, etc.
                Application.Exit();           // or navigate to login
            }
        }

        /* ----------------------------------------------------- */
        /* 6. Designer‑generated method (you can delete it)      */
        /* ----------------------------------------------------- */
        private void InitializeComponent()
        {
            // Nothing needed here – we build everything manually
            this.SuspendLayout();
            this.Load += (s, e) => { };
            this.ResumeLayout(false);
        }
    }
}
