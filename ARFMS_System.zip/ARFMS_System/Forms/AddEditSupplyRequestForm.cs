using ARFMS_System;
using ARFMS_System.Models;
using ARFMS_System.Data; // Added missing using directive for Data namespace
using System;
using System.Drawing;
using System.Windows.Forms;

namespace ARFMS.Forms
{
    public partial class AddEditSupplyRequestForm : Form
    {
        private User _currentUser;
        private int? _requestId;
        private CleaningSupplyRepository _supplyRepository;
        private bool _isEditMode;

        public AddEditSupplyRequestForm(User user, int? requestId = null)
        {
            _currentUser = user;
            _requestId = requestId;
            _isEditMode = _requestId.HasValue;
            _supplyRepository = new CleaningSupplyRepository();
            InitializeComponent();
            LoadSupplies();

            if (_isEditMode)
            {
                LoadRequestData();
            }
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();

            this.Size = new Size(450, 350);
            this.Text = _isEditMode ? "Edit Supply Request" : "Add Supply Request";
            this.StartPosition = FormStartPosition.CenterParent;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.BackColor = Color.White;

            // Supply Label & ComboBox
            var supplyLabel = new Label
            {
                Text = "Supply:",
                Font = new Font("Segoe UI", 10),
                Location = new Point(30, 30),
                Size = new Size(80, 20)
            };

            var supplyComboBox = new ComboBox
            {
                Name = "cmbSupply",
                Font = new Font("Segoe UI", 10),
                Location = new Point(120, 28),
                Size = new Size(280, 25),
                DropDownStyle = ComboBoxStyle.DropDownList
            };

            // Quantity Label & TextBox
            var quantityLabel = new Label
            {
                Text = "Quantity:",
                Font = new Font("Segoe UI", 10),
                Location = new Point(30, 70),
                Size = new Size(80, 20)
            };

            var quantityTextBox = new TextBox
            {
                Name = "txtQuantity",
                Font = new Font("Segoe UI", 10),
                Location = new Point(120, 68),
                Size = new Size(100, 25)
            };

            // Notes Label & TextBox
            var notesLabel = new Label
            {
                Text = "Notes:",
                Font = new Font("Segoe UI", 10),
                Location = new Point(30, 110),
                Size = new Size(80, 20)
            };

            var notesTextBox = new TextBox
            {
                Name = "txtNotes",
                Font = new Font("Segoe UI", 10),
                Location = new Point(120, 108),
                Size = new Size(280, 80),
                Multiline = true,
                ScrollBars = ScrollBars.Vertical
            };

            // Save Button
            var saveButton = new Button
            {
                Text = "Save",
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                BackColor = Color.FromArgb(46, 204, 113),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Location = new Point(200, 220),
                Size = new Size(80, 30)
            };
            saveButton.Click += SaveButton_Click;

            // Cancel Button
            var cancelButton = new Button
            {
                Text = "Cancel",
                Font = new Font("Segoe UI", 10),
                BackColor = Color.FromArgb(149, 165, 166),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Location = new Point(300, 220),
                Size = new Size(80, 30)
            };
            cancelButton.Click += (s, e) => { this.DialogResult = DialogResult.Cancel; this.Close(); };

            this.Controls.AddRange(new Control[] {
                supplyLabel, supplyComboBox, quantityLabel, quantityTextBox,
                notesLabel, notesTextBox, saveButton, cancelButton
            });

            this.ResumeLayout(false);
        }

        private void LoadSupplies()
        {
            try
            {
                var supplies = _supplyRepository.GetAllSupplies();
                var supplyComboBox = this.Controls["cmbSupply"] as ComboBox;

                supplyComboBox.DataSource = supplies;
                supplyComboBox.DisplayMember = "SupplyName";
                supplyComboBox.ValueMember = "SupplyID";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading supplies: {ex.Message}", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadRequestData()
        {
            // Implementation for loading existing request data in edit mode
            // This would require additional repository methods
        }

        private void SaveButton_Click(object sender, EventArgs e)
        {
            try
            {
                if (!ValidateInput()) return;

                var supplyComboBox = this.Controls["cmbSupply"] as ComboBox;
                var quantityTextBox = this.Controls["txtQuantity"] as TextBox;
                var notesTextBox = this.Controls["txtNotes"] as TextBox;

                var request = new SupplyRequest
                {
                    SupplyID = (int)supplyComboBox.SelectedValue,
                    RequestedBy = _currentUser.UserId, // Fixed property name from UserID to UserId to match User model
                    QuantityRequested = int.Parse(quantityTextBox.Text),
                    Notes = notesTextBox.Text.Trim(),
                    RequestDate = DateTime.Now,
                    Status = RequestStatus.Pending
                };

                bool success = false;
                if (_requestId.HasValue)
                {
                    request.SupplyRequestID = _requestId.Value;
                    success = _supplyRepository.UpdateSupplyRequest(request);
                }
                else
                {
                    success = _supplyRepository.AddSupplyRequest(request);
                }

                if (success)
                {
                    MessageBox.Show("Supply request saved successfully!", "Success",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);

                    this.DialogResult = DialogResult.OK;
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Failed to save supply request. Please try again.", "Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error saving request: {ex.Message}", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private bool ValidateInput()
        {
            var supplyComboBox = this.Controls["cmbSupply"] as ComboBox;
            var quantityTextBox = this.Controls["txtQuantity"] as TextBox;

            if (supplyComboBox.SelectedValue == null)
            {
                MessageBox.Show("Please select a supply.", "Validation Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            if (!int.TryParse(quantityTextBox.Text, out int quantity) || quantity <= 0)
            {
                MessageBox.Show("Please enter a valid quantity.", "Validation Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            return true;
        }
    }
}
