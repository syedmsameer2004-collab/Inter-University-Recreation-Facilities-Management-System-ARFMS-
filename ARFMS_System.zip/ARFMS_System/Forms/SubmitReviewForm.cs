using System;
using System.Drawing;
using System.Windows.Forms;
using ARFMS_System.Models;
using ARFMS_System;
using ARFMS.Services;

namespace ARFMS.Forms
{
    public partial class SubmitReviewForm : Form
    {
        private User currentUser;
        private int facilityId;

        public SubmitReviewForm(User user, int facilityId)
        {
            this.currentUser = user;
            this.facilityId = facilityId;
            InitializeComponent();
            SetupUI();
        }

        public SubmitReviewForm()
        {
            this.currentUser = AuthenticationService.CurrentUser;
            this.facilityId = 0; // Will be set when facility is selected or passed in constructor
            InitializeComponent();
            SetupUI();
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();
            this.ResumeLayout(false);
        }

        private void SetupUI()
        {
            this.Text = "Submit Review - ARFMS";
            this.Size = new Size(400, 350);
            this.StartPosition = FormStartPosition.CenterParent;

            Label lblFacility = new Label { Text = "Facility:", Location = new Point(20, 20), Size = new Size(100, 23) };
            ComboBox cmbFacility = new ComboBox
            {
                Name = "cmbFacility",
                Location = new Point(130, 20),
                Size = new Size(200, 23),
                DropDownStyle = ComboBoxStyle.DropDownList,
                Visible = facilityId == 0 // Only show if no facility ID provided
            };

            if (facilityId == 0)
            {
                LoadFacilities(cmbFacility);
                this.Controls.AddRange(new Control[] { lblFacility, cmbFacility });
            }

            int yOffset = facilityId == 0 ? 60 : 20;

            Label lblRating = new Label { Text = "Rating (1-5):", Location = new Point(20, yOffset), Size = new Size(100, 23) };
            NumericUpDown nudRating = new NumericUpDown { Name = "nudRating", Location = new Point(130, yOffset), Size = new Size(100, 23), Minimum = 1, Maximum = 5, Value = 5 };

            Label lblComment = new Label { Text = "Comment:", Location = new Point(20, yOffset + 40), Size = new Size(100, 23) };
            TextBox txtComment = new TextBox { Name = "txtComment", Location = new Point(20, yOffset + 70), Size = new Size(340, 100), Multiline = true };

            Button btnSubmit = new Button { Text = "Submit Review", Location = new Point(20, yOffset + 190), Size = new Size(100, 30) };
            Button btnCancel = new Button { Text = "Cancel", Location = new Point(130, yOffset + 190), Size = new Size(100, 30) };

            btnSubmit.Click += (s, e) =>
            {
                try
                {
                    int selectedFacilityId = facilityId;
                    if (facilityId == 0)
                    {
                        var facilityCombo = this.Controls["cmbFacility"] as ComboBox;
                        if (facilityCombo?.SelectedValue == null)
                        {
                            MessageBox.Show("Please select a facility.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }
                        selectedFacilityId = (int)facilityCombo.SelectedValue;
                    }

                    if (currentUser?.UserID == null || currentUser.UserID == 0)
                    {
                        MessageBox.Show("User authentication error. Please login again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    var repository = new ReviewRepository();
                    repository.AddReview(new Review
                    {
                        StudentID = currentUser.UserID,
                        FacilityID = selectedFacilityId,
                        Rating = (int)((NumericUpDown)this.Controls["nudRating"]).Value,
                        ReviewText = ((TextBox)this.Controls["txtComment"]).Text,
                        ReviewDate = DateTime.Now
                    });
                    MessageBox.Show("Review submitted successfully!");
                    this.DialogResult = DialogResult.OK;
                    this.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error submitting review: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            };

            btnCancel.Click += (s, e) => { this.DialogResult = DialogResult.Cancel; this.Close(); };

            this.Controls.AddRange(new Control[] { lblRating, nudRating, lblComment, txtComment, btnSubmit, btnCancel });
        }

        private void LoadFacilities(ComboBox cmbFacility)
        {
            try
            {
                var repository = new FacilityRepository();
                var facilities = repository.GetAllFacilities();

                cmbFacility.DataSource = facilities;
                cmbFacility.DisplayMember = "FacilityName";
                cmbFacility.ValueMember = "FacilityID";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading facilities: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
