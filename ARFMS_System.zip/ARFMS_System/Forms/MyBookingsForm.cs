﻿using ARFMS.Services;
using ARFMS_System;
using ARFMS_System.Models;

namespace ARFMS.Forms
{
    public partial class MyBookingsForm : Form
    {
        private BookingRepository bookingRepository;
        private DataGridView bookingsDataGridView;

        public MyBookingsForm()
        {
            bookingRepository = new BookingRepository();
            InitializeComponent();
            LoadMyBookings();
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();

            // Form properties
            this.Text = "My Bookings";
            this.Size = new Size(1000, 600);
            this.StartPosition = FormStartPosition.CenterParent;
            this.BackColor = Color.White;

            // Header Panel
            Panel headerPanel = new Panel();
            headerPanel.BackColor = Color.FromArgb(155, 89, 182);
            headerPanel.Dock = DockStyle.Top;
            headerPanel.Height = 60;
            this.Controls.Add(headerPanel);

            // Title Label
            Label titleLabel = new Label();
            titleLabel.Text = "My Bookings";
            titleLabel.Font = new Font("Segoe UI", 16, FontStyle.Bold);
            titleLabel.ForeColor = Color.White;
            titleLabel.Location = new Point(20, 15);
            titleLabel.Size = new Size(150, 30);
            headerPanel.Controls.Add(titleLabel);

            // Button Panel
            Panel buttonPanel = new Panel();
            buttonPanel.Dock = DockStyle.Top;
            buttonPanel.Height = 50;
            buttonPanel.BackColor = Color.FromArgb(236, 240, 241);
            this.Controls.Add(buttonPanel);

            // Refresh Button
            Button refreshButton = new Button();
            refreshButton.Text = "Refresh";
            refreshButton.Font = new Font("Segoe UI", 10);
            refreshButton.BackColor = Color.FromArgb(52, 152, 219);
            refreshButton.ForeColor = Color.White;
            refreshButton.FlatStyle = FlatStyle.Flat;
            refreshButton.Location = new Point(20, 10);
            refreshButton.Size = new Size(80, 30);
            refreshButton.Click += RefreshButton_Click;
            buttonPanel.Controls.Add(refreshButton);

            // Cancel Booking Button
            Button cancelButton = new Button();
            cancelButton.Text = "Cancel Booking";
            cancelButton.Font = new Font("Segoe UI", 10, FontStyle.Bold);
            cancelButton.BackColor = Color.FromArgb(231, 76, 60);
            cancelButton.ForeColor = Color.White;
            cancelButton.FlatStyle = FlatStyle.Flat;
            cancelButton.Location = new Point(110, 10);
            cancelButton.Size = new Size(120, 30);
            cancelButton.Click += CancelButton_Click;
            buttonPanel.Controls.Add(cancelButton);

            // DataGridView
            bookingsDataGridView = new DataGridView();
            bookingsDataGridView.Dock = DockStyle.Fill;
            bookingsDataGridView.BackgroundColor = Color.White;
            bookingsDataGridView.BorderStyle = BorderStyle.None;
            bookingsDataGridView.AllowUserToAddRows = false;
            bookingsDataGridView.AllowUserToDeleteRows = false;
            bookingsDataGridView.ReadOnly = true;
            bookingsDataGridView.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            bookingsDataGridView.MultiSelect = false;
            bookingsDataGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            bookingsDataGridView.RowHeadersVisible = false;
            this.Controls.Add(bookingsDataGridView); // Add the DataGridView last

            this.ResumeLayout(false);
        }

        private void LoadMyBookings()
        {
            try
            {
                List<Booking> allBookings = bookingRepository.GetAllBookings();
                List<Booking> myBookings = allBookings.Where(b => b.StudentID == AuthenticationService.CurrentUser.UserID).ToList();

                var displayData = myBookings.Select(b => new
                {
                    BookingID = b.BookingID,
                    FacilityName = b.Facility?.FacilityName ?? "Unknown",
                    FacilityCode = b.Facility?.FacilityCode ?? "Unknown",
                    BookingDate = b.BookingDate.ToString("yyyy-MM-dd"),
                    StartTime = b.StartTime.ToString(@"hh\:mm"),
                    EndTime = b.EndTime.ToString(@"hh\:mm"),
                    Duration = $"{b.Duration} hour(s)",
                    TotalAmount = b.TotalAmount.ToString("C"),
                    BookingStatus = b.BookingStatus.ToString(),
                    PaymentStatus = b.PaymentStatus.ToString(),
                    CreatedDate = b.CreatedDate.ToString("yyyy-MM-dd"),
                    Notes = b.Notes ?? ""
                }).OrderByDescending(b => b.CreatedDate).ToList();

                bookingsDataGridView.DataSource = displayData;

                // Configure columns
                if (bookingsDataGridView.Columns.Count > 0)
                {
                    bookingsDataGridView.Columns["BookingID"].Visible = false;
                    bookingsDataGridView.Columns["FacilityName"].HeaderText = "Facility";
                    bookingsDataGridView.Columns["FacilityCode"].HeaderText = "Code";
                    bookingsDataGridView.Columns["BookingDate"].HeaderText = "Date";
                    bookingsDataGridView.Columns["StartTime"].HeaderText = "Start";
                    bookingsDataGridView.Columns["EndTime"].HeaderText = "End";
                    bookingsDataGridView.Columns["Duration"].HeaderText = "Duration";
                    bookingsDataGridView.Columns["TotalAmount"].HeaderText = "Amount";
                    bookingsDataGridView.Columns["BookingStatus"].HeaderText = "Status";
                    bookingsDataGridView.Columns["PaymentStatus"].HeaderText = "Payment";
                    bookingsDataGridView.Columns["CreatedDate"].HeaderText = "Booked On";
                    bookingsDataGridView.Columns["Notes"].HeaderText = "Notes";
                    // … after you add the grid to Controls
                    bookingsDataGridView.Dock = DockStyle.Fill;
                    bookingsDataGridView.BringToFront();     // <‑‑ this is the one‑liner that fixes the overlap

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading bookings: {ex.Message}", "Error",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void RefreshButton_Click(object sender, EventArgs e)
        {
            LoadMyBookings();
        }

        private void CancelButton_Click(object sender, EventArgs e)
        {
            if (bookingsDataGridView.SelectedRows.Count > 0)
            {
                string status = bookingsDataGridView.SelectedRows[0].Cells["BookingStatus"].Value.ToString();
                string facilityName = bookingsDataGridView.SelectedRows[0].Cells["FacilityName"].Value.ToString();

                if (status != "Pending")
                {
                    MessageBox.Show("Only pending bookings can be cancelled.", "Cannot Cancel",
                                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                DialogResult result = MessageBox.Show($"Are you sure you want to cancel the booking for '{facilityName}'?",
                                                     "Confirm Cancellation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (result == DialogResult.Yes)
                {
                    try
                    {
                        int bookingId = Convert.ToInt32(bookingsDataGridView.SelectedRows[0].Cells["BookingID"].Value);

                        // Get the booking and update its status
                        List<Booking> allBookings = bookingRepository.GetAllBookings();
                        Booking booking = allBookings.FirstOrDefault(b => b.BookingID == bookingId);

                        if (booking != null)
                        {
                            booking.BookingStatus = BookingStatus.Cancelled;
                            bookingRepository.UpdateBooking(booking);

                            LoadMyBookings();
                            MessageBox.Show("Booking cancelled successfully.", "Success",
                                            MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Error cancelling booking: {ex.Message}", "Error",
                                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select a booking to cancel.", "No Selection",
                                MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
    }
}