using System;
using System.Drawing;
using System.Windows.Forms;
using ARFMS_System.Models;
using ARFMS_System;

namespace ARFMS.Forms
{
    public partial class EquipmentRequestForm : Form
    {
        private User _currentUser;

        public EquipmentRequestForm(User user)
        {
            _currentUser = user;
            InitializeComponent();
            LoadFacilities();
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();

            // Form properties
            this.Text = "Equipment Request";
            this.Size = new Size(500, 450);
            this.StartPosition = FormStartPosition.CenterParent;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;

            CreateControls();

            this.ResumeLayout(false);
        }

        private void CreateControls()
        {
            // Facility
            Label lblFacility = new Label { Text = "Facility:", Location = new Point(20, 20), Size = new Size(100, 23) };
            ComboBox cmbFacility = new ComboBox
            {
                Name = "cmbFacility",
                Location = new Point(130, 20),
                Size = new Size(200, 23),
                DropDownStyle = ComboBoxStyle.DropDownList
            };

            // Request Type
            Label lblRequestType = new Label { Text = "Request Type:", Location = new Point(20, 60), Size = new Size(100, 23) };
            ComboBox cmbRequestType = new ComboBox
            {
                Name = "cmbRequestType",
                Location = new Point(130, 60),
                Size = new Size(200, 23),
                DropDownStyle = ComboBoxStyle.DropDownList
            };
            cmbRequestType.Items.AddRange(Enum.GetNames(typeof(RequestType)));

            // Item Name
            Label lblItemName = new Label { Text = "Item Name:", Location = new Point(20, 100), Size = new Size(100, 23) };
            TextBox txtItemName = new TextBox { Name = "txtItemName", Location = new Point(130, 100), Size = new Size(200, 23) };

            // Description
            Label lblDescription = new Label { Text = "Description:", Location = new Point(20, 140), Size = new Size(100, 23) };
            TextBox txtDescription = new TextBox
            {
                Name = "txtDescription",
                Location = new Point(130, 140),
                Size = new Size(200, 80),
                Multiline = true
            };

            // Quantity
            Label lblQuantity = new Label { Text = "Quantity:", Location = new Point(20, 240), Size = new Size(100, 23) };
            NumericUpDown nudQuantity = new NumericUpDown
            {
                Name = "nudQuantity",
                Location = new Point(130, 240),
                Size = new Size(100, 23),
                Minimum = 1,
                Maximum = 100,
                Value = 1
            };

            // Priority
            Label lblPriority = new Label { Text = "Priority:", Location = new Point(20, 280), Size = new Size(100, 23) };
            ComboBox cmbPriority = new ComboBox
            {
                Name = "cmbPriority",
                Location = new Point(130, 280),
                Size = new Size(200, 23),
                DropDownStyle = ComboBoxStyle.DropDownList
            };
            cmbPriority.Items.AddRange(Enum.GetNames(typeof(Priority)));

            // Buttons
            Button btnSubmit = new Button { Text = "Submit Request", Location = new Point(130, 330), Size = new Size(100, 30) };
            Button btnCancel = new Button { Text = "Cancel", Location = new Point(240, 330), Size = new Size(80, 30) };

            btnSubmit.Click += BtnSubmit_Click;
            btnCancel.Click += (s, e) => { this.DialogResult = DialogResult.Cancel; this.Close(); };

            this.Controls.AddRange(new Control[] {
                lblFacility, cmbFacility, lblRequestType, cmbRequestType,
                lblItemName, txtItemName, lblDescription, txtDescription,
                lblQuantity, nudQuantity, lblPriority, cmbPriority,
                btnSubmit, btnCancel
            });
        }

        private void LoadFacilities()
        {
            try
            {
                var repository = new FacilityRepository();
                var facilities = repository.GetAllFacilities();

                var cmbFacility = this.Controls["cmbFacility"] as ComboBox;
                cmbFacility.DataSource = facilities;
                cmbFacility.DisplayMember = "FacilityName";
                cmbFacility.ValueMember = "FacilityID";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading facilities: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                // Validation and submission logic would go here
                var cmbFacility = this.Controls["cmbFacility"] as ComboBox;
                var cmbRequestType = this.Controls["cmbRequestType"] as ComboBox;
                var txtItemName = this.Controls["txtItemName"] as TextBox;
                var txtDescription = this.Controls["txtDescription"] as TextBox;
                var nudQuantity = this.Controls["nudQuantity"] as NumericUpDown;
                var cmbPriority = this.Controls["cmbPriority"] as ComboBox;

                // Validation
                if (cmbFacility.SelectedValue == null)
                {
                    MessageBox.Show("Please select a facility.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (cmbRequestType.SelectedItem == null)
                {
                    MessageBox.Show("Please select a request type.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (string.IsNullOrWhiteSpace(txtItemName.Text))
                {
                    MessageBox.Show("Please enter an item name.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (cmbPriority.SelectedItem == null)
                {
                    MessageBox.Show("Please select a priority level.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                var equipmentRequest = new EquipmentRequest
                {
                    FacilityID = (int)cmbFacility.SelectedValue,
                    RequestedBy = _currentUser.UserID,
                    RequestType = (RequestType)Enum.Parse(typeof(RequestType), cmbRequestType.SelectedItem.ToString()),
                    ItemName = txtItemName.Text.Trim(),
                    Description = txtDescription.Text.Trim(),
                    Quantity = (int)nudQuantity.Value,
                    Priority = (Priority)Enum.Parse(typeof(Priority), cmbPriority.SelectedItem.ToString()),
                    Status = RequestStatus.Pending,
                    RequestDate = DateTime.Now
                };

                var repository = new MaintenanceRepository();
                int requestId = repository.AddEquipmentRequest(equipmentRequest);

                MessageBox.Show($"Equipment request submitted successfully! Request ID: {requestId}", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error submitting request: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
