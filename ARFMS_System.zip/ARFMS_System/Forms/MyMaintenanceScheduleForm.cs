using ARFMS_System;
using ARFMS_System.Models;
using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace ARFMS.Forms
{
    public partial class MyMaintenanceScheduleForm : Form
    {
        private User _currentUser;
        private MaintenanceRepository _maintenanceRepository;
        private DataGridView _scheduleGrid;

        public MyMaintenanceScheduleForm(User user)
        {
            _currentUser = user;
            _maintenanceRepository = new MaintenanceRepository();
            InitializeComponent();
            LoadSchedule();
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();
            
            this.Size = new Size(1000, 600);
            this.Text = "My Maintenance Schedule";
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.FromArgb(240, 248, 255);

            // Header
            var headerLabel = new Label
            {
                Text = "My Maintenance Schedule",
                Font = new Font("Segoe UI", 16, FontStyle.Bold),
                Location = new Point(20, 20),
                AutoSize = true,
                ForeColor = Color.FromArgb(70, 130, 180)
            };

            // Schedule Grid
            _scheduleGrid = new DataGridView
            {
                Location = new Point(20, 60),
                Size = new Size(940, 400),
                BackgroundColor = Color.White,
                BorderStyle = BorderStyle.Fixed3D,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
            };

            // Buttons
            var refreshButton = new Button
            {
                Text = "Refresh",
                Size = new Size(100, 35),
                Location = new Point(20, 480),
                BackColor = Color.FromArgb(70, 130, 180),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            refreshButton.Click += RefreshButton_Click;

            var closeButton = new Button
            {
                Text = "Close",
                Size = new Size(100, 35),
                Location = new Point(860, 480),
                BackColor = Color.FromArgb(108, 117, 125),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            closeButton.Click += (s, e) => this.Close();

            this.Controls.AddRange(new Control[] {
                headerLabel, _scheduleGrid, refreshButton, closeButton
            });
            
            this.ResumeLayout(false);
        }

        private void LoadSchedule()
        {
            try
            {
                var schedules = _maintenanceRepository.GetSchedulesByStaff(_currentUser.UserID);

                _scheduleGrid.DataSource = schedules.Select(s => new
                {
                    ScheduleId = s.ScheduleId,
                    FacilityName = s.FacilityName,
                    MaintenanceType = s.MaintenanceType,
                    ScheduledDate = s.ScheduledDate.ToString("dd/MM/yyyy"),
                    Status = s.Status.ToString(),
                    Description = s.Description,
                    EstimatedHours = s.EstimatedHours
                }).ToList();

                // Customize column headers
                _scheduleGrid.Columns["ScheduleId"].HeaderText = "Schedule ID";
                _scheduleGrid.Columns["FacilityName"].HeaderText = "Facility";
                _scheduleGrid.Columns["MaintenanceType"].HeaderText = "Type";
                _scheduleGrid.Columns["ScheduledDate"].HeaderText = "Scheduled Date";
                _scheduleGrid.Columns["Status"].HeaderText = "Status";
                _scheduleGrid.Columns["Description"].HeaderText = "Description";
                _scheduleGrid.Columns["EstimatedHours"].HeaderText = "Est. Hours";

                // Hide ScheduleId column
                _scheduleGrid.Columns["ScheduleId"].Visible = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading schedule: {ex.Message}", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void RefreshButton_Click(object sender, EventArgs e)
        {
            LoadSchedule();
        }
    }
}
