using ARFMS.Services;
using ARFMS_System;
using ARFMS_System.Models;

namespace ARFMS.Forms
{
    public partial class StudentProfileForm : Form
    {
        private UserRepository userRepository;
        private User currentUser;

        public StudentProfileForm()
        {
            userRepository = new UserRepository();
            currentUser = AuthenticationService.CurrentUser;
            InitializeComponent();
            LoadUserData();
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();

            // Form properties
            this.Text = "My Profile";
            this.Size = new Size(450, 400);
            this.StartPosition = FormStartPosition.CenterParent;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.BackColor = Color.White;

            // Header Panel
            Panel headerPanel = new Panel();
            headerPanel.BackColor = Color.FromArgb(155, 89, 182);
            headerPanel.Dock = DockStyle.Top;
            headerPanel.Height = 60;
            this.Controls.Add(headerPanel);

            // Title Label
            Label titleLabel = new Label();
            titleLabel.Text = "My Profile";
            titleLabel.Font = new Font("Segoe UI", 16, FontStyle.Bold);
            titleLabel.ForeColor = Color.White;
            titleLabel.Location = new Point(20, 15);
            titleLabel.Size = new Size(150, 30);
            headerPanel.Controls.Add(titleLabel);

            // Username Label & TextBox
            Label usernameLabel = new Label();
            usernameLabel.Text = "Username:";
            usernameLabel.Font = new Font("Segoe UI", 10);
            usernameLabel.Location = new Point(30, 90);
            usernameLabel.Size = new Size(80, 20);
            this.Controls.Add(usernameLabel);

            TextBox usernameTextBox = new TextBox();
            usernameTextBox.Name = "txtUsername";
            usernameTextBox.Font = new Font("Segoe UI", 10);
            usernameTextBox.Location = new Point(120, 88);
            usernameTextBox.Size = new Size(280, 25);
            usernameTextBox.ReadOnly = true;
            usernameTextBox.BackColor = Color.FromArgb(236, 240, 241);
            this.Controls.Add(usernameTextBox);

            // Email Label & TextBox
            Label emailLabel = new Label();
            emailLabel.Text = "Email:";
            emailLabel.Font = new Font("Segoe UI", 10);
            emailLabel.Location = new Point(30, 130);
            emailLabel.Size = new Size(80, 20);
            this.Controls.Add(emailLabel);

            TextBox emailTextBox = new TextBox();
            emailTextBox.Name = "txtEmail";
            emailTextBox.Font = new Font("Segoe UI", 10);
            emailTextBox.Location = new Point(120, 128);
            emailTextBox.Size = new Size(280, 25);
            this.Controls.Add(emailTextBox);

            // First Name Label & TextBox
            Label firstNameLabel = new Label();
            firstNameLabel.Text = "First Name:";
            firstNameLabel.Font = new Font("Segoe UI", 10);
            firstNameLabel.Location = new Point(30, 170);
            firstNameLabel.Size = new Size(80, 20);
            this.Controls.Add(firstNameLabel);

            TextBox firstNameTextBox = new TextBox();
            firstNameTextBox.Name = "txtFirstName";
            firstNameTextBox.Font = new Font("Segoe UI", 10);
            firstNameTextBox.Location = new Point(120, 168);
            firstNameTextBox.Size = new Size(280, 25);
            this.Controls.Add(firstNameTextBox);

            // Last Name Label & TextBox
            Label lastNameLabel = new Label();
            lastNameLabel.Text = "Last Name:";
            lastNameLabel.Font = new Font("Segoe UI", 10);
            lastNameLabel.Location = new Point(30, 210);
            lastNameLabel.Size = new Size(80, 20);
            this.Controls.Add(lastNameLabel);

            TextBox lastNameTextBox = new TextBox();
            lastNameTextBox.Name = "txtLastName";
            lastNameTextBox.Font = new Font("Segoe UI", 10);
            lastNameTextBox.Location = new Point(120, 208);
            lastNameTextBox.Size = new Size(280, 25);
            this.Controls.Add(lastNameTextBox);

            // Phone Label & TextBox
            Label phoneLabel = new Label();
            phoneLabel.Text = "Phone:";
            phoneLabel.Font = new Font("Segoe UI", 10);
            phoneLabel.Location = new Point(30, 250);
            phoneLabel.Size = new Size(80, 20);
            this.Controls.Add(phoneLabel);

            TextBox phoneTextBox = new TextBox();
            phoneTextBox.Name = "txtPhone";
            phoneTextBox.Font = new Font("Segoe UI", 10);
            phoneTextBox.Location = new Point(120, 248);
            phoneTextBox.Size = new Size(280, 25);
            this.Controls.Add(phoneTextBox);

            // Change Password Button
            Button changePasswordButton = new Button();
            changePasswordButton.Text = "Change Password";
            changePasswordButton.Font = new Font("Segoe UI", 10);
            changePasswordButton.BackColor = Color.FromArgb(52, 152, 219);
            changePasswordButton.ForeColor = Color.White;
            changePasswordButton.FlatStyle = FlatStyle.Flat;
            changePasswordButton.Location = new Point(120, 290);
            changePasswordButton.Size = new Size(130, 30);
            changePasswordButton.Click += ChangePasswordButton_Click;
            this.Controls.Add(changePasswordButton);

            // Update Button
            Button updateButton = new Button();
            updateButton.Text = "Update";
            updateButton.Font = new Font("Segoe UI", 10, FontStyle.Bold);
            updateButton.BackColor = Color.FromArgb(46, 204, 113);
            updateButton.ForeColor = Color.White;
            updateButton.FlatStyle = FlatStyle.Flat;
            updateButton.Location = new Point(260, 290);
            updateButton.Size = new Size(80, 30);
            updateButton.Click += UpdateButton_Click;
            this.Controls.Add(updateButton);

            // Close Button
            Button closeButton = new Button();
            closeButton.Text = "Close";
            closeButton.Font = new Font("Segoe UI", 10);
            closeButton.BackColor = Color.FromArgb(149, 165, 166);
            closeButton.ForeColor = Color.White;
            closeButton.FlatStyle = FlatStyle.Flat;
            closeButton.Location = new Point(350, 290);
            closeButton.Size = new Size(80, 30);
            closeButton.Click += CloseButton_Click;
            this.Controls.Add(closeButton);

            this.ResumeLayout(false);
        }

        private void LoadUserData()
        {
            if (currentUser != null)
            {
                (this.Controls["txtUsername"] as TextBox).Text = currentUser.Username;
                (this.Controls["txtEmail"] as TextBox).Text = currentUser.Email;
                (this.Controls["txtFirstName"] as TextBox).Text = currentUser.FirstName;
                (this.Controls["txtLastName"] as TextBox).Text = currentUser.LastName;
                (this.Controls["txtPhone"] as TextBox).Text = currentUser.PhoneNumber;
            }
        }

        private void UpdateButton_Click(object sender, EventArgs e)
        {
            try
            {
                if (!ValidateInput())
                    return;

                currentUser.Email = (this.Controls["txtEmail"] as TextBox).Text.Trim();
                currentUser.FirstName = (this.Controls["txtFirstName"] as TextBox).Text.Trim();
                currentUser.LastName = (this.Controls["txtLastName"] as TextBox).Text.Trim();
                currentUser.PhoneNumber = (this.Controls["txtPhone"] as TextBox).Text.Trim();

                userRepository.UpdateUser(currentUser);

                MessageBox.Show("Profile updated successfully.", "Success",
                              MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error updating profile: {ex.Message}", "Error",
                              MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ChangePasswordButton_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Password change functionality will be implemented in future versions.",
                          "Coming Soon", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void CloseButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private bool ValidateInput()
        {
            string email = (this.Controls["txtEmail"] as TextBox).Text.Trim();
            string firstName = (this.Controls["txtFirstName"] as TextBox).Text.Trim();
            string lastName = (this.Controls["txtLastName"] as TextBox).Text.Trim();

            if (string.IsNullOrWhiteSpace(email))
            {
                MessageBox.Show("Email is required.", "Validation Error",
                              MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            if (string.IsNullOrWhiteSpace(firstName))
            {
                MessageBox.Show("First name is required.", "Validation Error",
                              MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            if (string.IsNullOrWhiteSpace(lastName))
            {
                MessageBox.Show("Last name is required.", "Validation Error",
                              MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            return true;
        }
    }
}
