﻿using ARFMS.Services;
using System;
using System.Drawing;
using System.Windows.Forms;

namespace ARFMS.Forms
{
    public partial class ReceptionHomeForm : Form
    {
        public ReceptionHomeForm()
        {
            InitializeComponent();
            SetupCustomUI();
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();
            // Basic form initialization - custom UI is handled in SetupCustomUI
            this.ResumeLayout(false);
        }

        private void SetupCustomUI()
        {
            // Form properties
            this.Text = "ARFMS - Reception Dashboard";
            this.Size = new Size(1000, 700);
            this.FormBorderStyle = FormBorderStyle.Sizable;
            this.BackColor = Color.White;

            // Root layout: 2 rows (header auto, content fill)
            var root = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 1,
                RowCount = 2,
                BackColor = Color.White
            };
            root.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            root.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
            this.Controls.Add(root);

            // ===== Header (TableLayout) =====
            var header = new TableLayoutPanel
            {
                Dock = DockStyle.Top,
                BackColor = Color.FromArgb(46, 204, 113),
                ColumnCount = 2,
                RowCount = 1,
                Padding = new Padding(20, 10, 20, 10),
                Height = 80,
                AutoSize = true
            };
            header.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f)); // left grows
            header.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));       // right fits logout
            root.Controls.Add(header, 0, 0);

            // Left stack for title + welcome
            var leftStack = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 1,
                RowCount = 2,
            };
            leftStack.RowStyles.Add(new RowStyle(SizeType.Percent, 60f));
            leftStack.RowStyles.Add(new RowStyle(SizeType.Percent, 40f));
            header.Controls.Add(leftStack, 0, 0);

            var titleLabel = new Label
            {
                Text = "Reception Dashboard",
                Font = new Font("Segoe UI", 18, FontStyle.Bold),
                ForeColor = Color.White,
                AutoSize = true,
                Anchor = AnchorStyles.Left | AnchorStyles.Bottom
            };
            leftStack.Controls.Add(titleLabel, 0, 0);

            var welcomeLabel = new Label
            {
                Text = $"Welcome, {AuthenticationService.GetCurrentUserFullName()}",
                Font = new Font("Segoe UI", 12),
                ForeColor = Color.White,
                AutoSize = true,
                Anchor = AnchorStyles.Left | AnchorStyles.Top
            };
            leftStack.Controls.Add(welcomeLabel, 0, 1);

            var logoutButton = new Button
            {
                Text = "Logout",
                Font = new Font("Segoe UI", 10),
                BackColor = Color.FromArgb(231, 76, 60),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                AutoSize = true,
                Anchor = AnchorStyles.Right
            };
            logoutButton.FlatAppearance.BorderSize = 0;
            logoutButton.Margin = new Padding(10, 0, 0, 0);
            logoutButton.Click += LogoutButton_Click;
            header.Controls.Add(logoutButton, 1, 0);

            // ===== Main grid (TableLayout) for menu buttons: 3 columns x 2 rows =====
            var grid = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                Padding = new Padding(20),
                ColumnCount = 3,
                RowCount = 2
            };
            grid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.33f));
            grid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.33f));
            grid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.34f));
            grid.RowStyles.Add(new RowStyle(SizeType.Percent, 50f));
            grid.RowStyles.Add(new RowStyle(SizeType.Percent, 50f));
            root.Controls.Add(grid, 0, 1);

            // Create and place menu buttons into grid cells
            CreateMenuButtons(grid);
        }

        private void CreateMenuButtons(TableLayoutPanel grid)
        {
            var studentMgmtButton = CreateMenuButton("Student Management", "Add & Manage Student Accounts");
            studentMgmtButton.Click += StudentMgmtButton_Click;
            grid.Controls.Add(studentMgmtButton, 0, 0);

            var bookingMgmtButton = CreateMenuButton("Booking Management", "Accept & Manage Bookings");
            bookingMgmtButton.Click += BookingMgmtButton_Click;
            grid.Controls.Add(bookingMgmtButton, 1, 0);

            var paymentButton = CreateMenuButton("Payment Processing", "Process Payments & Generate Receipts");
            paymentButton.Click += PaymentButton_Click;
            grid.Controls.Add(paymentButton, 2, 0);

            var searchButton = CreateMenuButton("Search Bookings", "Search by Student or Facility");
            searchButton.Click += SearchButton_Click;
            grid.Controls.Add(searchButton, 0, 1);

            var reviewsButton = CreateMenuButton("View Reviews", "View Student Reviews & Ratings");
            reviewsButton.Click += ReviewsButton_Click;
            grid.Controls.Add(reviewsButton, 1, 1);

            var reportsButton = CreateMenuButton("Reports", "Booking & Payment Reports");
            reportsButton.Click += ReportsButton_Click;
            grid.Controls.Add(reportsButton, 2, 1);
        }

        private Button CreateMenuButton(string title, string description)
        {
            var button = new Button
            {
                Text = $"{title}\n{description}",
                Font = new Font("Segoe UI", 11, FontStyle.Bold),
                BackColor = Color.FromArgb(52, 152, 219),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Dock = DockStyle.Fill,
                TextAlign = ContentAlignment.MiddleCenter,
                Cursor = Cursors.Hand,
                Margin = new Padding(10),
                MinimumSize = new Size(200, 110)
            };
            button.FlatAppearance.BorderSize = 0;

            // Hover effects
            button.MouseEnter += (s, e) => button.BackColor = Color.FromArgb(41, 128, 185);
            button.MouseLeave += (s, e) => button.BackColor = Color.FromArgb(52, 152, 219);

            return button;
        }

        private void StudentMgmtButton_Click(object sender, EventArgs e)
        {
            var studentForm = new StudentManagementForm();
            studentForm.ShowDialog();
        }

        private void BookingMgmtButton_Click(object sender, EventArgs e)
        {
            var bookingForm = new BookingManagementForm();
            bookingForm.ShowDialog();
        }

        private void PaymentButton_Click(object sender, EventArgs e)
        {
            var paymentForm = new PaymentProcessingForm();
            paymentForm.ShowDialog();
        }

        private void SearchButton_Click(object sender, EventArgs e)
        {
            var searchForm = new SearchBookingsForm();
            searchForm.ShowDialog();
        }

        private void ReviewsButton_Click(object sender, EventArgs e)
        {
            var reviewsForm = new ViewReviewsForm();
            reviewsForm.ShowDialog();
        }

        private void ReportsButton_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Reports functionality will be implemented in future versions.",
                "Coming Soon", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void LogoutButton_Click(object sender, EventArgs e)
        {
            var result = MessageBox.Show("Are you sure you want to logout?",
                "Confirm Logout", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                var authService = new AuthenticationService();
                authService.Logout();

                var loginForm = new LoginForm();
                loginForm.Show();
                this.Close();
            }
        }
    }
}
