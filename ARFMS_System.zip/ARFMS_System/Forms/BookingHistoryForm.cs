﻿using System;
using System.Drawing;
using System.Windows.Forms;
using ARFMS_System.Models;
using ARFMS_System;
using ARFMS.Services;

namespace ARFMS.Forms
{
    public partial class BookingHistoryForm : Form
    {
        private User currentUser;

        // Controls as fields for responsiveness
        private DataGridView dgvBookings;
        private Button btnClose;
        private TableLayoutPanel layoutRoot;
        private Panel footerPanel;

        public BookingHistoryForm(User user)
        {
            this.currentUser = user;
            InitializeComponent();
            SetupUI();
            LoadBookingHistory();
        }

        public BookingHistoryForm()
        {
            this.currentUser = AuthenticationService.CurrentUser;
            InitializeComponent();
            SetupUI();
            LoadBookingHistory();
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();

            // Form baseline
            this.AutoScaleDimensions = new SizeF(96F, 96F);
            this.AutoScaleMode = AutoScaleMode.Dpi;
            this.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            this.FormBorderStyle = FormBorderStyle.Sizable;
            this.StartPosition = FormStartPosition.CenterParent;
            this.MinimumSize = new Size(1000, 650);   // bigger by default
            this.Size = new Size(1200, 700);
            this.Text = "Booking History - ARFMS";

            // Root layout (3 rows: spacer 50px, grid (fill), footer (auto))
            layoutRoot = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 1,
                RowCount = 3,
                Padding = new Padding(16, 16, 16, 16), // edge padding
            };
            layoutRoot.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            layoutRoot.RowStyles.Add(new RowStyle(SizeType.Absolute, 50F)); // spacer row (50px top gap)
            layoutRoot.RowStyles.Add(new RowStyle(SizeType.Percent, 100F)); // main grid area
            layoutRoot.RowStyles.Add(new RowStyle(SizeType.AutoSize));      // footer

            // Top spacer (actual space above the grid)
            var spacer = new Panel { Dock = DockStyle.Fill };
            layoutRoot.Controls.Add(spacer, 0, 0);

            // Data grid
            dgvBookings = new DataGridView
            {
                Name = "dgvBookings",
                Dock = DockStyle.Fill,
                AutoGenerateColumns = false, // bind to readable properties
                ReadOnly = true,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                RowHeadersVisible = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                MultiSelect = false,
                BackgroundColor = SystemColors.Window,
                BorderStyle = BorderStyle.FixedSingle,
                EnableHeadersVisualStyles = true,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
               // RowTemplate.Height = 32, // Ensuring proper row height
                ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize // Ensuring proper column sizing
            };

            // Readability tweaks
            dgvBookings.ColumnHeadersDefaultCellStyle.Padding = new Padding(6);
            dgvBookings.DefaultCellStyle.Padding = new Padding(4);

            // Define friendly columns (NO IDs)
            dgvBookings.Columns.Add(new DataGridViewTextBoxColumn
            {
                HeaderText = "Booking #",
                DataPropertyName = "BookingId",
                FillWeight = 70,
                SortMode = DataGridViewColumnSortMode.Automatic
            });
            dgvBookings.Columns.Add(new DataGridViewTextBoxColumn
            {
                HeaderText = "Date",
                DataPropertyName = "BookingDate",
                DefaultCellStyle = { Format = "yyyy-MM-dd" },
                FillWeight = 90,
                SortMode = DataGridViewColumnSortMode.Automatic
            });
            dgvBookings.Columns.Add(new DataGridViewTextBoxColumn
            {
                HeaderText = "Start",
                DataPropertyName = "StartTime",
                DefaultCellStyle = { Format = @"hh\:mm" },
                FillWeight = 70,
                SortMode = DataGridViewColumnSortMode.Automatic
            });
            dgvBookings.Columns.Add(new DataGridViewTextBoxColumn
            {
                HeaderText = "End",
                DataPropertyName = "EndTime",
                DefaultCellStyle = { Format = @"hh\:mm" },
                FillWeight = 70,
                SortMode = DataGridViewColumnSortMode.Automatic
            });
            dgvBookings.Columns.Add(new DataGridViewTextBoxColumn
            {
                HeaderText = "Duration (h)",
                DataPropertyName = "Duration",
                FillWeight = 75,
                SortMode = DataGridViewColumnSortMode.Automatic
            });
            dgvBookings.Columns.Add(new DataGridViewTextBoxColumn
            {
                HeaderText = "Facility",
                DataPropertyName = "FacilityName",
                FillWeight = 160,
                SortMode = DataGridViewColumnSortMode.Automatic
            });
            dgvBookings.Columns.Add(new DataGridViewTextBoxColumn
            {
                HeaderText = "Code",
                DataPropertyName = "FacilityCode",
                FillWeight = 80,
                SortMode = DataGridViewColumnSortMode.Automatic
            });
            dgvBookings.Columns.Add(new DataGridViewTextBoxColumn
            {
                HeaderText = "Amount",
                DataPropertyName = "TotalAmount",
                DefaultCellStyle = { Format = "C2" },
                FillWeight = 90,
                SortMode = DataGridViewColumnSortMode.Automatic
            });
            dgvBookings.Columns.Add(new DataGridViewTextBoxColumn
            {
                HeaderText = "Booking Status",
                DataPropertyName = "BookingStatusText",
                FillWeight = 120,
                SortMode = DataGridViewColumnSortMode.Automatic
            });
            dgvBookings.Columns.Add(new DataGridViewTextBoxColumn
            {
                HeaderText = "Payment",
                DataPropertyName = "PaymentStatusText",
                FillWeight = 90,
                SortMode = DataGridViewColumnSortMode.Automatic
            });
            dgvBookings.Columns.Add(new DataGridViewTextBoxColumn
            {
                HeaderText = "Created By",
                DataPropertyName = "CreatedByName",
                FillWeight = 120,
                SortMode = DataGridViewColumnSortMode.Automatic
            });
            dgvBookings.Columns.Add(new DataGridViewTextBoxColumn
            {
                HeaderText = "Notes",
                DataPropertyName = "Notes",
                FillWeight = 180,
                SortMode = DataGridViewColumnSortMode.Automatic
            });

            // Add grid to row 1 (middle row)
            layoutRoot.Controls.Add(dgvBookings, 0, 1);

            // Footer (Close button aligned right)
            footerPanel = new Panel { Dock = DockStyle.Fill, Height = 50 };
            btnClose = new Button
            {
                Name = "btnClose",
                Text = "Close",
                AutoSize = true,
                Anchor = AnchorStyles.Right | AnchorStyles.Bottom
            };
            btnClose.Click += (s, e) => this.Close();

            var footerFlow = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                FlowDirection = FlowDirection.RightToLeft,
                Padding = new Padding(0),
                Margin = new Padding(0),
                AutoSize = true,
                WrapContents = false
            };
            footerFlow.Controls.Add(btnClose);
            footerPanel.Controls.Add(footerFlow);

            // Footer in the last row
            layoutRoot.Controls.Add(footerPanel, 0, 2);

            // Compose
            this.Controls.Add(layoutRoot);
            this.ResumeLayout(false);
        }

        private void SetupUI()
        {
            this.Text = "Booking History - ARFMS";
            EnableDoubleBuffering(dgvBookings);

            // Ensure DataGridView fills its container properly
            dgvBookings.Dock = DockStyle.Fill;
            dgvBookings.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders;
          //  dgvBookings.AdjustRowHeights();
        }

        private void LoadBookingHistory()
        {
            try
            {
                if (currentUser != null)
                {
                    var repository = new BookingRepository();
                    // Repository already maps names into Booking (Student/Facility/CreatedBy)
                    var bookings = repository.GetBookingsByStudent(currentUser.UserID);

                    dgvBookings.DataSource = bookings;

                    // Force DataGridView to adjust layout
                    dgvBookings.Refresh();
                }
                else
                {
                    MessageBox.Show("No user is currently authenticated.", "ARFMS",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading booking history: {ex.Message}", "ARFMS",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private static void EnableDoubleBuffering(Control control)
        {
            const int WS_EX_COMPOSITED = 0x2000000;
            if (control == null) return;

            var windowHandle = control.Handle;
            var extendedStyle = GetWindowLong(windowHandle, GWL.EXSTYLE);
            SetWindowLong(windowHandle, GWL.EXSTYLE, extendedStyle | WS_EX_COMPOSITED);
        }

        private enum GWL
        {
            EXSTYLE = -20
        }

        [System.Runtime.InteropServices.DllImport("user32.dll")]
        private static extern int GetWindowLong(IntPtr hWnd, GWL nIndex);

        [System.Runtime.InteropServices.DllImport("user32.dll")]
        private static extern int SetWindowLong(IntPtr hWnd, GWL nIndex, int dwNewLong);
    }
}
