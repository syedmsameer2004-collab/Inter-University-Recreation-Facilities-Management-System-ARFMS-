using ARFMS_System;
using ARFMS_System.Models;

namespace ARFMS.Forms
{
    public partial class MaintenanceSchedulingForm : Form
    {
        private MaintenanceRepository maintenanceRepository;
        private FacilityRepository facilityRepository;
        private UserRepository userRepository;
        private DataGridView schedulesDataGridView;

        public MaintenanceSchedulingForm()
        {
            maintenanceRepository = new MaintenanceRepository();
            facilityRepository = new FacilityRepository();
            userRepository = new UserRepository();
            InitializeComponent();
            LoadSchedules();
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();

            // Form properties
            this.Text = "Maintenance Scheduling";
            this.Size = new Size(1100, 600);
            this.StartPosition = FormStartPosition.CenterParent;
            this.BackColor = Color.White;

            // Header Panel
            Panel headerPanel = new Panel();
            headerPanel.BackColor = Color.FromArgb(41, 128, 185);
            headerPanel.Dock = DockStyle.Top;
            headerPanel.Height = 60;
            //this.Controls.Add(headerPanel);

            // Title Label
            Label titleLabel = new Label();
            titleLabel.Text = "Maintenance Scheduling";
            titleLabel.Font = new Font("Segoe UI", 16, FontStyle.Bold);
            titleLabel.ForeColor = Color.White;
            titleLabel.Location = new Point(20, 15);
            titleLabel.Size = new Size(300, 30);
            headerPanel.Controls.Add(titleLabel);

            // Button Panel
            Panel buttonPanel = new Panel();
            buttonPanel.Dock = DockStyle.Top;
            buttonPanel.Height = 50;
            buttonPanel.BackColor = Color.FromArgb(236, 240, 241);
            //this.Controls.Add(buttonPanel);

            // Add Schedule Button
            Button addScheduleButton = new Button();
            addScheduleButton.Text = "Add Schedule";
            addScheduleButton.Font = new Font("Segoe UI", 10, FontStyle.Bold);
            addScheduleButton.BackColor = Color.FromArgb(46, 204, 113);
            addScheduleButton.ForeColor = Color.White;
            addScheduleButton.FlatStyle = FlatStyle.Flat;
            addScheduleButton.Location = new Point(20, 10);
            addScheduleButton.Size = new Size(120, 30);
            addScheduleButton.Click += AddScheduleButton_Click;
            buttonPanel.Controls.Add(addScheduleButton);

            // Refresh Button
            Button refreshButton = new Button();
            refreshButton.Text = "Refresh";
            refreshButton.Font = new Font("Segoe UI", 10);
            refreshButton.BackColor = Color.FromArgb(52, 152, 219);
            refreshButton.ForeColor = Color.White;
            refreshButton.FlatStyle = FlatStyle.Flat;
            refreshButton.Location = new Point(150, 10);
            refreshButton.Size = new Size(80, 30);
            refreshButton.Click += RefreshButton_Click;
            buttonPanel.Controls.Add(refreshButton);

            // DataGridView
            schedulesDataGridView = new DataGridView();
            schedulesDataGridView.Dock = DockStyle.Fill;
            schedulesDataGridView.BackgroundColor = Color.White;
            schedulesDataGridView.BorderStyle = BorderStyle.None;
            schedulesDataGridView.AllowUserToAddRows = false;
            schedulesDataGridView.AllowUserToDeleteRows = false;
            schedulesDataGridView.ReadOnly = true;
            schedulesDataGridView.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            schedulesDataGridView.MultiSelect = false;
            schedulesDataGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            schedulesDataGridView.RowHeadersVisible = false;
            //this.Controls.Add(schedulesDataGridView);

            this.ResumeLayout(false);

            TableLayoutPanel tlp = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,   // TLP fills the form
                ColumnCount = 1,
                RowCount = 3,
                Padding = new Padding(0),  // optional � keeps things flush
                Margin = new Padding(0)
            };

            // Row 0 � Header panel � absolute height
            tlp.RowStyles.Add(new RowStyle(SizeType.Absolute, headerPanel.Height));
            // Row 1 � Button panel � absolute height
            tlp.RowStyles.Add(new RowStyle(SizeType.Absolute, buttonPanel.Height));
            // Row 2 � DataGridView � takes the rest
            tlp.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));

            // Place the three controls in the TLP
            tlp.Controls.Add(headerPanel, 0, 0);  // (column, row)
            tlp.Controls.Add(buttonPanel, 0, 1);
            tlp.Controls.Add(schedulesDataGridView, 0, 2);

            // Finally, add the TLP to the form
            this.Controls.Add(tlp);
        }

        private void LoadSchedules()
        {
            try
            {
                List<MaintenanceSchedule> schedules = maintenanceRepository.GetAllMaintenanceSchedules();

                var displayData = schedules.Select(s => new
                {
                    ScheduleID = s.ScheduleID,
                    Facility = s.Facility?.FacilityName ?? "Unknown",
                    MaintenanceStaff = s.MaintenanceStaff?.FullName ?? "Unknown",
                    ScheduledDate = s.ScheduledDate.ToString("yyyy-MM-dd"),
                    ScheduledTime = s.ScheduledTime.ToString(@"hh\:mm"),
                    MaintenanceType = s.MaintenanceType,
                    Status = s.Status.ToString(),
                    AssignedBy = s.AssignedByUser?.FullName ?? "Unknown",
                    CreatedDate = s.CreatedDate.ToString("yyyy-MM-dd")
                }).ToList();

                schedulesDataGridView.DataSource = displayData;

                // Configure columns
                if (schedulesDataGridView.Columns.Count > 0)
                {
                    schedulesDataGridView.Columns["ScheduleID"].Visible = false;
                    schedulesDataGridView.Columns["Facility"].HeaderText = "Facility";
                    schedulesDataGridView.Columns["MaintenanceStaff"].HeaderText = "Staff";
                    schedulesDataGridView.Columns["ScheduledDate"].HeaderText = "Date";
                    schedulesDataGridView.Columns["ScheduledTime"].HeaderText = "Time";
                    schedulesDataGridView.Columns["MaintenanceType"].HeaderText = "Type";
                    schedulesDataGridView.Columns["Status"].HeaderText = "Status";
                    schedulesDataGridView.Columns["AssignedBy"].HeaderText = "Assigned By";
                    schedulesDataGridView.Columns["CreatedDate"].HeaderText = "Created";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading schedules: {ex.Message}", "Error",
                              MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void AddScheduleButton_Click(object sender, EventArgs e)
        {
            AddMaintenanceScheduleForm addScheduleForm = new AddMaintenanceScheduleForm();
            if (addScheduleForm.ShowDialog() == DialogResult.OK)
            {
                LoadSchedules();
            }
        }

        private void RefreshButton_Click(object sender, EventArgs e)
        {
            LoadSchedules();
        }
    }
}
