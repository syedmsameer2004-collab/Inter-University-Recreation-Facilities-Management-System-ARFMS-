using ARFMS.Services;
using ARFMS_System;
using ARFMS_System.Models;

namespace ARFMS.Forms
{
    public partial class PaymentProcessingForm : Form
    {
        private PaymentRepository paymentRepository;
        private BookingRepository bookingRepository;
        private ComboBox bookingComboBox;
        private TextBox amountTextBox;
        private ComboBox paymentMethodComboBox;
        private Button processButton;
        private Button generateReceiptButton;

        public PaymentProcessingForm()
        {
            paymentRepository = new PaymentRepository();
            bookingRepository = new BookingRepository();
            InitializeComponent();
            LoadPendingBookings();
        }

        private void InitializeComponent()
        {
            this.Text = "Payment Processing";
            this.Size = new Size(500, 400);
            this.StartPosition = FormStartPosition.CenterScreen;

            // Booking selection
            Label bookingLabel = new Label();
            bookingLabel.Text = "Select Booking:";
            bookingLabel.Location = new Point(20, 20);
            bookingLabel.Size = new Size(100, 20);
            this.Controls.Add(bookingLabel);

            bookingComboBox = new ComboBox();
            bookingComboBox.Location = new Point(130, 20);
            bookingComboBox.Size = new Size(300, 25);
            bookingComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
            bookingComboBox.SelectedIndexChanged += BookingComboBox_SelectedIndexChanged;
            this.Controls.Add(bookingComboBox);

            // Amount
            Label amountLabel = new Label();
            amountLabel.Text = "Amount:";
            amountLabel.Location = new Point(20, 60);
            amountLabel.Size = new Size(100, 20);
            this.Controls.Add(amountLabel);

            amountTextBox = new TextBox();
            amountTextBox.Location = new Point(130, 60);
            amountTextBox.Size = new Size(150, 25);
            amountTextBox.ReadOnly = true;
            this.Controls.Add(amountTextBox);

            // Payment method
            Label methodLabel = new Label();
            methodLabel.Text = "Payment Method:";
            methodLabel.Location = new Point(20, 100);
            methodLabel.Size = new Size(100, 20);
            this.Controls.Add(methodLabel);

            paymentMethodComboBox = new ComboBox();
            paymentMethodComboBox.Location = new Point(130, 100);
            paymentMethodComboBox.Size = new Size(150, 25);
            paymentMethodComboBox.Items.AddRange(new string[] { "Cash"}); // can add credit card etc. later
            paymentMethodComboBox.SelectedIndex = 0;
            this.Controls.Add(paymentMethodComboBox);

            // Buttons
            processButton = new Button();
            processButton.Text = "Process Payment";
            processButton.Location = new Point(130, 150);
            processButton.Size = new Size(120, 30);
            processButton.Click += ProcessButton_Click;
            this.Controls.Add(processButton);

            generateReceiptButton = new Button();
            generateReceiptButton.Text = "Generate Receipt";
            generateReceiptButton.Location = new Point(270, 150);
            generateReceiptButton.Size = new Size(120, 30);
            generateReceiptButton.Click += GenerateReceiptButton_Click;
            this.Controls.Add(generateReceiptButton);
        }

        private void LoadPendingBookings()
        {
            var bookings = bookingRepository.GetBookingsByStatus(BookingStatus.Confirmed);
            bookingComboBox.DataSource = bookings;
            bookingComboBox.DisplayMember = "DisplayText";
            bookingComboBox.ValueMember = "BookingId";
        }

        private void BookingComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (bookingComboBox.SelectedItem is Booking booking)
            {
                amountTextBox.Text = booking.TotalAmount.ToString("C");
            }
        }

        private void ProcessButton_Click(object sender, EventArgs e)
        {
            if (bookingComboBox.SelectedItem is Booking booking)
            {
                Payment payment = new Payment
                {
                    BookingID = booking.BookingID,
                    Amount = booking.TotalAmount,
                    PaymentMethod = (PaymentMethod)Enum.Parse(typeof(PaymentMethod), paymentMethodComboBox.SelectedItem.ToString().Replace(" ", "")),
                    PaymentDate = DateTime.Now,
                    Status = PaymentStatus.Paid,
                    ReceiptNumber= Payment.GenerateReceiptNumber(),
                    ProcessedBy = AuthenticationService.CurrentUser.UserID

                };

                paymentRepository.AddPayment(payment);
                bookingRepository.UpdateBookingStatus(booking.BookingID, BookingStatus.Confirmed);

                MessageBox.Show("Payment processed successfully!");
                LoadPendingBookings();
            }
        }

        private void GenerateReceiptButton_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Receipt generation functionality will be implemented.");
        }
    }
}
