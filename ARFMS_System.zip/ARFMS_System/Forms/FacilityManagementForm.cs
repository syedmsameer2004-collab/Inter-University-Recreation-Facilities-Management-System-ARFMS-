using ARFMS_System;
using ARFMS_System.Models;

namespace ARFMS.Forms
{
    public partial class FacilityManagementForm : Form
    {
        private FacilityRepository facilityRepository;
        private DataGridView facilitiesDataGridView;

        public FacilityManagementForm()
        {
            facilityRepository = new FacilityRepository();
            InitializeComponent();
            LoadFacilities();
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();

            // Form properties
            this.Text = "Facility Management";
            this.Size = new Size(1000, 600);
            this.StartPosition = FormStartPosition.CenterParent;
            this.BackColor = Color.White;

            // Header Panel
            Panel headerPanel = new Panel();
            headerPanel.BackColor = Color.FromArgb(41, 128, 185);
            headerPanel.Dock = DockStyle.Top;
            headerPanel.Height = 60;
            //this.Controls.Add(headerPanel);

            // Title Label
            Label titleLabel = new Label();
            titleLabel.Text = "Facility Management";
            titleLabel.Font = new Font("Segoe UI", 16, FontStyle.Bold);
            titleLabel.ForeColor = Color.White;
            titleLabel.Location = new Point(20, 15);
            titleLabel.Size = new Size(250, 30);
            headerPanel.Controls.Add(titleLabel);

            // Button Panel
            Panel buttonPanel = new Panel();
            buttonPanel.Dock = DockStyle.Top;
            buttonPanel.Height = 50;
            buttonPanel.BackColor = Color.FromArgb(236, 240, 241);
            //this.Controls.Add(buttonPanel);

            // Add Facility Button
            Button addFacilityButton = new Button();
            addFacilityButton.Text = "Add Facility";
            addFacilityButton.Font = new Font("Segoe UI", 10, FontStyle.Bold);
            addFacilityButton.BackColor = Color.FromArgb(46, 204, 113);
            addFacilityButton.ForeColor = Color.White;
            addFacilityButton.FlatStyle = FlatStyle.Flat;
            addFacilityButton.Location = new Point(20, 10);
            addFacilityButton.Size = new Size(120, 30);
            addFacilityButton.Click += AddFacilityButton_Click;
            buttonPanel.Controls.Add(addFacilityButton);

            // Refresh Button
            Button refreshButton = new Button();
            refreshButton.Text = "Refresh";
            refreshButton.Font = new Font("Segoe UI", 10);
            refreshButton.BackColor = Color.FromArgb(52, 152, 219);
            refreshButton.ForeColor = Color.White;
            refreshButton.FlatStyle = FlatStyle.Flat;
            refreshButton.Location = new Point(150, 10);
            refreshButton.Size = new Size(80, 30);
            refreshButton.Click += RefreshButton_Click;
            buttonPanel.Controls.Add(refreshButton);

            // DataGridView
            facilitiesDataGridView = new DataGridView();
            facilitiesDataGridView.Dock = DockStyle.Fill;
            facilitiesDataGridView.BackgroundColor = Color.White;
            facilitiesDataGridView.BorderStyle = BorderStyle.None;
            facilitiesDataGridView.AllowUserToAddRows = false;
            facilitiesDataGridView.AllowUserToDeleteRows = false;
            facilitiesDataGridView.ReadOnly = true;
            facilitiesDataGridView.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            facilitiesDataGridView.MultiSelect = false;
            facilitiesDataGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            facilitiesDataGridView.RowHeadersVisible = false;
            facilitiesDataGridView.CellDoubleClick += FacilitiesDataGridView_CellDoubleClick;
            //this.Controls.Add(facilitiesDataGridView);

            // Context Menu
            ContextMenuStrip contextMenu = new ContextMenuStrip();

            ToolStripMenuItem editMenuItem = new ToolStripMenuItem("Edit Facility");
            editMenuItem.Click += EditMenuItem_Click;
            contextMenu.Items.Add(editMenuItem);

            ToolStripMenuItem deleteMenuItem = new ToolStripMenuItem("Delete Facility");
            deleteMenuItem.Click += DeleteMenuItem_Click;
            contextMenu.Items.Add(deleteMenuItem);

            facilitiesDataGridView.ContextMenuStrip = contextMenu;

            this.ResumeLayout(false);


            TableLayoutPanel tlp = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 1,
                RowCount = 3,
                Padding = new Padding(0),   // keep controls flush to the edges
                Margin = new Padding(0)
            };

            // Define the row heights � first two are *absolute* (panel heights), last one is *percent*
            tlp.RowStyles.Add(new RowStyle(SizeType.Absolute, headerPanel.Height));      // row 0
            tlp.RowStyles.Add(new RowStyle(SizeType.Absolute, buttonPanel.Height));      // row 1
            tlp.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));                     // row 2

            // Place the controls inside the TLP
            tlp.Controls.Add(headerPanel, 0, 0);
            tlp.Controls.Add(buttonPanel, 0, 1);          // <-- this is your buttonPanel
            tlp.Controls.Add(facilitiesDataGridView, 0, 2);

            // Add the whole TLP to the form *instead* of the individual controls
            this.Controls.Add(tlp);
        }

        private void LoadFacilities()
        {
            try
            {
                List<Facility> facilities = facilityRepository.GetAllFacilities();

                var displayData = facilities.Select(f => new
                {
                    FacilityID = f.FacilityID,
                    FacilityCode = f.FacilityCode,
                    FacilityName = f.FacilityName,
                    Type = f.FacilityType?.TypeName ?? "Unknown",
                    University = f.University?.UniversityName ?? "Unknown",
                    Location = f.Location,
                    Capacity = f.Capacity,
                    HourlyRate = f.HourlyRate.ToString("C"),
                    Available = f.IsAvailable ? "Yes" : "No",
                    CreatedDate = f.CreatedDate.ToString("yyyy-MM-dd")
                }).ToList();

                facilitiesDataGridView.DataSource = displayData;

                // Configure columns
                if (facilitiesDataGridView.Columns.Count > 0)
                {
                    facilitiesDataGridView.Columns["FacilityID"].Visible = false;
                    facilitiesDataGridView.Columns["FacilityCode"].HeaderText = "Code";
                    facilitiesDataGridView.Columns["FacilityName"].HeaderText = "Name";
                    facilitiesDataGridView.Columns["Type"].HeaderText = "Type";
                    facilitiesDataGridView.Columns["University"].HeaderText = "University";
                    facilitiesDataGridView.Columns["Location"].HeaderText = "Location";
                    facilitiesDataGridView.Columns["Capacity"].HeaderText = "Capacity";
                    facilitiesDataGridView.Columns["HourlyRate"].HeaderText = "Rate/Hour";
                    facilitiesDataGridView.Columns["Available"].HeaderText = "Available";
                    facilitiesDataGridView.Columns["CreatedDate"].HeaderText = "Created";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading facilities: {ex.Message}", "Error",
                              MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void AddFacilityButton_Click(object sender, EventArgs e)
        {
            AddEditFacilityForm addFacilityForm = new AddEditFacilityForm();
            if (addFacilityForm.ShowDialog() == DialogResult.OK)
            {
                LoadFacilities();
            }
        }

        private void RefreshButton_Click(object sender, EventArgs e)
        {
            LoadFacilities();
        }

        private void FacilitiesDataGridView_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            EditSelectedFacility();
        }

        private void EditMenuItem_Click(object sender, EventArgs e)
        {
            EditSelectedFacility();
        }

        private void DeleteMenuItem_Click(object sender, EventArgs e)
        {
            DeleteSelectedFacility();
        }

        private void EditSelectedFacility()
        {
            if (facilitiesDataGridView.SelectedRows.Count > 0)
            {
                int facilityId = Convert.ToInt32(facilitiesDataGridView.SelectedRows[0].Cells["FacilityID"].Value);
                List<Facility> facilities = facilityRepository.GetAllFacilities();
                Facility facility = facilities.FirstOrDefault(f => f.FacilityID == facilityId);

                if (facility != null)
                {
                    AddEditFacilityForm editFacilityForm = new AddEditFacilityForm(facility);
                    if (editFacilityForm.ShowDialog() == DialogResult.OK)
                    {
                        LoadFacilities();
                    }
                }
            }
        }

        private void DeleteSelectedFacility()
        {
            if (facilitiesDataGridView.SelectedRows.Count > 0)
            {
                string facilityName = facilitiesDataGridView.SelectedRows[0].Cells["FacilityName"].Value.ToString();

                DialogResult result = MessageBox.Show($"Are you sure you want to delete facility '{facilityName}'?",
                                                    "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                if (result == DialogResult.Yes)
                {
                    try
                    {
                        int facilityId = Convert.ToInt32(facilitiesDataGridView.SelectedRows[0].Cells["FacilityID"].Value);
                        facilityRepository.DeleteFacility(facilityId);
                        LoadFacilities();
                        MessageBox.Show("Facility deleted successfully.", "Success",
                                      MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Error deleting facility: {ex.Message}", "Error",
                                      MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }
    }
}
