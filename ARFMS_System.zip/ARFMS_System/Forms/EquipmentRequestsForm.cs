﻿using ARFMS.Services;
using ARFMS_System;
using ARFMS_System.Models;
using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using System.Collections.Generic;

namespace ARFMS.Forms
{
    public partial class EquipmentRequestsForm : Form
    {
        private MaintenanceRepository maintenanceRepository;
        private Panel headerPanel;
        private Label titleLabel;
        private Panel buttonPanel;
        private Button refreshButton;
        private Button approveButton;
        private Button rejectButton;
        private DataGridView requestsDataGridView;

        public EquipmentRequestsForm()
        {
            maintenanceRepository = new MaintenanceRepository();
            InitializeComponent();
            LoadRequests();
        }

        private void InitializeComponent()
        {
            headerPanel = new Panel();
            titleLabel = new Label();
            buttonPanel = new Panel();
            refreshButton = new Button();
            approveButton = new Button();
            rejectButton = new Button();
            requestsDataGridView = new DataGridView();
            headerPanel.SuspendLayout();
            buttonPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)requestsDataGridView).BeginInit();
            SuspendLayout();
            // 
            // headerPanel
            // 
            headerPanel.BackColor = Color.FromArgb(41, 128, 185);
            headerPanel.Controls.Add(titleLabel);
            headerPanel.Dock = DockStyle.Top;
            headerPanel.Location = new Point(0, 44);
            headerPanel.Name = "headerPanel";
            headerPanel.Size = new Size(1184, 45);
            headerPanel.TabIndex = 0;
            // 
            // titleLabel
            // 
            titleLabel.Font = new Font("Segoe UI", 16F, FontStyle.Bold);
            titleLabel.ForeColor = Color.White;
            titleLabel.Location = new Point(20, 3);
            titleLabel.Name = "titleLabel";
            titleLabel.Size = new Size(250, 30);
            titleLabel.TabIndex = 0;
            titleLabel.Text = "Equipment Requests";
            // 
            // buttonPanel
            // 
            buttonPanel.BackColor = Color.FromArgb(236, 240, 241);
            buttonPanel.Controls.Add(refreshButton);
            buttonPanel.Controls.Add(approveButton);
            buttonPanel.Controls.Add(rejectButton);
            buttonPanel.Dock = DockStyle.Top;
            buttonPanel.Location = new Point(0, 0);
            buttonPanel.Name = "buttonPanel";
            buttonPanel.Size = new Size(1184, 44);
            buttonPanel.TabIndex = 1;
            // 
            // refreshButton
            // 
            refreshButton.BackColor = Color.FromArgb(52, 152, 219);
            refreshButton.FlatStyle = FlatStyle.Flat;
            refreshButton.Font = new Font("Segoe UI", 10F);
            refreshButton.ForeColor = Color.White;
            refreshButton.Location = new Point(20, 10);
            refreshButton.Name = "refreshButton";
            refreshButton.Size = new Size(80, 30);
            refreshButton.TabIndex = 0;
            refreshButton.Text = "Refresh";
            refreshButton.UseVisualStyleBackColor = false;
            refreshButton.Click += RefreshButton_Click;
            // 
            // approveButton
            // 
            approveButton.BackColor = Color.FromArgb(46, 204, 113);
            approveButton.FlatStyle = FlatStyle.Flat;
            approveButton.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            approveButton.ForeColor = Color.White;
            approveButton.Location = new Point(110, 10);
            approveButton.Name = "approveButton";
            approveButton.Size = new Size(80, 30);
            approveButton.TabIndex = 1;
            approveButton.Text = "Approve";
            approveButton.UseVisualStyleBackColor = false;
            approveButton.Click += ApproveButton_Click;
            // 
            // rejectButton
            // 
            rejectButton.BackColor = Color.FromArgb(231, 76, 60);
            rejectButton.FlatStyle = FlatStyle.Flat;
            rejectButton.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            rejectButton.ForeColor = Color.White;
            rejectButton.Location = new Point(200, 10);
            rejectButton.Name = "rejectButton";
            rejectButton.Size = new Size(80, 30);
            rejectButton.TabIndex = 2;
            rejectButton.Text = "Reject";
            rejectButton.UseVisualStyleBackColor = false;
            rejectButton.Click += RejectButton_Click;
            // 
            // requestsDataGridView
            // 
            requestsDataGridView.AllowUserToAddRows = false;
            requestsDataGridView.AllowUserToDeleteRows = false;
            requestsDataGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            requestsDataGridView.BackgroundColor = Color.White;
            requestsDataGridView.BorderStyle = BorderStyle.None;
            requestsDataGridView.Dock = DockStyle.Fill;
            requestsDataGridView.Location = new Point(0, 0);
            requestsDataGridView.MultiSelect = false;
            requestsDataGridView.Name = "requestsDataGridView";
            requestsDataGridView.ReadOnly = true;
            requestsDataGridView.RowHeadersVisible = false;
            requestsDataGridView.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            requestsDataGridView.Size = new Size(1184, 561);
            requestsDataGridView.TabIndex = 2;
            // 
            // EquipmentRequestsForm
            // 
            BackColor = Color.White;
            ClientSize = new Size(1184, 561);
            //Controls.Add(headerPanel);
            //Controls.Add(buttonPanel);
            //Controls.Add(requestsDataGridView);

            TableLayoutPanel tlp = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,   // TLP fills the form
                ColumnCount = 1,
                RowCount = 3,
                Padding = new Padding(0),  // optional – keeps things flush
                Margin = new Padding(0)
            };

            // Row 0 – Header panel – absolute height
            tlp.RowStyles.Add(new RowStyle(SizeType.Absolute, headerPanel.Height));
            // Row 1 – Button panel – absolute height
            tlp.RowStyles.Add(new RowStyle(SizeType.Absolute, buttonPanel.Height));
            // Row 2 – DataGridView – takes the rest
            tlp.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));

            // Place the three controls in the TLP
            tlp.Controls.Add(headerPanel, 0, 0);  // (column, row)
            tlp.Controls.Add(buttonPanel, 0, 1);
            tlp.Controls.Add(requestsDataGridView, 0, 2);

            // Finally, add the TLP to the form
            this.Controls.Add(tlp);
            Name = "EquipmentRequestsForm";
            StartPosition = FormStartPosition.CenterParent;
            Text = "Equipment Requests";
            headerPanel.ResumeLayout(false);
            buttonPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)requestsDataGridView).EndInit();
            ResumeLayout(false);
        }

        private void LoadRequests()
        {
            try
            {
                List<EquipmentRequest> requests = maintenanceRepository.GetAllEquipmentRequests();

                var displayData = requests.Select(r => new
                {
                    RequestID = r.RequestID,
                    Facility = r.Facility?.FacilityName ?? "Unknown",
                    RequestedBy = r.RequestedByUser?.FullName ?? "Unknown",
                    RequestType = r.RequestType.ToString(),
                    ItemName = r.ItemName,
                    Description = r.Description,
                    Quantity = r.Quantity,
                    EstimatedCost = r.EstimatedCost?.ToString("C") ?? "N/A",
                    Priority = r.Priority.ToString(),
                    Status = r.Status.ToString(),
                    RequestDate = r.RequestDate.ToString("yyyy-MM-dd"),
                    ApprovedBy = r.ApprovedByUser?.FullName ?? "N/A",
                    ApprovalNotes = r.ApprovalNotes ?? ""
                }).ToList();

                requestsDataGridView.DataSource = displayData;

                // Configure columns
                if (requestsDataGridView.Columns.Count > 0)
                {
                    requestsDataGridView.Columns["RequestID"].Visible = false;
                    requestsDataGridView.Columns["Facility"].HeaderText = "Facility";
                    requestsDataGridView.Columns["RequestedBy"].HeaderText = "Requested By";
                    requestsDataGridView.Columns["RequestType"].HeaderText = "Type";
                    requestsDataGridView.Columns["ItemName"].HeaderText = "Item";
                    requestsDataGridView.Columns["Description"].HeaderText = "Description";
                    requestsDataGridView.Columns["Quantity"].HeaderText = "Qty";
                    requestsDataGridView.Columns["EstimatedCost"].HeaderText = "Cost";
                    requestsDataGridView.Columns["Priority"].HeaderText = "Priority";
                    requestsDataGridView.Columns["Status"].HeaderText = "Status";
                    requestsDataGridView.Columns["RequestDate"].HeaderText = "Date";
                    requestsDataGridView.Columns["ApprovedBy"].HeaderText = "Approved By";
                    requestsDataGridView.Columns["ApprovalNotes"].HeaderText = "Notes";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading requests: {ex.Message}", "Error",
                              MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void RefreshButton_Click(object sender, EventArgs e)
        {
            LoadRequests();
        }

        private void ApproveButton_Click(object sender, EventArgs e)
        {
            if (requestsDataGridView.SelectedRows.Count > 0)
            {
                int requestId = (int)requestsDataGridView.SelectedRows[0].Cells["RequestID"].Value;
                string status = requestsDataGridView.SelectedRows[0].Cells["Status"].Value.ToString();

                if (status != "Pending")
                {
                    MessageBox.Show("Only pending requests can be approved.", "Invalid Action",
                                  MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                string notes = Microsoft.VisualBasic.Interaction.InputBox(
                    "Enter approval notes (optional):", "Approve Request", "");

                try
                {
                    maintenanceRepository.ApproveEquipmentRequest(requestId, AuthenticationService.CurrentUser.UserID, notes);
                    MessageBox.Show("Request approved successfully.", "Success",
                                  MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadRequests();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error approving request: {ex.Message}", "Error",
                                  MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Please select a request to approve.", "No Selection",
                              MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void RejectButton_Click(object sender, EventArgs e)
        {
            if (requestsDataGridView.SelectedRows.Count > 0)
            {
                int requestId = (int)requestsDataGridView.SelectedRows[0].Cells["RequestID"].Value;
                string status = requestsDataGridView.SelectedRows[0].Cells["Status"].Value.ToString();

                if (status != "Pending")
                {
                    MessageBox.Show("Only pending requests can be rejected.", "Invalid Action",
                                  MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                string notes = Microsoft.VisualBasic.Interaction.InputBox(
                    "Enter rejection reason:", "Reject Request", "");

                if (string.IsNullOrWhiteSpace(notes))
                {
                    MessageBox.Show("Rejection reason is required.", "Validation Error",
                                  MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                try
                {
                    maintenanceRepository.RejectEquipmentRequest(requestId, AuthenticationService.CurrentUser.UserID, notes);
                    MessageBox.Show("Request rejected successfully.", "Success",
                                  MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadRequests();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error rejecting request: {ex.Message}", "Error",
                                  MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Please select a request to reject.", "No Selection",
                              MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
    }
}
