﻿using System;
using System.Linq;
using System.Windows.Forms;
using ARFMS_System.Data;
using ARFMS_System.Models;

namespace ARFMS_System.Forms
{
    public partial class SupplyRequestsForm : Form
    {
        private CleaningSupplyRepository cleaningSupplyRepository;
        private DataGridView dataGridViewRequests;
        private Button btnApprove;
        private Button btnReject;
        private Button btnRefresh;

        public SupplyRequestsForm()
        {
            InitializeComponent();
            cleaningSupplyRepository = new CleaningSupplyRepository();
            LoadSupplyRequests();
        }

        private void InitializeComponent()
        {
            this.dataGridViewRequests = new DataGridView();
            this.btnApprove = new Button();
            this.btnReject = new Button();
            this.btnRefresh = new Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewRequests)).BeginInit();
            this.SuspendLayout();

            // dataGridViewRequests
            this.dataGridViewRequests.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewRequests.Location = new System.Drawing.Point(12, 12);
            this.dataGridViewRequests.Name = "dataGridViewRequests";
            this.dataGridViewRequests.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewRequests.Size = new System.Drawing.Size(760, 350);
            this.dataGridViewRequests.TabIndex = 0;

            // btnApprove
            this.btnApprove.BackColor = System.Drawing.Color.Green;
            this.btnApprove.ForeColor = System.Drawing.Color.White;
            this.btnApprove.Location = new System.Drawing.Point(12, 380);
            this.btnApprove.Name = "btnApprove";
            this.btnApprove.Size = new System.Drawing.Size(100, 30);
            this.btnApprove.TabIndex = 1;
            this.btnApprove.Text = "Approve";
            this.btnApprove.UseVisualStyleBackColor = false;
            this.btnApprove.Click += new System.EventHandler(this.btnApprove_Click);

            // btnReject
            this.btnReject.BackColor = System.Drawing.Color.Red;
            this.btnReject.ForeColor = System.Drawing.Color.White;
            this.btnReject.Location = new System.Drawing.Point(130, 380);
            this.btnReject.Name = "btnReject";
            this.btnReject.Size = new System.Drawing.Size(100, 30);
            this.btnReject.TabIndex = 2;
            this.btnReject.Text = "Reject";
            this.btnReject.UseVisualStyleBackColor = false;
            this.btnReject.Click += new System.EventHandler(this.btnReject_Click);

            // btnRefresh
            this.btnRefresh.Location = new System.Drawing.Point(250, 380);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(100, 30);
            this.btnRefresh.TabIndex = 3;
            this.btnRefresh.Text = "Refresh";
            this.btnRefresh.UseVisualStyleBackColor = true;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);

            // SupplyRequestsForm
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 431);
            this.Controls.Add(this.btnRefresh);
            this.Controls.Add(this.btnReject);
            this.Controls.Add(this.btnApprove);
            this.Controls.Add(this.dataGridViewRequests);
            this.Name = "SupplyRequestsForm";
            this.Text = "Supply Requests Management";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewRequests)).EndInit();
            this.ResumeLayout(false);
        }

        private void LoadSupplyRequests()
        {
            try
            {
                var requests = cleaningSupplyRepository.GetAllSupplyRequests();
                dataGridViewRequests.DataSource = requests.Select(r => new
                {
                    r.SupplyRequestID,
                    r.Supply.SupplyName,
                    r.QuantityRequested,
                    r.Supply.Unit,
                    RequestedBy = r.RequestedByUser?.FullName ?? "Unknown",
                    r.RequestDate,
                    r.Status,
                    r.Notes
                }).ToList();

                dataGridViewRequests.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading supply requests: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnApprove_Click(object sender, EventArgs e)
        {
            if (dataGridViewRequests.SelectedRows.Count > 0)
            {
                try
                {
                    int requestId = Convert.ToInt32(dataGridViewRequests.SelectedRows[0].Cells["SupplyRequestID"].Value);
                    cleaningSupplyRepository.UpdateSupplyRequestStatus(requestId, RequestStatus.Approved);
                    MessageBox.Show("Supply request approved successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadSupplyRequests();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error approving request: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Please select a supply request to approve.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnReject_Click(object sender, EventArgs e)
        {
            if (dataGridViewRequests.SelectedRows.Count > 0)
            {
                try
                {
                    int requestId = Convert.ToInt32(dataGridViewRequests.SelectedRows[0].Cells["SupplyRequestID"].Value);
                    cleaningSupplyRepository.UpdateSupplyRequestStatus(requestId, RequestStatus.Rejected);
                    MessageBox.Show("Supply request rejected successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadSupplyRequests();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error rejecting request: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Please select a supply request to reject.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            LoadSupplyRequests();
        }
    }
}
