﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using ARFMS_System;
using ARFMS_System.Models;

namespace ARFMS.Forms
{
    public partial class SearchFacilitiesForm : Form
    {
        private FacilityRepository facilityRepository;
        private BookingRepository bookingRepository;
        private DataGridView facilitiesDataGridView;
        private TextBox searchTextBox;
        private ComboBox facilityTypeComboBox;
        private ComboBox universityComboBox;

        private bool _isInitializing = true;

        public SearchFacilitiesForm()
        {
            facilityRepository = new FacilityRepository();
            bookingRepository = new BookingRepository();
            InitializeComponent();

            _isInitializing = true;
            LoadComboBoxData();
            _isInitializing = false;

            LoadFacilities();
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();

            // Form properties
            this.Text = "Search Facilities";
            this.Size = new Size(1100, 700);
            this.StartPosition = FormStartPosition.CenterParent;
            this.BackColor = Color.White;

            // Header Panel
            Panel headerPanel = new Panel();
            headerPanel.BackColor = Color.FromArgb(155, 89, 182);
            headerPanel.Dock = DockStyle.Top;
            headerPanel.Height = 60;

            // Title Label
            Label titleLabel = new Label();
            titleLabel.Text = "Search Facilities";
            titleLabel.Font = new Font("Segoe UI", 16, FontStyle.Bold);
            titleLabel.ForeColor = Color.White;
            titleLabel.Location = new Point(20, 15);
            titleLabel.Size = new Size(300, 30);
            headerPanel.Controls.Add(titleLabel);

            this.Controls.Add(headerPanel);

            // Search Panel (container)
            Panel searchPanel = new Panel();
            searchPanel.Dock = DockStyle.Top;
            searchPanel.Padding = new Padding(0, 10, 0, 10);   // Added bottom padding for spacing
            searchPanel.BackColor = Color.FromArgb(236, 240, 241);

            // Make the search panel auto-size to its content (responsive height)
            searchPanel.AutoSize = true;
            searchPanel.AutoSizeMode = AutoSizeMode.GrowAndShrink;

            // Inner FlowLayoutPanel for responsive layout
            FlowLayoutPanel flow = new FlowLayoutPanel();
            flow.Dock = DockStyle.Top;              // sits inside searchPanel
            flow.WrapContents = true;               // wrap on small widths
            flow.AutoSize = true;                   // grow height as needed
            flow.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            flow.Padding = new Padding(16, 12, 16, 12);
            flow.Margin = new Padding(0);
            flow.FlowDirection = FlowDirection.LeftToRight;
            searchPanel.Controls.Add(flow);

            // Helper to create labeled blocks
            static Panel Labeled(string labelText, Control input, int inputWidth)
            {
                var container = new Panel { Width = inputWidth + 70, Height = 54, Margin = new Padding(8, 4, 8, 4) };
                var lbl = new Label
                {
                    Text = labelText,
                    Font = new Font("Segoe UI", 10),
                    Location = new Point(0, 2),
                    Size = new Size(70, 20)
                };
                input.Location = new Point(0, 24);
                input.Width = inputWidth;
                container.Controls.Add(lbl);
                container.Controls.Add(input);
                return container;
            }

            // Search TextBox
            searchTextBox = new TextBox();
            searchTextBox.Font = new Font("Segoe UI", 10);
            searchTextBox.TextChanged += SearchTextBox_TextChanged;
            flow.Controls.Add(Labeled("Search:", searchTextBox, 220));

            // Facility Type ComboBox
            facilityTypeComboBox = new ComboBox();
            facilityTypeComboBox.Font = new Font("Segoe UI", 10);
            facilityTypeComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
            facilityTypeComboBox.SelectedIndexChanged += FilterComboBox_SelectedIndexChanged;
            flow.Controls.Add(Labeled("Type:", facilityTypeComboBox, 170));

            // University ComboBox
            universityComboBox = new ComboBox();
            universityComboBox.Font = new Font("Segoe UI", 10);
            universityComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
            universityComboBox.SelectedIndexChanged += FilterComboBox_SelectedIndexChanged;
            flow.Controls.Add(Labeled("University:", universityComboBox, 220));

            // Clear Filters Button
            Button clearButton = new Button();
            clearButton.Text = "Clear";
            clearButton.Font = new Font("Segoe UI", 10);
            clearButton.BackColor = Color.FromArgb(149, 165, 166);
            clearButton.ForeColor = Color.White;
            clearButton.FlatStyle = FlatStyle.Flat;
            clearButton.Size = new Size(90, 34);
            clearButton.Margin = new Padding(8, 24, 8, 4);
            clearButton.Click += ClearButton_Click;
            flow.Controls.Add(clearButton);

            // Book Facility Button
            Button bookButton = new Button();
            bookButton.Text = "Book Facility";
            bookButton.Font = new Font("Segoe UI", 10, FontStyle.Bold);
            bookButton.BackColor = Color.FromArgb(46, 204, 113);
            bookButton.ForeColor = Color.White;
            bookButton.FlatStyle = FlatStyle.Flat;
            bookButton.Size = new Size(130, 34);
            bookButton.Margin = new Padding(8, 24, 8, 4);
            bookButton.Click += BookButton_Click;
            flow.Controls.Add(bookButton);

            this.Controls.Add(searchPanel);

            Panel dataGridContainer = new Panel();
            dataGridContainer.Dock = DockStyle.Fill;
            dataGridContainer.Padding = new Padding(10, 180, 10, 10); // Add padding around the grid
            dataGridContainer.BackColor = Color.White;

            // --- DataGridView (now inside container with padding) ---
            facilitiesDataGridView = new DataGridView();
            facilitiesDataGridView.Dock = DockStyle.Fill; // Fill the container, not the form
            facilitiesDataGridView.BackgroundColor = Color.White;
            facilitiesDataGridView.BorderStyle = BorderStyle.None;
            facilitiesDataGridView.AllowUserToAddRows = false;
            facilitiesDataGridView.AllowUserToDeleteRows = false;
            facilitiesDataGridView.ReadOnly = true;
            facilitiesDataGridView.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            facilitiesDataGridView.MultiSelect = false;
            facilitiesDataGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            facilitiesDataGridView.RowHeadersVisible = false;
            facilitiesDataGridView.CellDoubleClick += FacilitiesDataGridView_CellDoubleClick;
            facilitiesDataGridView.EnableHeadersVisualStyles = false;
            facilitiesDataGridView.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(236, 240, 241);
            facilitiesDataGridView.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 10, FontStyle.Bold);
            facilitiesDataGridView.DefaultCellStyle.Font = new Font("Segoe UI", 10);

            dataGridContainer.Controls.Add(facilitiesDataGridView);
            this.Controls.Add(dataGridContainer);

            this.ResumeLayout(true);
            this.PerformLayout();
        }

        private void LoadComboBoxData()
        {
            try
            {
                // Load facility types
                List<FacilityType> facilityTypes = facilityRepository.GetAllFacilityTypes();
                facilityTypes.Insert(0, new FacilityType { FacilityTypeID = 0, TypeName = "All Types" });

                facilityTypeComboBox.DisplayMember = "TypeName";
                facilityTypeComboBox.ValueMember = "FacilityTypeID";
                facilityTypeComboBox.DataSource = facilityTypes;

                // Load universities
                List<University> universities = facilityRepository.GetAllUniversities();
                universities.Insert(0, new University { UniversityID = 0, UniversityName = "All Universities" });

                universityComboBox.DisplayMember = "UniversityName";
                universityComboBox.ValueMember = "UniversityID";
                universityComboBox.DataSource = universities;

                facilityTypeComboBox.SelectedIndex = 0;
                universityComboBox.SelectedIndex = 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading filter data: {ex.Message}", "Error",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadFacilities()
        {
            try
            {
                List<Facility> facilities = facilityRepository.GetAllFacilities();

                // Apply filters
                string searchTerm = searchTextBox?.Text?.Trim().ToLower() ?? "";

                int selectedTypeId = GetSelectedIdSafe(facilityTypeComboBox,
                    getFromItem: (obj) => (obj as FacilityType)?.FacilityTypeID ?? 0);

                int selectedUniversityId = GetSelectedIdSafe(universityComboBox,
                    getFromItem: (obj) => (obj as University)?.UniversityID ?? 0);

                if (!string.IsNullOrEmpty(searchTerm))
                {
                    facilities = facilities.Where(f =>
                        (f.FacilityName ?? "").ToLower().Contains(searchTerm) ||
                        (f.FacilityCode ?? "").ToLower().Contains(searchTerm) ||
                        ((f.Location ?? "").ToLower().Contains(searchTerm))
                    ).ToList();
                }

                if (selectedTypeId > 0)
                    facilities = facilities.Where(f => f.FacilityTypeID == selectedTypeId).ToList();

                if (selectedUniversityId > 0)
                    facilities = facilities.Where(f => f.UniversityID == selectedUniversityId).ToList();

                // Only show available facilities
                facilities = facilities.Where(f => f.IsAvailable).ToList();

                var displayData = facilities.Select(f => new
                {
                    FacilityID = f.FacilityID,
                    FacilityCode = f.FacilityCode,
                    FacilityName = f.FacilityName,
                    Type = f.FacilityType?.TypeName ?? "Unknown",
                    University = f.University?.UniversityName ?? "Unknown",
                    Location = f.Location,
                    Capacity = f.Capacity,
                    HourlyRate = f.HourlyRate.ToString("C"),
                    Description = f.Description
                }).ToList();

                facilitiesDataGridView.DataSource = displayData;

                if (facilitiesDataGridView.Columns.Count > 0)
                {
                    facilitiesDataGridView.Columns["FacilityID"].Visible = false;
                    facilitiesDataGridView.Columns["FacilityCode"].HeaderText = "Code";
                    facilitiesDataGridView.Columns["FacilityName"].HeaderText = "Name";
                    facilitiesDataGridView.Columns["Type"].HeaderText = "Type";
                    facilitiesDataGridView.Columns["University"].HeaderText = "University";
                    facilitiesDataGridView.Columns["Location"].HeaderText = "Location";
                    facilitiesDataGridView.Columns["Capacity"].HeaderText = "Capacity";
                    facilitiesDataGridView.Columns["HourlyRate"].HeaderText = "Rate/Hour";
                    facilitiesDataGridView.Columns["Description"].HeaderText = "Description";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading facilities: {ex.Message}", "Error",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private static int GetSelectedIdSafe(ComboBox combo, Func<object, int> getFromItem)
        {
            if (combo == null) return 0;

            try
            {
                if (combo.SelectedValue is int idFromValue)
                    return idFromValue;

                if (combo.SelectedItem != null)
                    return getFromItem(combo.SelectedItem);
            }
            catch { }

            return 0;
        }

        private void SearchTextBox_TextChanged(object sender, EventArgs e)
        {
            if (_isInitializing) return;
            LoadFacilities();
        }

        private void FilterComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (_isInitializing) return;
            LoadFacilities();
        }

        private void ClearButton_Click(object sender, EventArgs e)
        {
            _isInitializing = true;
            searchTextBox.Clear();
            facilityTypeComboBox.SelectedIndex = 0;
            universityComboBox.SelectedIndex = 0;
            _isInitializing = false;
            LoadFacilities();
        }

        private void BookButton_Click(object sender, EventArgs e)
        {
            BookSelectedFacility();
        }

        private void FacilitiesDataGridView_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0) BookSelectedFacility();
        }

        private void BookSelectedFacility()
        {
            if (facilitiesDataGridView.SelectedRows.Count > 0)
            {
                int facilityId = Convert.ToInt32(facilitiesDataGridView.SelectedRows[0].Cells["FacilityID"].Value);
                string facilityName = facilitiesDataGridView.SelectedRows[0].Cells["FacilityName"].Value?.ToString() ?? "Facility";

                BookFacilityForm bookForm = new BookFacilityForm(facilityId, facilityName);
                if (bookForm.ShowDialog() == DialogResult.OK)
                {
                    MessageBox.Show("Booking request submitted successfully! Please visit reception to complete payment.",
                                    "Booking Submitted", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadFacilities();
                }
            }
            else
            {
                MessageBox.Show("Please select a facility to book.", "No Selection",
                                MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
    }
}
