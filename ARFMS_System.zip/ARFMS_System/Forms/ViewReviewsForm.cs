using ARFMS_System;

namespace ARFMS.Forms
{
    public partial class ViewReviewsForm : Form
    {
        private ReviewRepository reviewRepository;
        private DataGridView reviewsGrid;
        private ComboBox facilityFilterComboBox;
        private Button filterButton;

        public ViewReviewsForm()
        {
            reviewRepository = new ReviewRepository();
            InitializeComponent();
            LoadReviews();
        }

        private void InitializeComponent()
        {
            this.Text = "View Reviews & Ratings";
            this.Size = new Size(900, 600);
            this.StartPosition = FormStartPosition.CenterScreen;

            // Filter controls
            Label filterLabel = new Label();
            filterLabel.Text = "Filter by Facility:";
            filterLabel.Location = new Point(20, 20);
            filterLabel.Size = new Size(100, 20);
            this.Controls.Add(filterLabel);

            facilityFilterComboBox = new ComboBox();
            facilityFilterComboBox.Location = new Point(130, 20);
            facilityFilterComboBox.Size = new Size(200, 25);
            facilityFilterComboBox.Items.Add("All Facilities");
            facilityFilterComboBox.SelectedIndex = 0;
            this.Controls.Add(facilityFilterComboBox);

            filterButton = new Button();
            filterButton.Text = "Filter";
            filterButton.Location = new Point(350, 20);
            filterButton.Size = new Size(80, 25);
            filterButton.Click += FilterButton_Click;
            this.Controls.Add(filterButton);

            // Reviews grid
            reviewsGrid = new DataGridView();
            reviewsGrid.Location = new Point(20, 60);
            reviewsGrid.Size = new Size(840, 480);
            reviewsGrid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            this.Controls.Add(reviewsGrid);
        }

        private void LoadReviews()
        {
            var reviews = reviewRepository.GetAllReviews();
            reviewsGrid.DataSource = reviews;
        }

        private void FilterButton_Click(object sender, EventArgs e)
        {
            LoadReviews(); // For now, just reload all reviews
        }
    }
}
