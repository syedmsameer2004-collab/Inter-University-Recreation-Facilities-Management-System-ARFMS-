﻿using ARFMS.Services;
using System.Drawing;
using System.Windows.Forms;

namespace ARFMS.Forms
{
    public partial class ManagerHomeForm : Form
    {
        public ManagerHomeForm()
        {
            InitializeComponent();
            SetupCustomUI();
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // ManagerHomeForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1000, 700);
            this.Name = "ManagerHomeForm";
            this.Text = "ARFMS - Manager Dashboard";
            this.ResumeLayout(false);
        }


        private void SetupCustomUI()
        {
            // Form properties
            this.Text = "ARFMS - Manager Dashboard";
            this.Size = new Size(1000, 700);
            this.FormBorderStyle = FormBorderStyle.Sizable;
            this.BackColor = Color.White;

            // MAIN PANEL (add first so it goes behind)
            Panel mainPanel = new Panel
            {
                Dock = DockStyle.Fill,
                Padding = new Padding(20, 100, 0, 0),
                AutoScroll = true
            };
            this.Controls.Add(mainPanel);

            // HEADER (add after; bring to front to avoid overlap)
            Panel headerPanel = new Panel
            {
                BackColor = Color.FromArgb(41, 128, 185),
                Dock = DockStyle.Top,
                Height = 80
            };
            this.Controls.Add(headerPanel);
            headerPanel.BringToFront(); // <- ensures header is on top


            // Title
            Label titleLabel = new Label
            {
                Text = "Manager Dashboard",
                Font = new Font("Segoe UI", 18, FontStyle.Bold),
                ForeColor = Color.White,
                Location = new Point(20, 10),
                AutoSize = true
            };
            headerPanel.Controls.Add(titleLabel);

            // Welcome
            Label welcomeLabel = new Label
            {
                Text = $"Welcome, {AuthenticationService.GetCurrentUserFullName()}",
                Font = new Font("Segoe UI", 12),
                ForeColor = Color.White,
                Location = new Point(20, 45),
                AutoSize = true
            };
            headerPanel.Controls.Add(welcomeLabel);

            // Logout
            Button logoutButton = new Button
            {
                Text = "Logout",
                Font = new Font("Segoe UI", 10),
                BackColor = Color.FromArgb(231, 76, 60),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Size = new Size(100, 30),
                Anchor = AnchorStyles.Top | AnchorStyles.Right
            };
            logoutButton.Location = new Point(headerPanel.Width - logoutButton.Width - 20, 25);
            logoutButton.Click += LogoutButton_Click;
            headerPanel.Controls.Add(logoutButton);
            headerPanel.Resize += (s, e) =>
            {
                logoutButton.Left = headerPanel.Width - logoutButton.Width - 20;
            };

            // Menu grid (prevents overlaps on resize/DPI)
            var grid = new TableLayoutPanel
            {
                Dock = DockStyle.Top,
                ColumnCount = 3,
                RowCount = 3,
                AutoSize = true,
                AutoSizeMode = AutoSizeMode.GrowAndShrink,
                Padding = new Padding(0),
                Margin = new Padding(0)
            };
            // 3 equal columns
            grid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.33f));
            grid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.33f));
            grid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.33f));
            grid.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            grid.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            grid.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            mainPanel.Controls.Add(grid);

            // Add buttons (no absolute coords)
            AddMenuButton(grid, 0, 0, "User Management", "Manage Reception & Maintenance Staff", UserMgmtButton_Click);
            AddMenuButton(grid, 1, 0, "Facility Management", "Manage Sports & Recreation Facilities", FacilityMgmtButton_Click);
            AddMenuButton(grid, 2, 0, "Maintenance Scheduling", "Assign Maintenance Tasks", MaintenanceButton_Click);
            AddMenuButton(grid, 0, 1, "Equipment Requests", "View & Approve Equipment Requests", EquipmentButton_Click);
            AddMenuButton(grid, 1, 1, "Reviews & Ratings", "View Facility Reviews & Ratings", ReviewsButton_Click);
            AddMenuButton(grid, 2, 1, "Reports", "View System Reports", ReportsButton_Click);
            AddMenuButton(grid, 0, 2, "Supply Requests", "View & Approve Cleaning Supply Requests", SupplyRequestsButton_Click);
        }

        private void AddMenuButton(TableLayoutPanel grid, int col, int row, string title, string desc, EventHandler onClick)
        {
            var btn = new Button
            {
                Text = $"{title}\n{desc}",
                Font = new Font("Segoe UI", 11, FontStyle.Bold),
                BackColor = Color.FromArgb(52, 152, 219),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                FlatAppearance = { BorderSize = 0 },
                Margin = new Padding(10),
                Padding = new Padding(10),
                Size = new Size(0, 120),        // height fixed, width grows with cell
                Dock = DockStyle.Fill,          // fill the table cell
                TextAlign = ContentAlignment.MiddleCenter,
                Cursor = Cursors.Hand
            };
            btn.MouseEnter += (s, e) => btn.BackColor = Color.FromArgb(41, 128, 185);
            btn.MouseLeave += (s, e) => btn.BackColor = Color.FromArgb(52, 152, 219);
            btn.Click += onClick;

            // ensure grid has enough rows/cols
            while (grid.RowCount <= row) grid.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            grid.Controls.Add(btn, col, row);
        }

        private void UserMgmtButton_Click(object sender, EventArgs e)
        {
            UserManagementForm userForm = new UserManagementForm();
            userForm.ShowDialog();
        }

        private void FacilityMgmtButton_Click(object sender, EventArgs e)
        {
            FacilityManagementForm facilityForm = new FacilityManagementForm();
            facilityForm.ShowDialog();
        }

        private void MaintenanceButton_Click(object sender, EventArgs e)
        {
            MaintenanceSchedulingForm maintenanceForm = new MaintenanceSchedulingForm();
            maintenanceForm.ShowDialog();
        }

        private void EquipmentButton_Click(object sender, EventArgs e)
        {
            EquipmentRequestsForm equipmentForm = new EquipmentRequestsForm();
            equipmentForm.ShowDialog();
        }

        private void ReviewsButton_Click(object sender, EventArgs e)
        {
            ViewReviewsForm reviewsForm = new ViewReviewsForm();
            reviewsForm.ShowDialog();
        }

        private void ReportsButton_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Reports functionality will be implemented in future versions.",
                          "Coming Soon", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void SupplyRequestsButton_Click(object sender, EventArgs e)
        {
            ARFMS_System.Forms.SupplyRequestsForm supplyForm = new ARFMS_System.Forms.SupplyRequestsForm();
            supplyForm.ShowDialog();
        }

        private void LogoutButton_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you sure you want to logout?",
                                                "Confirm Logout", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                AuthenticationService authService = new AuthenticationService();
                authService.Logout();

                LoginForm loginForm = new LoginForm();
                loginForm.Show();
                this.Close();
            }
        }
    }
}
