﻿using ARFMS_System;
using ARFMS_System.Models;
using ARFMS_System.Data;

namespace ARFMS.Forms
{
    public partial class ManageSuppliesForm : Form
    {
        private User _currentUser;
        private CleaningSupplyRepository _supplyRepository;
        private DataGridView _requestsGrid;

        public ManageSuppliesForm(User user)
        {
            _currentUser = user;
            _supplyRepository = new CleaningSupplyRepository();
            InitializeComponent();
            LoadSupplyRequests();
        }

        private void InitializeComponent()
        {
            // ---------- Form base ----------
            this.Size = new Size(1000, 600);
            this.Text = "Manage Cleaning Supplies";
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.FromArgb(240, 248, 255);

            // ---------- TLPanel (fills the form) ----------
            var tlpMain = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                RowCount = 2,
                ColumnCount = 1,
                RowStyles =
        {
            // Header – fixed 60 px
            new RowStyle(SizeType.Absolute, 60f),
            // Main – takes the rest
            new RowStyle(SizeType.Percent, 100f)
        }
            };

            // ---------- Header ----------
            var headerLabel = new Label
            {
                Text = "My Supply Requests",
                Font = new Font("Segoe UI", 16, FontStyle.Bold),
                ForeColor = Color.FromArgb(70, 130, 180),
                Dock = DockStyle.Fill,
                TextAlign = ContentAlignment.MiddleLeft,
                Padding = new Padding(20, 0, 0, 0)
            };
            tlpMain.Controls.Add(headerLabel, 0, 0);   // Row 0

            // ---------- Main content area ----------
            var tlpContent = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 2,
                RowCount = 1,
                ColumnStyles =
        {
            // DataGridView – fills
            new ColumnStyle(SizeType.Percent, 100f),
            // Buttons – fixed 400 px
            new ColumnStyle(SizeType.Absolute, 400f)
        },
                RowStyles =
        {
            new RowStyle(SizeType.Percent, 100f)
        }
            };
            tlpMain.Controls.Add(tlpContent, 0, 1);    // Row 1

            // ---------- DataGridView ----------
            _requestsGrid = new DataGridView
            {
                Dock = DockStyle.Fill,
                BackgroundColor = Color.White,
                BorderStyle = BorderStyle.Fixed3D,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
            };
            tlpContent.Controls.Add(_requestsGrid, 0, 0);   // Column 0

            // ---------- Button panel ----------
            var pnlButtons = new Panel { Dock = DockStyle.Fill, Padding = new Padding(10) };

            // Create buttons once, keep the same appearance as before
            var addButton = new Button
            {
                Text = "Add Request",
                Size = new Size(120, 35),
                BackColor = Color.FromArgb(40, 167, 69),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Anchor = AnchorStyles.Bottom
            };
            addButton.Click += AddButton_Click;

            var editButton = new Button
            {
                Text = "Edit Request",
                Size = new Size(120, 35),
                BackColor = Color.FromArgb(255, 193, 7),
                ForeColor = Color.Black,
                FlatStyle = FlatStyle.Flat,
                Anchor = AnchorStyles.Bottom
            };
            editButton.Click += EditButton_Click;

            var deleteButton = new Button
            {
                Text = "Delete Request",
                Size = new Size(120, 35),
                BackColor = Color.FromArgb(220, 53, 69),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Anchor = AnchorStyles.Bottom
            };
            deleteButton.Click += DeleteButton_Click;

            var refreshButton = new Button
            {
                Text = "Refresh",
                Size = new Size(100, 35),
                BackColor = Color.FromArgb(70, 130, 180),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Anchor = AnchorStyles.Bottom
            };
            refreshButton.Click += RefreshButton_Click;

            var closeButton = new Button
            {
                Text = "Close",
                Size = new Size(100, 35),
                BackColor = Color.FromArgb(108, 117, 125),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Anchor = AnchorStyles.Bottom
            };
            closeButton.Click += (s, e) => this.Close();

            // ----- Arrange buttons inside a TLPanel for neat vertical spacing ----------
            var tlpButtons = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                RowCount = 5,
                ColumnCount = 1,
                Padding = new Padding(10, 5, 10, 5),
                RowStyles =
        {
            new RowStyle(SizeType.Percent, 20f),
            new RowStyle(SizeType.Percent, 20f),
            new RowStyle(SizeType.Percent, 20f),
            new RowStyle(SizeType.Percent, 20f),
            new RowStyle(SizeType.Percent, 20f)
        }
            };

            // Put the button collection into tlpButtons (you could also put them in a single column with spacing)
            tlpButtons.Controls.Add(addButton, 0, 0);
            tlpButtons.Controls.Add(editButton, 0, 1);
            tlpButtons.Controls.Add(deleteButton, 0, 2);
            tlpButtons.Controls.Add(refreshButton, 0, 3);
            tlpButtons.Controls.Add(closeButton, 0, 4);

            // Add button panel to tlpContent
            tlpContent.Controls.Add(tlpButtons, 1, 0);   // Col 1
                                                         // Add the grid to tlpContent
            tlpContent.Controls.Add(_requestsGrid, 0, 0);   // Col 0

            // ---------- Add content TLPanel to main TLPanel ----------
            tlpMain.Controls.Add(tlpContent, 0, 1);   // Row 1

            // ---------- Final form ----------
            this.Controls.Add(tlpMain);

            // ---------- Load data ----------
            LoadSupplyRequests();
        }

        private void LoadSupplyRequests()
        {
            try
            {
                var requests = _supplyRepository.GetSupplyRequestsByStaff(_currentUser.UserId);

                _requestsGrid.DataSource = requests.Select(r => new
                {
                    RequestId = r.SupplyRequestID,
                    SupplyName = r.Supply.SupplyName,
                    Quantity = r.QuantityRequested,
                    Unit = r.Supply.Unit,
                    RequestDate = r.RequestDate.ToString("dd/MM/yyyy"),
                    Status = r.Status.ToString(),
                    Notes = r.Notes
                }).ToList();

                // Customize column headers
                _requestsGrid.Columns["RequestId"].HeaderText = "Request ID";
                _requestsGrid.Columns["SupplyName"].HeaderText = "Supply";
                _requestsGrid.Columns["Quantity"].HeaderText = "Quantity";
                _requestsGrid.Columns["Unit"].HeaderText = "Unit";
                _requestsGrid.Columns["RequestDate"].HeaderText = "Request Date";
                _requestsGrid.Columns["Status"].HeaderText = "Status";
                _requestsGrid.Columns["Notes"].HeaderText = "Notes";

                // Hide RequestId column
                _requestsGrid.Columns["RequestId"].Visible = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading supply requests: {ex.Message}", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void AddButton_Click(object sender, EventArgs e)
        {
            var addForm = new AddEditSupplyRequestForm(_currentUser);
            if (addForm.ShowDialog() == DialogResult.OK)
            {
                LoadSupplyRequests();
            }
        }

        private void EditButton_Click(object sender, EventArgs e)
        {
            if (_requestsGrid.SelectedRows.Count > 0)
            {
                var requestId = Convert.ToInt32(_requestsGrid.SelectedRows[0].Cells["RequestId"].Value);
                var editForm = new AddEditSupplyRequestForm(_currentUser, requestId);
                if (editForm.ShowDialog() == DialogResult.OK)
                {
                    LoadSupplyRequests();
                }
            }
            else
            {
                MessageBox.Show("Please select a request to edit.", "No Selection",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void DeleteButton_Click(object sender, EventArgs e)
        {
            if (_requestsGrid.SelectedRows.Count > 0)
            {
                if (MessageBox.Show("Are you sure you want to delete this supply request?",
                    "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    try
                    {
                        var requestId = Convert.ToInt32(_requestsGrid.SelectedRows[0].Cells["RequestId"].Value);
                        if (_supplyRepository.DeleteSupplyRequest(requestId))
                        {
                            MessageBox.Show("Supply request deleted successfully!", "Success",
                                MessageBoxButtons.OK, MessageBoxIcon.Information);
                            LoadSupplyRequests();
                        }
                        else
                        {
                            MessageBox.Show("Failed to delete supply request.", "Error",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Error deleting supply request: {ex.Message}", "Error",
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select a request to delete.", "No Selection",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void RefreshButton_Click(object sender, EventArgs e)
        {
            LoadSupplyRequests();
        }
    }
}
