﻿using ARFMS_System;
using ARFMS_System.Models;

namespace ARFMS.Forms
{
    public partial class UserManagementForm : Form
    {
        private UserRepository userRepository;
        private DataGridView usersDataGridView;
        private ComboBox roleFilterComboBox;

        public UserManagementForm()
        {
            userRepository = new UserRepository();
            InitializeComponent();
            LoadUsers();
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();

            // Form properties
            this.Text = "User Management";
            this.Size = new Size(900, 600);
            this.StartPosition = FormStartPosition.CenterParent;
            this.BackColor = Color.White;

            // Header Panel
            Panel headerPanel = new Panel();
            headerPanel.BackColor = Color.FromArgb(41, 128, 185);
            headerPanel.Dock = DockStyle.Top;
            headerPanel.Height = 60;
            //this.Controls.Add(headerPanel);

            // Title Label
            Label titleLabel = new Label();
            titleLabel.Text = "User Management";
            titleLabel.Font = new Font("Segoe UI", 16, FontStyle.Bold);
            titleLabel.ForeColor = Color.White;
            titleLabel.Location = new Point(20, 15);
            titleLabel.Size = new Size(200, 30);
            headerPanel.Controls.Add(titleLabel);

            // Filter Panel
            Panel filterPanel = new Panel();
            filterPanel.Dock = DockStyle.Top;
            filterPanel.Height = 50;
            filterPanel.BackColor = Color.FromArgb(236, 240, 241);
            //this.Controls.Add(filterPanel);

            // Role Filter Label
            Label roleFilterLabel = new Label();
            roleFilterLabel.Text = "Filter by Role:";
            roleFilterLabel.Font = new Font("Segoe UI", 10);
            roleFilterLabel.Location = new Point(20, 15);
            roleFilterLabel.Size = new Size(100, 20);
            filterPanel.Controls.Add(roleFilterLabel);

            // Role Filter ComboBox
            roleFilterComboBox = new ComboBox();
            roleFilterComboBox.Font = new Font("Segoe UI", 10);
            roleFilterComboBox.Location = new Point(130, 12);
            roleFilterComboBox.Size = new Size(150, 25);
            roleFilterComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
            roleFilterComboBox.Items.AddRange(new string[] { "All", "Reception", "MaintenanceStaff" });
            roleFilterComboBox.SelectedIndex = 0;
            roleFilterComboBox.SelectedIndexChanged += RoleFilterComboBox_SelectedIndexChanged;
            filterPanel.Controls.Add(roleFilterComboBox);

            // Add User Button
            Button addUserButton = new Button();
            addUserButton.Text = "Add User";
            addUserButton.Font = new Font("Segoe UI", 10, FontStyle.Bold);
            addUserButton.BackColor = Color.FromArgb(46, 204, 113);
            addUserButton.ForeColor = Color.White;
            addUserButton.FlatStyle = FlatStyle.Flat;
            addUserButton.Location = new Point(300, 10);
            addUserButton.Size = new Size(100, 30);
            addUserButton.Click += AddUserButton_Click;
            filterPanel.Controls.Add(addUserButton);

            // DataGridView
            usersDataGridView = new DataGridView();
            usersDataGridView.Dock = DockStyle.Fill;
            usersDataGridView.BackgroundColor = Color.White;
            usersDataGridView.BorderStyle = BorderStyle.None;
            usersDataGridView.AllowUserToAddRows = false;
            usersDataGridView.AllowUserToDeleteRows = false;
            usersDataGridView.ReadOnly = true;
            usersDataGridView.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            usersDataGridView.MultiSelect = false;
            usersDataGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            usersDataGridView.RowHeadersVisible = false;
            usersDataGridView.CellDoubleClick += UsersDataGridView_CellDoubleClick;
            //this.Controls.Add(usersDataGridView);

            // Context Menu
            ContextMenuStrip contextMenu = new ContextMenuStrip();

            ToolStripMenuItem editMenuItem = new ToolStripMenuItem("Edit User");
            editMenuItem.Click += EditMenuItem_Click;
            contextMenu.Items.Add(editMenuItem);

            ToolStripMenuItem deleteMenuItem = new ToolStripMenuItem("Delete User");
            deleteMenuItem.Click += DeleteMenuItem_Click;
            contextMenu.Items.Add(deleteMenuItem);

            usersDataGridView.ContextMenuStrip = contextMenu;

            this.ResumeLayout(false);

            // 4️⃣ Wrap everything in a TableLayoutPanel
            var tlp = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 1,
                RowCount = 3
            };

            // Make sure the row heights match the panels’ heights
            tlp.RowStyles.Add(new RowStyle(SizeType.Absolute, headerPanel.Height));
            tlp.RowStyles.Add(new RowStyle(SizeType.Absolute, filterPanel.Height));
            tlp.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));

            // Add the controls to the TLP
            tlp.Controls.Add(headerPanel, 0, 0);
            tlp.Controls.Add(filterPanel, 0, 1);
            tlp.Controls.Add(usersDataGridView, 0, 2);

            // Finally add the TLP to the form
            this.Controls.Add(tlp);

        }

        private void LoadUsers()
        {
            try
            {
                List<User> allUsers = new List<User>();

                // Get Reception and Maintenance Staff only
                allUsers.AddRange(userRepository.GetUsersByRole(UserRole.Reception));
                allUsers.AddRange(userRepository.GetUsersByRole(UserRole.MaintenanceStaff));

                // Apply role filter
                string selectedRole = roleFilterComboBox?.SelectedItem?.ToString();
                if (!string.IsNullOrEmpty(selectedRole) && selectedRole != "All")
                {
                    UserRole filterRole = (UserRole)Enum.Parse(typeof(UserRole), selectedRole);
                    allUsers = allUsers.Where(u => u.UserRole == filterRole).ToList();
                }

                // Create display data
                var displayData = allUsers.Select(u => new
                {
                    UserID = u.UserID,
                    Username = u.Username,
                    Email = u.Email,
                    FullName = u.FullName,
                    Role = u.UserRole.ToString(),
                    PhoneNumber = u.PhoneNumber,
                    IsActive = u.IsActive ? "Active" : "Inactive",
                    CreatedDate = u.CreatedDate.ToString("yyyy-MM-dd"),
                    LastLogin = u.LastLoginDate?.ToString("yyyy-MM-dd HH:mm") ?? "Never"
                }).ToList();

                usersDataGridView.DataSource = displayData;

                // Configure columns
                if (usersDataGridView.Columns.Count > 0)
                {
                    usersDataGridView.Columns["UserID"].Visible = false;
                    usersDataGridView.Columns["Username"].HeaderText = "Username";
                    usersDataGridView.Columns["Email"].HeaderText = "Email";
                    usersDataGridView.Columns["FullName"].HeaderText = "Full Name";
                    usersDataGridView.Columns["Role"].HeaderText = "Role";
                    usersDataGridView.Columns["PhoneNumber"].HeaderText = "Phone";
                    usersDataGridView.Columns["IsActive"].HeaderText = "Status";
                    usersDataGridView.Columns["CreatedDate"].HeaderText = "Created";
                    usersDataGridView.Columns["LastLogin"].HeaderText = "Last Login";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading users: {ex.Message}", "Error",
                              MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void RoleFilterComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            LoadUsers();
        }

        private void AddUserButton_Click(object sender, EventArgs e)
        {
            AddEditUserForm addUserForm = new AddEditUserForm();
            if (addUserForm.ShowDialog() == DialogResult.OK)
            {
                LoadUsers();
            }
        }

        private void UsersDataGridView_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            EditSelectedUser();
        }

        private void EditMenuItem_Click(object sender, EventArgs e)
        {
            EditSelectedUser();
        }

        private void DeleteMenuItem_Click(object sender, EventArgs e)
        {
            DeleteSelectedUser();
        }

        private void EditSelectedUser()
        {
            if (usersDataGridView.SelectedRows.Count > 0)
            {
                int userId = Convert.ToInt32(usersDataGridView.SelectedRows[0].Cells["UserID"].Value);
                User user = userRepository.GetUserById(userId);

                if (user != null)
                {
                    AddEditUserForm editUserForm = new AddEditUserForm(user);
                    if (editUserForm.ShowDialog() == DialogResult.OK)
                    {
                        LoadUsers();
                    }
                }
            }
        }

        private void DeleteSelectedUser()
        {
            if (usersDataGridView.SelectedRows.Count > 0)
            {
                string username = usersDataGridView.SelectedRows[0].Cells["Username"].Value.ToString();

                DialogResult result = MessageBox.Show($"Are you sure you want to delete user '{username}'?",
                                                    "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                if (result == DialogResult.Yes)
                {
                    try
                    {
                        int userId = Convert.ToInt32(usersDataGridView.SelectedRows[0].Cells["UserID"].Value);
                        userRepository.DeleteUser(userId);
                        LoadUsers();
                        MessageBox.Show("User deleted successfully.", "Success",
                                      MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Error deleting user: {ex.Message}", "Error",
                                      MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }
    }
}
