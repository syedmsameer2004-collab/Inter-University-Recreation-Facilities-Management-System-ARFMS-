﻿using System;
using System.Drawing;
using System.Windows.Forms;
using ARFMS_System.Models;
using ARFMS.Services;

namespace ARFMS.Forms
{
    public partial class MaintenanceHomeForm : Form
    {
        private User currentUser;

        public MaintenanceHomeForm(User user)
        {
            currentUser = user;
            InitializeComponent();
            SetupCustomUI();
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // MaintenanceHomeForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1000, 700);
            this.Name = "MaintenanceHomeForm";
            this.Text = "Maintenance Staff Dashboard";
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.White;
            this.ResumeLayout(false);
        }

        private void SetupCustomUI()
        {
            // Header Panel
            Panel headerPanel = new Panel();
            headerPanel.BackColor = Color.FromArgb(41, 128, 185);
            headerPanel.Dock = DockStyle.Top;
            headerPanel.Height = 80;
            //this.Controls.Add(headerPanel);

            // Title Label
            Label titleLabel = new Label();
            titleLabel.Text = "Maintenance Staff Dashboard";
            titleLabel.Font = new Font("Segoe UI", 18, FontStyle.Bold);
            titleLabel.ForeColor = Color.White;
            titleLabel.Location = new Point(20, 20);
            titleLabel.Size = new Size(400, 40);
            headerPanel.Controls.Add(titleLabel);

            // Welcome Label
            Label welcomeLabel = new Label();
            welcomeLabel.Text = $"Welcome, {currentUser?.FullName ?? "Maintenance Staff"}";
            welcomeLabel.Font = new Font("Segoe UI", 12);
            welcomeLabel.ForeColor = Color.White;
            welcomeLabel.Location = new Point(20, 50);
            welcomeLabel.Size = new Size(400, 25);
            headerPanel.Controls.Add(welcomeLabel);

            // Logout Button
            Button logoutButton = new Button();
            logoutButton.Text = "Logout";
            logoutButton.Font = new Font("Segoe UI", 10);
            logoutButton.BackColor = Color.FromArgb(231, 76, 60);
            logoutButton.ForeColor = Color.White;
            logoutButton.FlatStyle = FlatStyle.Flat;
            logoutButton.Location = new Point(850, 25);
            logoutButton.Size = new Size(100, 30);
            logoutButton.Click += LogoutButton_Click;
            headerPanel.Controls.Add(logoutButton);

            // Main Panel
            Panel mainPanel = new Panel();
            mainPanel.Dock = DockStyle.Fill;
            mainPanel.Padding = new Padding(20);
            //this.Controls.Add(mainPanel);

            // Create menu buttons
            CreateMenuButtons(mainPanel);
        }

        private void CreateMenuButtons(Panel parent)
        {
            // My Profile Button
            Button profileButton = CreateMenuButton("My Profile",
                "View & Update Profile Information", 50, 20);
            profileButton.Click += ProfileButton_Click;
            parent.Controls.Add(profileButton);

            // Maintenance Tasks Button
            Button tasksButton = CreateMenuButton("Maintenance Tasks",
                "View Assigned Maintenance Tasks", 350, 20);
            tasksButton.Click += TasksButton_Click;
            parent.Controls.Add(tasksButton);

            // Update Task Status Button
            Button statusButton = CreateMenuButton("Update Task Status",
                "Update Progress of Tasks", 650, 20);
            statusButton.Click += StatusButton_Click;
            parent.Controls.Add(statusButton);

            // Equipment Requests Button
            Button equipmentButton = CreateMenuButton("Equipment Requests",
                "Submit Equipment Requests", 50, 200);
            equipmentButton.Click += EquipmentButton_Click;
            parent.Controls.Add(equipmentButton);

            // Supply Requests Button
            Button supplyButton = CreateMenuButton("Supply Requests",
                "Request Cleaning Supplies", 350, 200);
            supplyButton.Click += SupplyButton_Click;
            parent.Controls.Add(supplyButton);

            // My Schedule Button
            Button scheduleButton = CreateMenuButton("My Schedule",
                "View Maintenance Schedule", 650, 200);
            scheduleButton.Click += ScheduleButton_Click;
            parent.Controls.Add(scheduleButton);
        }

        private Button CreateMenuButton(string title, string description, int x, int y)
        {
            Button button = new Button();
            button.Text = $"{title}\n{description}";
            button.Font = new Font("Segoe UI", 11, FontStyle.Bold);
            button.BackColor = Color.FromArgb(52, 152, 219);
            button.ForeColor = Color.White;
            button.FlatStyle = FlatStyle.Flat;
            button.FlatAppearance.BorderSize = 0;
            button.Location = new Point(x, y);
            button.Size = new Size(250, 120);
            button.TextAlign = ContentAlignment.MiddleCenter;
            button.Cursor = Cursors.Hand;

            // Hover effects
            button.MouseEnter += (s, e) => button.BackColor = Color.FromArgb(41, 128, 185);
            button.MouseLeave += (s, e) => button.BackColor = Color.FromArgb(52, 152, 219);

            return button;
        }

        private void ProfileButton_Click(object sender, EventArgs e)
        {
            MaintenanceProfileForm profileForm = new MaintenanceProfileForm(currentUser);
            profileForm.ShowDialog();
        }

        private void TasksButton_Click(object sender, EventArgs e)
        {
            MyMaintenanceScheduleForm scheduleForm = new MyMaintenanceScheduleForm(currentUser);
            scheduleForm.ShowDialog();
        }

        private void StatusButton_Click(object sender, EventArgs e)
        {
            UpdateMaintenanceStatusForm statusForm = new UpdateMaintenanceStatusForm(currentUser);
            statusForm.ShowDialog();
        }

        private void EquipmentButton_Click(object sender, EventArgs e)
        {
            EquipmentRequestForm equipmentForm = new EquipmentRequestForm(currentUser);
            equipmentForm.ShowDialog();
        }

        private void SupplyButton_Click(object sender, EventArgs e)
        {
            AddEditSupplyRequestForm supplyForm = new AddEditSupplyRequestForm(currentUser);
            supplyForm.ShowDialog();
        }

        private void ScheduleButton_Click(object sender, EventArgs e)
        {
            MyMaintenanceScheduleForm scheduleForm = new MyMaintenanceScheduleForm(currentUser);
            scheduleForm.ShowDialog();
        }

        private void LogoutButton_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you sure you want to logout?",
                                                "Confirm Logout", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                AuthenticationService authService = new AuthenticationService();
                authService.Logout();

                LoginForm loginForm = new LoginForm();
                loginForm.Show();
                this.Close();
            }
        }
    }
}
