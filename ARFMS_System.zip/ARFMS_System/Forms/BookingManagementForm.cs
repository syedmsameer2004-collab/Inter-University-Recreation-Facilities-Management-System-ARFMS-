using ARFMS_System;
using ARFMS_System.Models;

namespace ARFMS.Forms
{
    public partial class BookingManagementForm : Form
    {
        private BookingRepository bookingRepository;
        private DataGridView bookingsGrid;
        private Button acceptButton;
        private Button editButton;
        private Button deleteButton;
        private Button refreshButton;

        public BookingManagementForm()
        {
            bookingRepository = new BookingRepository();
            InitializeComponent();
            LoadBookings();
        }

        private void InitializeComponent()
        {
            this.Text = "Booking Management";
            this.Size = new Size(900, 600);
            this.StartPosition = FormStartPosition.CenterScreen;

            // Create controls
            bookingsGrid = new DataGridView();
            bookingsGrid.Location = new Point(20, 20);
            bookingsGrid.Size = new Size(840, 400);
            bookingsGrid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            bookingsGrid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            bookingsGrid.MultiSelect = false;
            this.Controls.Add(bookingsGrid);

            // Buttons
            acceptButton = new Button();
            acceptButton.Text = "Accept Booking";
            acceptButton.Location = new Point(20, 440);
            acceptButton.Size = new Size(120, 30);
            acceptButton.Click += AcceptButton_Click;
            this.Controls.Add(acceptButton);

            editButton = new Button();
            editButton.Text = "Edit Booking";
            editButton.Location = new Point(160, 440);
            editButton.Size = new Size(120, 30);
            editButton.Click += EditButton_Click;
            this.Controls.Add(editButton);

            deleteButton = new Button();
            deleteButton.Text = "Cancel Booking";
            deleteButton.Location = new Point(300, 440);
            deleteButton.Size = new Size(120, 30);
            deleteButton.Click += DeleteButton_Click;
            this.Controls.Add(deleteButton);

            refreshButton = new Button();
            refreshButton.Text = "Refresh";
            refreshButton.Location = new Point(440, 440);
            refreshButton.Size = new Size(120, 30);
            refreshButton.Click += RefreshButton_Click;
            this.Controls.Add(refreshButton);
        }

        private void LoadBookings()
        {
            var bookings = bookingRepository.GetAllBookings();
            bookingsGrid.DataSource = bookings;
        }

        private void AcceptButton_Click(object sender, EventArgs e)
        {
            if (bookingsGrid.SelectedRows.Count > 0)
            {
                int bookingId = (int)bookingsGrid.SelectedRows[0].Cells["BookingID"].Value;
                bookingRepository.UpdateBookingStatus(bookingId, BookingStatus.Confirmed);
                LoadBookings();
                MessageBox.Show("Booking accepted successfully!");
            }
        }

        private void EditButton_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Edit booking functionality will be implemented.");
        }

        private void DeleteButton_Click(object sender, EventArgs e)
        {
            if (bookingsGrid.SelectedRows.Count > 0)
            {
                int bookingId = (int)bookingsGrid.SelectedRows[0].Cells["BookingID"].Value;
                bookingRepository.UpdateBookingStatus(bookingId, BookingStatus.Cancelled);
                LoadBookings();
                MessageBox.Show("Booking cancelled successfully!");
            }
        }

        private void RefreshButton_Click(object sender, EventArgs e)
        {
            LoadBookings();
        }
    }
}
