using ARFMS.Services;
using ARFMS_System;
using ARFMS_System.Models;

namespace ARFMS.Forms
{
    public partial class BookFacilityForm : Form
    {
        private BookingRepository bookingRepository;
        private FacilityRepository facilityRepository;
        private int facilityId;
        private string facilityName;
        private Facility selectedFacility;

        public BookFacilityForm(int facilityId, string facilityName)
        {
            this.facilityId = facilityId;
            this.facilityName = facilityName;
            bookingRepository = new BookingRepository();
            facilityRepository = new FacilityRepository();
            InitializeComponent();
            LoadFacilityDetails();
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();

            // Form properties
            this.Text = "Book Facility";
            this.Size = new Size(500, 450);
            this.StartPosition = FormStartPosition.CenterParent;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.BackColor = Color.White;

            // Facility Name Label
            Label facilityLabel = new Label();
            facilityLabel.Text = $"Booking: {facilityName}";
            facilityLabel.Font = new Font("Segoe UI", 14, FontStyle.Bold);
            facilityLabel.ForeColor = Color.FromArgb(155, 89, 182);
            facilityLabel.Location = new Point(30, 20);
            facilityLabel.Size = new Size(400, 30);
            this.Controls.Add(facilityLabel);

            // Booking Date
            Label dateLabel = new Label();
            dateLabel.Text = "Booking Date:";
            dateLabel.Font = new Font("Segoe UI", 10);
            dateLabel.Location = new Point(30, 70);
            dateLabel.Size = new Size(100, 20);
            this.Controls.Add(dateLabel);

            DateTimePicker datePicker = new DateTimePicker();
            datePicker.Name = "dtpDate";
            datePicker.Font = new Font("Segoe UI", 10);
            datePicker.Location = new Point(140, 68);
            datePicker.Size = new Size(200, 25);
            datePicker.Format = DateTimePickerFormat.Short;
            datePicker.MinDate = DateTime.Today.AddDays(1); // Must book at least 1 day in advance
            this.Controls.Add(datePicker);

            // Start Time
            Label startTimeLabel = new Label();
            startTimeLabel.Text = "Start Time:";
            startTimeLabel.Font = new Font("Segoe UI", 10);
            startTimeLabel.Location = new Point(30, 110);
            startTimeLabel.Size = new Size(100, 20);
            this.Controls.Add(startTimeLabel);

            DateTimePicker startTimePicker = new DateTimePicker();
            startTimePicker.Name = "dtpStartTime";
            startTimePicker.Font = new Font("Segoe UI", 10);
            startTimePicker.Location = new Point(140, 108);
            startTimePicker.Size = new Size(150, 25);
            startTimePicker.Format = DateTimePickerFormat.Time;
            startTimePicker.ShowUpDown = true;
            startTimePicker.ValueChanged += TimePickerValueChanged;
            this.Controls.Add(startTimePicker);

            // End Time
            Label endTimeLabel = new Label();
            endTimeLabel.Text = "End Time:";
            endTimeLabel.Font = new Font("Segoe UI", 10);
            endTimeLabel.Location = new Point(30, 150);
            endTimeLabel.Size = new Size(100, 20);
            this.Controls.Add(endTimeLabel);

            DateTimePicker endTimePicker = new DateTimePicker();
            endTimePicker.Name = "dtpEndTime";
            endTimePicker.Font = new Font("Segoe UI", 10);
            endTimePicker.Location = new Point(140, 148);
            endTimePicker.Size = new Size(150, 25);
            endTimePicker.Format = DateTimePickerFormat.Time;
            endTimePicker.ShowUpDown = true;
            endTimePicker.ValueChanged += TimePickerValueChanged;
            this.Controls.Add(endTimePicker);

            // Duration Label
            Label durationLabel = new Label();
            durationLabel.Name = "lblDuration";
            durationLabel.Text = "Duration: 0 hours";
            durationLabel.Font = new Font("Segoe UI", 10);
            durationLabel.Location = new Point(140, 180);
            durationLabel.Size = new Size(200, 20);
            this.Controls.Add(durationLabel);

            // Total Cost Label
            Label totalCostLabel = new Label();
            totalCostLabel.Name = "lblTotalCost";
            totalCostLabel.Text = "Total Cost: $0.00";
            totalCostLabel.Font = new Font("Segoe UI", 12, FontStyle.Bold);
            totalCostLabel.ForeColor = Color.FromArgb(46, 204, 113);
            totalCostLabel.Location = new Point(140, 210);
            totalCostLabel.Size = new Size(200, 25);
            this.Controls.Add(totalCostLabel);

            // Notes
            Label notesLabel = new Label();
            notesLabel.Text = "Notes:";
            notesLabel.Font = new Font("Segoe UI", 10);
            notesLabel.Location = new Point(30, 250);
            notesLabel.Size = new Size(100, 20);
            this.Controls.Add(notesLabel);

            TextBox notesTextBox = new TextBox();
            notesTextBox.Name = "txtNotes";
            notesTextBox.Font = new Font("Segoe UI", 10);
            notesTextBox.Location = new Point(140, 248);
            notesTextBox.Size = new Size(300, 60);
            notesTextBox.Multiline = true;
            notesTextBox.ScrollBars = ScrollBars.Vertical;
            this.Controls.Add(notesTextBox);

            // Check Availability Button
            Button checkAvailabilityButton = new Button();
            checkAvailabilityButton.Text = "Check Availability";
            checkAvailabilityButton.Font = new Font("Segoe UI", 10);
            checkAvailabilityButton.BackColor = Color.FromArgb(52, 152, 219);
            checkAvailabilityButton.ForeColor = Color.White;
            checkAvailabilityButton.FlatStyle = FlatStyle.Flat;
            checkAvailabilityButton.Location = new Point(140, 330);
            checkAvailabilityButton.Size = new Size(130, 30);
            checkAvailabilityButton.Click += CheckAvailabilityButton_Click;
            this.Controls.Add(checkAvailabilityButton);

            // Book Button
            Button bookButton = new Button();
            bookButton.Text = "Book Now";
            bookButton.Font = new Font("Segoe UI", 10, FontStyle.Bold);
            bookButton.BackColor = Color.FromArgb(46, 204, 113);
            bookButton.ForeColor = Color.White;
            bookButton.FlatStyle = FlatStyle.Flat;
            bookButton.Location = new Point(280, 330);
            bookButton.Size = new Size(100, 30);
            bookButton.Click += BookButton_Click;
            this.Controls.Add(bookButton);

            // Cancel Button
            Button cancelButton = new Button();
            cancelButton.Text = "Cancel";
            cancelButton.Font = new Font("Segoe UI", 10);
            cancelButton.BackColor = Color.FromArgb(149, 165, 166);
            cancelButton.ForeColor = Color.White;
            cancelButton.FlatStyle = FlatStyle.Flat;
            cancelButton.Location = new Point(390, 330);
            cancelButton.Size = new Size(80, 30);
            cancelButton.Click += CancelButton_Click;
            this.Controls.Add(cancelButton);

            this.ResumeLayout(false);
        }

        private void LoadFacilityDetails()
        {
            try
            {
                var facilities = facilityRepository.GetAllFacilities();
                selectedFacility = facilities.Find(f => f.FacilityID == facilityId);

                if (selectedFacility != null)
                {
                    // Set default end time to 1 hour after start time
                    DateTimePicker startTimePicker = this.Controls["dtpStartTime"] as DateTimePicker;
                    DateTimePicker endTimePicker = this.Controls["dtpEndTime"] as DateTimePicker;
                    endTimePicker.Value = startTimePicker.Value.AddHours(1);

                    CalculateCost();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading facility details: {ex.Message}", "Error",
                              MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void TimePickerValueChanged(object sender, EventArgs e)
        {
            CalculateCost();
        }

        private void CalculateCost()
        {
            try
            {
                DateTimePicker startTimePicker = this.Controls["dtpStartTime"] as DateTimePicker;
                DateTimePicker endTimePicker = this.Controls["dtpEndTime"] as DateTimePicker;
                Label durationLabel = this.Controls["lblDuration"] as Label;
                Label totalCostLabel = this.Controls["lblTotalCost"] as Label;

                TimeSpan duration = endTimePicker.Value.TimeOfDay - startTimePicker.Value.TimeOfDay;

                if (duration.TotalHours > 0 && selectedFacility != null)
                {
                    int hours = (int)Math.Ceiling(duration.TotalHours);
                    decimal totalCost = selectedFacility.HourlyRate * hours;

                    durationLabel.Text = $"Duration: {hours} hour(s)";
                    totalCostLabel.Text = $"Total Cost: {totalCost:C}";
                }
                else
                {
                    durationLabel.Text = "Duration: 0 hours";
                    totalCostLabel.Text = "Total Cost: $0.00";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error calculating cost: {ex.Message}", "Error",
                              MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void CheckAvailabilityButton_Click(object sender, EventArgs e)
        {
            try
            {
                DateTimePicker datePicker = this.Controls["dtpDate"] as DateTimePicker;
                DateTimePicker startTimePicker = this.Controls["dtpStartTime"] as DateTimePicker;
                DateTimePicker endTimePicker = this.Controls["dtpEndTime"] as DateTimePicker;

                DateTime bookingDate = datePicker.Value.Date;
                TimeSpan startTime = startTimePicker.Value.TimeOfDay;
                TimeSpan endTime = endTimePicker.Value.TimeOfDay;

                if (endTime <= startTime)
                {
                    MessageBox.Show("End time must be after start time.", "Invalid Time",
                                  MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                bool isAvailable = bookingRepository.IsFacilityAvailable(facilityId, bookingDate, startTime, endTime);

                if (isAvailable)
                {
                    MessageBox.Show("Facility is available for the selected time slot!", "Available",
                                  MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("Facility is not available for the selected time slot. Please choose a different time.",
                                  "Not Available", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error checking availability: {ex.Message}", "Error",
                              MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BookButton_Click(object sender, EventArgs e)
        {
            try
            {
                if (!ValidateInput())
                    return;

                DateTimePicker datePicker = this.Controls["dtpDate"] as DateTimePicker;
                DateTimePicker startTimePicker = this.Controls["dtpStartTime"] as DateTimePicker;
                DateTimePicker endTimePicker = this.Controls["dtpEndTime"] as DateTimePicker;
                TextBox notesTextBox = this.Controls["txtNotes"] as TextBox;

                DateTime bookingDate = datePicker.Value.Date;
                TimeSpan startTime = startTimePicker.Value.TimeOfDay;
                TimeSpan endTime = endTimePicker.Value.TimeOfDay;

                // Check availability one more time
                bool isAvailable = bookingRepository.IsFacilityAvailable(facilityId, bookingDate, startTime, endTime);

                if (!isAvailable)
                {
                    MessageBox.Show("Facility is no longer available for the selected time slot.",
                                  "Not Available", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Calculate total cost
                int hours = (int)Math.Ceiling((endTime - startTime).TotalHours);
                decimal totalCost = selectedFacility.HourlyRate * hours;

                // Create booking
                Booking booking = new Booking
                {
                    StudentID = AuthenticationService.CurrentUser.UserID,
                    FacilityID = facilityId,
                    BookingDate = bookingDate,
                    StartTime = startTime,
                    EndTime = endTime,
                    TotalAmount = totalCost,
                    BookingStatus = BookingStatus.Pending,
                    PaymentStatus = PaymentStatus.Unpaid,
                    Notes = notesTextBox.Text.Trim()
                };

                bookingRepository.AddBooking(booking);

                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error creating booking: {ex.Message}", "Error",
                              MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void CancelButton_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private bool ValidateInput()
        {
            DateTimePicker startTimePicker = this.Controls["dtpStartTime"] as DateTimePicker;
            DateTimePicker endTimePicker = this.Controls["dtpEndTime"] as DateTimePicker;

            if (endTimePicker.Value.TimeOfDay <= startTimePicker.Value.TimeOfDay)
            {
                MessageBox.Show("End time must be after start time.", "Invalid Time",
                              MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            return true;
        }
    }
}
