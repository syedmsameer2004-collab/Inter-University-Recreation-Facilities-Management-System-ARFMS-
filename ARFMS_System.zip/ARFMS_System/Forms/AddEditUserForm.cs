using ARFMS_System;
using ARFMS_System.Models;

namespace ARFMS.Forms
{
    public partial class AddEditUserForm : Form
    {
        private UserRepository userRepository;
        private User currentUser;
        private bool isEditMode;

        public AddEditUserForm(User user = null)
        {
            userRepository = new UserRepository();
            currentUser = user;
            isEditMode = user != null;
            InitializeComponent();

            if (isEditMode)
            {
                LoadUserData();
            }
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();

            // Form properties
            this.Text = isEditMode ? "Edit User" : "Add User";
            this.Size = new Size(450, 400);
            this.StartPosition = FormStartPosition.CenterParent;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.BackColor = Color.White;

            // Username Label & TextBox
            Label usernameLabel = new Label();
            usernameLabel.Text = "Username:";
            usernameLabel.Font = new Font("Segoe UI", 10);
            usernameLabel.Location = new Point(30, 30);
            usernameLabel.Size = new Size(80, 20);
            this.Controls.Add(usernameLabel);

            TextBox usernameTextBox = new TextBox();
            usernameTextBox.Name = "txtUsername";
            usernameTextBox.Font = new Font("Segoe UI", 10);
            usernameTextBox.Location = new Point(120, 28);
            usernameTextBox.Size = new Size(280, 25);
            this.Controls.Add(usernameTextBox);

            // Email Label & TextBox
            Label emailLabel = new Label();
            emailLabel.Text = "Email:";
            emailLabel.Font = new Font("Segoe UI", 10);
            emailLabel.Location = new Point(30, 70);
            emailLabel.Size = new Size(80, 20);
            this.Controls.Add(emailLabel);

            TextBox emailTextBox = new TextBox();
            emailTextBox.Name = "txtEmail";
            emailTextBox.Font = new Font("Segoe UI", 10);
            emailTextBox.Location = new Point(120, 68);
            emailTextBox.Size = new Size(280, 25);
            this.Controls.Add(emailTextBox);

            // Password Label & TextBox
            Label passwordLabel = new Label();
            passwordLabel.Text = "Password:";
            passwordLabel.Font = new Font("Segoe UI", 10);
            passwordLabel.Location = new Point(30, 110);
            passwordLabel.Size = new Size(80, 20);
            this.Controls.Add(passwordLabel);

            TextBox passwordTextBox = new TextBox();
            passwordTextBox.Name = "txtPassword";
            passwordTextBox.Font = new Font("Segoe UI", 10);
            passwordTextBox.Location = new Point(120, 108);
            passwordTextBox.Size = new Size(280, 25);
            passwordTextBox.UseSystemPasswordChar = true;
            this.Controls.Add(passwordTextBox);

            // First Name Label & TextBox
            Label firstNameLabel = new Label();
            firstNameLabel.Text = "First Name:";
            firstNameLabel.Font = new Font("Segoe UI", 10);
            firstNameLabel.Location = new Point(30, 150);
            firstNameLabel.Size = new Size(80, 20);
            this.Controls.Add(firstNameLabel);

            TextBox firstNameTextBox = new TextBox();
            firstNameTextBox.Name = "txtFirstName";
            firstNameTextBox.Font = new Font("Segoe UI", 10);
            firstNameTextBox.Location = new Point(120, 148);
            firstNameTextBox.Size = new Size(280, 25);
            this.Controls.Add(firstNameTextBox);

            // Last Name Label & TextBox
            Label lastNameLabel = new Label();
            lastNameLabel.Text = "Last Name:";
            lastNameLabel.Font = new Font("Segoe UI", 10);
            lastNameLabel.Location = new Point(30, 190);
            lastNameLabel.Size = new Size(80, 20);
            this.Controls.Add(lastNameLabel);

            TextBox lastNameTextBox = new TextBox();
            lastNameTextBox.Name = "txtLastName";
            lastNameTextBox.Font = new Font("Segoe UI", 10);
            lastNameTextBox.Location = new Point(120, 188);
            lastNameTextBox.Size = new Size(280, 25);
            this.Controls.Add(lastNameTextBox);

            // Phone Label & TextBox
            Label phoneLabel = new Label();
            phoneLabel.Text = "Phone:";
            phoneLabel.Font = new Font("Segoe UI", 10);
            phoneLabel.Location = new Point(30, 230);
            phoneLabel.Size = new Size(80, 20);
            this.Controls.Add(phoneLabel);

            TextBox phoneTextBox = new TextBox();
            phoneTextBox.Name = "txtPhone";
            phoneTextBox.Font = new Font("Segoe UI", 10);
            phoneTextBox.Location = new Point(120, 228);
            phoneTextBox.Size = new Size(280, 25);
            this.Controls.Add(phoneTextBox);

            // Role Label & ComboBox
            Label roleLabel = new Label();
            roleLabel.Text = "Role:";
            roleLabel.Font = new Font("Segoe UI", 10);
            roleLabel.Location = new Point(30, 270);
            roleLabel.Size = new Size(80, 20);
            this.Controls.Add(roleLabel);

            ComboBox roleComboBox = new ComboBox();
            roleComboBox.Name = "cmbRole";
            roleComboBox.Font = new Font("Segoe UI", 10);
            roleComboBox.Location = new Point(120, 268);
            roleComboBox.Size = new Size(280, 25);
            roleComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
            roleComboBox.Items.AddRange(new string[] { "Reception", "MaintenanceStaff" });
            roleComboBox.SelectedIndex = 0;
            this.Controls.Add(roleComboBox);

            // Save Button
            Button saveButton = new Button();
            saveButton.Text = "Save";
            saveButton.Font = new Font("Segoe UI", 10, FontStyle.Bold);
            saveButton.BackColor = Color.FromArgb(46, 204, 113);
            saveButton.ForeColor = Color.White;
            saveButton.FlatStyle = FlatStyle.Flat;
            saveButton.Location = new Point(200, 320);
            saveButton.Size = new Size(80, 30);
            saveButton.Click += SaveButton_Click;
            this.Controls.Add(saveButton);

            // Cancel Button
            Button cancelButton = new Button();
            cancelButton.Text = "Cancel";
            cancelButton.Font = new Font("Segoe UI", 10);
            cancelButton.BackColor = Color.FromArgb(149, 165, 166);
            cancelButton.ForeColor = Color.White;
            cancelButton.FlatStyle = FlatStyle.Flat;
            cancelButton.Location = new Point(300, 320);
            cancelButton.Size = new Size(80, 30);
            cancelButton.Click += CancelButton_Click;
            this.Controls.Add(cancelButton);

            this.ResumeLayout(false);
        }

        private void LoadUserData()
        {
            if (currentUser != null)
            {
                (this.Controls["txtUsername"] as TextBox).Text = currentUser.Username;
                (this.Controls["txtEmail"] as TextBox).Text = currentUser.Email;
                (this.Controls["txtFirstName"] as TextBox).Text = currentUser.FirstName;
                (this.Controls["txtLastName"] as TextBox).Text = currentUser.LastName;
                (this.Controls["txtPhone"] as TextBox).Text = currentUser.PhoneNumber;
                (this.Controls["cmbRole"] as ComboBox).SelectedItem = currentUser.UserRole.ToString();

                // Don't show password in edit mode
                (this.Controls["txtPassword"] as TextBox).PlaceholderText = "Leave blank to keep current password";
            }
        }

        private void SaveButton_Click(object sender, EventArgs e)
        {
            try
            {
                // Validate input
                if (!ValidateInput())
                    return;

                User user = isEditMode ? currentUser : new User();

                user.Username = (this.Controls["txtUsername"] as TextBox).Text.Trim();
                user.Email = (this.Controls["txtEmail"] as TextBox).Text.Trim();
                user.FirstName = (this.Controls["txtFirstName"] as TextBox).Text.Trim();
                user.LastName = (this.Controls["txtLastName"] as TextBox).Text.Trim();
                user.PhoneNumber = (this.Controls["txtPhone"] as TextBox).Text.Trim();
                user.UserRole = (UserRole)Enum.Parse(typeof(UserRole), (this.Controls["cmbRole"] as ComboBox).SelectedItem.ToString());

                string password = (this.Controls["txtPassword"] as TextBox).Text;
                if (!isEditMode || !string.IsNullOrWhiteSpace(password))
                {
                    user.Password = password; // In production, hash this password
                }

                if (isEditMode)
                {
                    userRepository.UpdateUser(user);
                    MessageBox.Show("User updated successfully.", "Success",
                                  MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    userRepository.AddUser(user);
                    MessageBox.Show("User added successfully.", "Success",
                                  MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error saving user: {ex.Message}", "Error",
                              MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void CancelButton_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private bool ValidateInput()
        {
            string username = (this.Controls["txtUsername"] as TextBox).Text.Trim();
            string email = (this.Controls["txtEmail"] as TextBox).Text.Trim();
            string password = (this.Controls["txtPassword"] as TextBox).Text;
            string firstName = (this.Controls["txtFirstName"] as TextBox).Text.Trim();
            string lastName = (this.Controls["txtLastName"] as TextBox).Text.Trim();

            if (string.IsNullOrWhiteSpace(username))
            {
                MessageBox.Show("Username is required.", "Validation Error",
                              MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            if (string.IsNullOrWhiteSpace(email))
            {
                MessageBox.Show("Email is required.", "Validation Error",
                              MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            if (!isEditMode && string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("Password is required for new users.", "Validation Error",
                              MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            if (string.IsNullOrWhiteSpace(firstName))
            {
                MessageBox.Show("First name is required.", "Validation Error",
                              MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            if (string.IsNullOrWhiteSpace(lastName))
            {
                MessageBox.Show("Last name is required.", "Validation Error",
                              MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            return true;
        }
    }
}
