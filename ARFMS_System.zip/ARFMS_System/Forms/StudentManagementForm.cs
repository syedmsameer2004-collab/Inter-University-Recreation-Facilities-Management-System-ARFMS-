using ARFMS_System;
using ARFMS_System.Models;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace ARFMS.Forms
{
    public partial class StudentManagementForm : Form
    {
        private UserRepository userRepository;
        private DataGridView studentsDataGridView;

        public StudentManagementForm()
        {
            userRepository = new UserRepository();
            InitializeComponent();
            LoadStudents();
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();

            // ===== Form properties =====
            this.Text = "Student Management";
            this.Size = new Size(900, 600);
            this.StartPosition = FormStartPosition.CenterParent;
            this.BackColor = Color.White;

            // ===== Root layout: header (auto), toolbar (auto), grid (fill) =====
            var root = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 1,
                RowCount = 3,
                BackColor = Color.White
            };
            root.RowStyles.Add(new RowStyle(SizeType.AutoSize));          // Header
            root.RowStyles.Add(new RowStyle(SizeType.AutoSize));          // Command bar
            root.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));     // Grid
            this.Controls.Add(root);

            // ===== Header (TableLayout) =====
            var header = new TableLayoutPanel
            {
                Dock = DockStyle.Top,
                BackColor = Color.FromArgb(46, 204, 113),
                ColumnCount = 2,
                RowCount = 1,
                Padding = new Padding(20, 12, 20, 12),
                AutoSize = true
            };
            header.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f)); // left grows
            header.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));       // right (empty spacer for future)
            root.Controls.Add(header, 0, 0);

            var titleLabel = new Label
            {
                Text = "Student Management",
                Font = new Font("Segoe UI", 16, FontStyle.Bold),
                ForeColor = Color.White,
                AutoSize = true,
                Anchor = AnchorStyles.Left
            };
            header.Controls.Add(titleLabel, 0, 0);

            // (Optional spacer/right area)
            header.Controls.Add(new Panel { Width = 1, Height = 1 }, 1, 0);

            // ===== Command bar (TableLayout) =====
            var cmdBar = new TableLayoutPanel
            {
                Dock = DockStyle.Top,
                BackColor = Color.FromArgb(236, 240, 241),
                ColumnCount = 3,
                RowCount = 1,
                Padding = new Padding(12, 8, 12, 8),
                AutoSize = true
            };
            cmdBar.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));        // Add
            cmdBar.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));        // Refresh
            cmdBar.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));   // Filler
            root.Controls.Add(cmdBar, 0, 1);

            var addStudentButton = new Button
            {
                Text = "Add Student",
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                BackColor = Color.FromArgb(46, 204, 113),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                AutoSize = true,
                Margin = new Padding(8, 0, 8, 0)
            };
            addStudentButton.FlatAppearance.BorderSize = 0;
            addStudentButton.Click += AddStudentButton_Click;
            cmdBar.Controls.Add(addStudentButton, 0, 0);

            var refreshButton = new Button
            {
                Text = "Refresh",
                Font = new Font("Segoe UI", 10),
                BackColor = Color.FromArgb(52, 152, 219),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                AutoSize = true,
                Margin = new Padding(8, 0, 8, 0)
            };
            refreshButton.FlatAppearance.BorderSize = 0;
            refreshButton.Click += RefreshButton_Click;
            cmdBar.Controls.Add(refreshButton, 1, 0);

            // Filler to push buttons left
            cmdBar.Controls.Add(new Panel { Dock = DockStyle.Fill }, 2, 0);

            // ===== DataGridView =====
            studentsDataGridView = new DataGridView
            {
                Dock = DockStyle.Fill,
                BackgroundColor = Color.White,
                BorderStyle = BorderStyle.None,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                MultiSelect = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                RowHeadersVisible = false
            };
            studentsDataGridView.CellDoubleClick += StudentsDataGridView_CellDoubleClick;
            // Ensure right-click selects the row under cursor before showing context menu
            studentsDataGridView.MouseDown += (s, e) =>
            {
                if (e.Button == MouseButtons.Right)
                {
                    var hit = studentsDataGridView.HitTest(e.X, e.Y);
                    if (hit.RowIndex >= 0)
                    {
                        studentsDataGridView.ClearSelection();
                        studentsDataGridView.Rows[hit.RowIndex].Selected = true;
                    }
                }
            };
            root.Controls.Add(studentsDataGridView, 0, 2);

            // ===== Context Menu =====
            var contextMenu = new ContextMenuStrip();

            var editMenuItem = new ToolStripMenuItem("Edit Student");
            editMenuItem.Click += EditMenuItem_Click;
            contextMenu.Items.Add(editMenuItem);

            var deleteMenuItem = new ToolStripMenuItem("Delete Student");
            deleteMenuItem.Click += DeleteMenuItem_Click;
            contextMenu.Items.Add(deleteMenuItem);

            studentsDataGridView.ContextMenuStrip = contextMenu;

            this.ResumeLayout(false);
        }

        private void LoadStudents()
        {
            try
            {
                List<User> students = userRepository.GetUsersByRole(UserRole.Student);

                var displayData = students.Select(s => new
                {
                    UserID = s.UserID,
                    Username = s.Username,
                    Email = s.Email,
                    FullName = s.FullName,
                    PhoneNumber = s.PhoneNumber,
                    IsActive = s.IsActive ? "Active" : "Inactive",
                    CreatedDate = s.CreatedDate.ToString("yyyy-MM-dd"),
                    LastLogin = s.LastLoginDate?.ToString("yyyy-MM-dd HH:mm") ?? "Never"
                }).ToList();

                studentsDataGridView.DataSource = displayData;

                // Configure columns
                if (studentsDataGridView.Columns.Count > 0)
                {
                    studentsDataGridView.Columns["UserID"].Visible = false;
                    studentsDataGridView.Columns["Username"].HeaderText = "Username";
                    studentsDataGridView.Columns["Email"].HeaderText = "Email";
                    studentsDataGridView.Columns["FullName"].HeaderText = "Full Name";
                    studentsDataGridView.Columns["PhoneNumber"].HeaderText = "Phone";
                    studentsDataGridView.Columns["IsActive"].HeaderText = "Status";
                    studentsDataGridView.Columns["CreatedDate"].HeaderText = "Created";
                    studentsDataGridView.Columns["LastLogin"].HeaderText = "Last Login";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading students: {ex.Message}", "Error",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void AddStudentButton_Click(object sender, EventArgs e)
        {
            var addStudentForm = new AddEditStudentForm();
            if (addStudentForm.ShowDialog() == DialogResult.OK)
            {
                LoadStudents();
            }
        }

        private void RefreshButton_Click(object sender, EventArgs e)
        {
            LoadStudents();
        }

        private void StudentsDataGridView_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            EditSelectedStudent();
        }

        private void EditMenuItem_Click(object sender, EventArgs e)
        {
            EditSelectedStudent();
        }

        private void DeleteMenuItem_Click(object sender, EventArgs e)
        {
            DeleteSelectedStudent();
        }

        private void EditSelectedStudent()
        {
            if (studentsDataGridView.SelectedRows.Count > 0)
            {
                int userId = Convert.ToInt32(studentsDataGridView.SelectedRows[0].Cells["UserID"].Value);
                User student = userRepository.GetUserById(userId);

                if (student != null)
                {
                    var editStudentForm = new AddEditStudentForm(student);
                    if (editStudentForm.ShowDialog() == DialogResult.OK)
                    {
                        LoadStudents();
                    }
                }
            }
        }

        private void DeleteSelectedStudent()
        {
            if (studentsDataGridView.SelectedRows.Count > 0)
            {
                string studentName = studentsDataGridView.SelectedRows[0].Cells["FullName"].Value.ToString();

                DialogResult result = MessageBox.Show(
                    $"Are you sure you want to delete student '{studentName}'?",
                    "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                if (result == DialogResult.Yes)
                {
                    try
                    {
                        int userId = Convert.ToInt32(studentsDataGridView.SelectedRows[0].Cells["UserID"].Value);
                        userRepository.DeleteUser(userId);
                        LoadStudents();
                        MessageBox.Show("Student deleted successfully.", "Success",
                                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Error deleting student: {ex.Message}", "Error",
                                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }
    }
}
