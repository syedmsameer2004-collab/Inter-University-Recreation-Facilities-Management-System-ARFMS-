﻿using ARFMS_System.Models;
using ARFMS_System;
using System;
using System.Drawing;
using System.Windows.Forms;

namespace ARFMS.Forms
{
    public partial class MaintenanceStaffHomeForm : Form
    {
        private User _currentUser;

        public MaintenanceStaffHomeForm(User user)
        {
            _currentUser = user;
            InitializeComponent();
            SetupForm();
        }
        private void InitializeComponent()
        {
            // ---- 1️⃣  Form base settings -----------------------------------------
            this.Size = new Size(1000, 700);
            this.Text = "ARFMS - Maintenance Staff Dashboard";
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.FromArgb(240, 248, 255);

            // ---- 2️⃣  TLPanel (fills the form) -----------------------------------
            var tlpMain = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                RowCount = 2,
                ColumnCount = 1,
                RowStyles =
        {
            // Header – fixed 80 px
            new RowStyle(SizeType.Absolute, 80f),
            // Main – takes the rest
            new RowStyle(SizeType.Percent, 100f)
        }
            };

            // ---- 3️⃣  Header Panel ------------------------------------------------
            var headerPanel = new Panel
            {
                BackColor = Color.FromArgb(70, 130, 180),
                Dock = DockStyle.Fill   // TLPanel will keep the height 80 px
            };

            var titleLabel = new Label
            {
                Text = "Maintenance Staff Dashboard",
                Font = new Font("Segoe UI", 18, FontStyle.Bold),
                ForeColor = Color.White,
                Location = new Point(20, 20),
                AutoSize = true
            };

            var welcomeLabel = new Label
            {
                Text = $"Welcome, {_currentUser.FullName}",
                Font = new Font("Segoe UI", 12),
                ForeColor = Color.White,
                Location = new Point(20, 50),
                AutoSize = true
            };

            var logoutButton = new Button
            {
                Text = "Logout",
                Size = new Size(80, 30),
                Location = new Point(900, 25),
                BackColor = Color.FromArgb(220, 20, 60),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            logoutButton.Click += LogoutButton_Click;
            // If you want it to stay on the right edge:
            logoutButton.Anchor = AnchorStyles.Top | AnchorStyles.Right;

            headerPanel.Controls.AddRange(new Control[] { titleLabel, welcomeLabel, logoutButton });

            // ---- 4️⃣  Main Content Panel ------------------------------------------
            var mainPanel = new Panel
            {
                Dock = DockStyle.Fill,
                Padding = new Padding(20)
            };

            // ---- 5️⃣  Menu Buttons ------------------------------------------------
            var viewScheduleButton = CreateMenuButton("View My Schedule",
                                                           "View your assigned maintenance tasks", 50);
            viewScheduleButton.Click += ViewScheduleButton_Click;

            var updateStatusButton = CreateMenuButton("Update Maintenance Status",
                                                           "Update completion status of maintenance tasks", 150);
            updateStatusButton.Click += UpdateStatusButton_Click;

            var manageSuppliesButton = CreateMenuButton("Manage Cleaning Supplies",
                                                           "Request and manage cleaning supplies", 250);
            manageSuppliesButton.Click += ManageSuppliesButton_Click;

            var equipmentRequestButton = CreateMenuButton("Equipment Requests",
                                                           "Submit equipment repair/replacement requests", 350);
            equipmentRequestButton.Click += EquipmentRequestButton_Click;

            var profileButton = CreateMenuButton("Update Profile",
                                                           "Update your personal information", 450);
            profileButton.Click += ProfileButton_Click;

            mainPanel.Controls.AddRange(new Control[]
            {
        viewScheduleButton,
        updateStatusButton,
        manageSuppliesButton,
        equipmentRequestButton,
        profileButton
            });

            // ---- 6️⃣  Wire everything together -----------------------------------
            tlpMain.Controls.Add(headerPanel);   // Row 0
            tlpMain.Controls.Add(mainPanel);     // Row 1
            this.Controls.Add(tlpMain);          // TLPanel is the *only* control on the form

            // ---- 7️⃣  Final tweaks -------------------------------------------------
            SetupForm(); // keeps FixedDialog + no maximize
        }

        private Button CreateMenuButton(string title, string description, int yPosition)
        {
            var button = new Button
            {
                Size = new Size(400, 80),
                Location = new Point(50, yPosition),
                BackColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 12, FontStyle.Bold),
                Text = $"{title}\n{description}",
                TextAlign = ContentAlignment.MiddleLeft,
                Padding = new Padding(20, 10, 10, 10),
                Cursor = Cursors.Hand
            };

            button.FlatAppearance.BorderColor = Color.FromArgb(70, 130, 180);
            button.FlatAppearance.BorderSize = 2;

            button.MouseEnter += (s, e) => button.BackColor = Color.FromArgb(230, 240, 255);
            button.MouseLeave += (s, e) => button.BackColor = Color.White;

            return button;
        }

        private void SetupForm()
        {
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
        }

        private void ViewScheduleButton_Click(object sender, EventArgs e)
        {
            var scheduleForm = new MyMaintenanceScheduleForm(_currentUser);
            scheduleForm.ShowDialog();
        }

        private void UpdateStatusButton_Click(object sender, EventArgs e)
        {
            var updateForm = new UpdateMaintenanceStatusForm(_currentUser);
            updateForm.ShowDialog();
        }

        private void ManageSuppliesButton_Click(object sender, EventArgs e)
        {
            var suppliesForm = new ManageSuppliesForm(_currentUser);
            suppliesForm.ShowDialog();
        }

        private void EquipmentRequestButton_Click(object sender, EventArgs e)
        {
            var equipmentForm = new EquipmentRequestForm(_currentUser);
            equipmentForm.ShowDialog();
        }

        private void ProfileButton_Click(object sender, EventArgs e)
        {
            var profileForm = new MaintenanceProfileForm(_currentUser);
            if (profileForm.ShowDialog() == DialogResult.OK)
            {
                _currentUser = profileForm.UpdatedUser;
                this.Text = $"ARFMS - Maintenance Staff Dashboard - {_currentUser.FullName}";
            }
        }

        private void LogoutButton_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to logout?", "Confirm Logout",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                this.Hide();
                var loginForm = new LoginForm();
                loginForm.ShowDialog();
                this.Close();
            }
        }
    }
}
