using System;
using System.Drawing;
using System.Windows.Forms;
using ARFMS_System.Models;

namespace ARFMS.Forms
{
    public partial class MaintenanceProfileForm : Form
    {
        private User _currentUser;
        public User UpdatedUser { get; private set; }

        public MaintenanceProfileForm(User user)
        {
            _currentUser = user;
            UpdatedUser = user;
            InitializeComponent();
            LoadUserData();
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();
            
            // Form properties
            this.Text = "Maintenance Profile";
            this.Size = new Size(500, 400);
            this.StartPosition = FormStartPosition.CenterParent;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;

            // Create form controls
            CreateControls();
            
            this.ResumeLayout(false);
        }

        private void CreateControls()
        {
            // First Name
            Label lblFirstName = new Label { Text = "First Name:", Location = new Point(20, 20), Size = new Size(100, 23) };
            TextBox txtFirstName = new TextBox { Name = "txtFirstName", Location = new Point(130, 20), Size = new Size(200, 23) };

            // Last Name
            Label lblLastName = new Label { Text = "Last Name:", Location = new Point(20, 60), Size = new Size(100, 23) };
            TextBox txtLastName = new TextBox { Name = "txtLastName", Location = new Point(130, 60), Size = new Size(200, 23) };

            // Email
            Label lblEmail = new Label { Text = "Email:", Location = new Point(20, 100), Size = new Size(100, 23) };
            TextBox txtEmail = new TextBox { Name = "txtEmail", Location = new Point(130, 100), Size = new Size(200, 23) };

            // Phone
            Label lblPhone = new Label { Text = "Phone:", Location = new Point(20, 140), Size = new Size(100, 23) };
            TextBox txtPhone = new TextBox { Name = "txtPhone", Location = new Point(130, 140), Size = new Size(200, 23) };

            // Buttons
            Button btnSave = new Button { Text = "Save", Location = new Point(130, 200), Size = new Size(80, 30) };
            Button btnCancel = new Button { Text = "Cancel", Location = new Point(220, 200), Size = new Size(80, 30) };

            btnSave.Click += BtnSave_Click;
            btnCancel.Click += (s, e) => { this.DialogResult = DialogResult.Cancel; this.Close(); };

            this.Controls.AddRange(new Control[] { 
                lblFirstName, txtFirstName, lblLastName, txtLastName, 
                lblEmail, txtEmail, lblPhone, txtPhone, btnSave, btnCancel 
            });
        }

        private void LoadUserData()
        {
            if (_currentUser != null)
            {
                ((TextBox)this.Controls["txtFirstName"]).Text = _currentUser.FirstName;
                ((TextBox)this.Controls["txtLastName"]).Text = _currentUser.LastName;
                ((TextBox)this.Controls["txtEmail"]).Text = _currentUser.Email;
                ((TextBox)this.Controls["txtPhone"]).Text = _currentUser.PhoneNumber ?? "";
            }
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            try
            {
                _currentUser.FirstName = ((TextBox)this.Controls["txtFirstName"]).Text;
                _currentUser.LastName = ((TextBox)this.Controls["txtLastName"]).Text;
                _currentUser.Email = ((TextBox)this.Controls["txtEmail"]).Text;
                _currentUser.PhoneNumber = ((TextBox)this.Controls["txtPhone"]).Text;

                UpdatedUser = _currentUser;
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error saving profile: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
